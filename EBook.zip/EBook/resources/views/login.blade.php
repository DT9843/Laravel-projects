<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookbhandar login</title>
    <link rel="stylesheet"  href="{{asset('css/style.css')}}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    
    <div class="form-container">

        <div>
            <h1 class="login-h1">Login</h1>
        </div>
        @if($errors -> has('email'))
            <div class="error">
                <p>{{$errors ->first('email')}}</p>
            </div>
        @endif
        <form action="/login" method="POST" class="login-form">
           

           
            @csrf
            <div>
                <label for="email">Email</label>
                <input type="email" name="email" id="email" class="login-form-input">
            </div>

            <div>
                <label for="password">Password</label>
                <input type="password" name="password" id="password" class="login-form-input">
            </div>
            
            <div>
                <label>
                    <input type="checkbox" name="remember" id="remember-me"> 
                    <span>Remember me</span>
                </label>
                
            </div>

            <div>
                <input type="submit" value="Login" class="login-form-btn">
            </div>
          

        </form>

        <div class="login-form-links">
            <a href="/signup">Do not have an account?</a>
            <a href="/forgot-password">Forgot password?</a>
        </div>

    </div>


    <!-- <script src="{{asset('js/login.js')}}"></script> -->

</body>
</html>