@extends('base')

@section('head')

<meta name="csrf-token" content="{{ csrf_token() }}">

@endsection

@section('title') Home @endsection

<!-- @section('css')  
    <link rel="stylesheet"  href="{{asset('css/style.css')}}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
@endsection -->

@section('body')
    <div class="welcome">

        <h1 class="welcome-text">WELCOME TO BOOKBHANDAR</h1>

    </div>

    <div class="container">

        <div class="new-arrivals">
            <div class="common-heading">
                <h2>New Arrivals</h2>
                <a href="/view/all/books/New Arrivals">VIEW ALL</a>
                
            </div>

            @if(count($new_arrival_books) < 6)
            <div class="new-arrivals-books">
            @else
            <div class="new-arrivals-books-2">
            @endif  
      
                @foreach($new_arrival_books as $new_book)
                <div class="books" id="{{$new_book->id}}">
                    <img src="{{asset($new_book -> image_path)}}" alt="" height="240px" width="158px">
                    <div class="book-info">
                      <a href="" class="title-link">  <h6 href="" class="title">{{$new_book -> title}}</h6></a>
                        <!-- <p class="author"><b>by</b> {{$new_book->author()->first()->first_name}} {{$new_book->author()->first()->last_name}}</p> -->
                        <p class="author"><b>by</b> 
                        @for($authors = 0; $authors < count($new_book->author()->get()); $authors++ )

                            @if( $authors + 1 === count($new_book->author()->get()) - 1 )
                               {{ $new_book->author()->get()[$authors]->first_name}} {{$new_book->author()->get()[$authors]->last_name}} and

                            @elseif($authors + 1 < count($new_book->author()->get()) - 1)
                               {{ $new_book->author()->get()[$authors]->first_name}} {{ $new_book->author()->get()[$authors]->last_name}} ,

                            @else
                               {{ $new_book->author()->get()[$authors]->first_name}} {{$new_book->author()->get()[$authors]->last_name}}.

                            @endif


                        @endfor
                        
                        </p> 

                        <div>
                            @for($i=0; $i< 5; $i++)
                                @if($new_book -> rating > $i)
                                    <span class="fa fa-star checked rating"></span>
                                @else
                                    <span class="fa fa-star rating"></span>
                                @endif
                            @endfor
                        </div>
                        <p class="price">NPR.{{$new_book -> price}}</p>
                    </div>
                        @auth

                            @if(Auth::user()->book()->where('book_id',$new_book->id)->first())
                                <button class="cart-btn-view" onclick='window.location.href="{{url('/cart')}}"' >
                                  View Cart
                                </button>
                            @else
                                <button class="cart-btn" onclick='addToCart("{{$new_book->title}}",this)'>
                                  Add To Cart
                                </button>
                            @endif
                        @else
                       
                            <button class="cart-btn" onclick='window.location.href="{{url('/login')}}"'>Add To Cart</button>
                     

                        @endauth
                </div>
                @endforeach
           

    
            </div>
            

        </div>
   </div>



   @include('footer')
   <script src="{{asset('js/cart.js')}}"></script>

@endsection