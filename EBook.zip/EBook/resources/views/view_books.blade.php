@extends("base")

@section('head')

<meta name="csrf-token" content="{{ csrf_token() }}">

@endsection

@section("title") View All Books @endsection


@section("body")

<div class="container">

    <div class="common-heading">
        <h2>{{$str}}</h2>
    </div>

<div class="new-arrivals">
    @if(count($books) < 6)
    <div class="new-arrivals-books">
    @else
    <div class="new-arrivals-books-2">
    @endif    
        @foreach($books as $book)
        
        <div class="books" id="{{$book->id}}">
          <img src="{{asset($book -> image_path)}}" alt="" height="240px" width="158px">
            <div class="book-info">
               <a href="" class="title-link">  <h6 class="title">{{$book -> title}}</h6></a>

              <p class="author"><b>by</b> 
                @for($authors = 0; $authors < count($book->author()->get()); $authors++ )

                    @if( $authors + 1 === count($book->author()->get()) - 1 )
                        {{ $book->author()->get()[$authors]->first_name}} {{$book->author()->get()[$authors]->last_name}} and

                    @elseif($authors + 1 < count($book->author()->get()) - 1)
                        {{ $book->author()->get()[$authors]->first_name}} {{ $book->author()->get()[$authors]->last_name}} ,

                    @else
                        {{ $book->author()->get()[$authors]->first_name}} {{$book->author()->get()[$authors]->last_name}}.

                    @endif


                @endfor
                
                </p> 

                <div>
                    @for($i=0; $i< 5; $i++)
                        @if($book -> rating > $i)
                            <span class="fa fa-star checked rating"></span>
                        @else
                            <span class="fa fa-star rating"></span>
                        @endif
                    @endfor
                </div>
                <p class="price">NPR.{{$book -> price}}</p>
           </div>
                @auth

                    @if(Auth::user()->book()->where('book_id',$book->id)->first())
                        <button class="cart-btn-view" onclick='window.location.href="{{url('/cart')}}"' >
                            View Cart
                        </button>
                    @else
                        <button class="cart-btn" onclick='addToCart("{{$book->title}}",this)'>
                            Add To Cart
                        </button>
                    @endif
                @else
                
                    <button class="cart-btn" onclick='window.location.href="{{url('/login')}}"'>Add To Cart</button>
                

                @endauth
        </div>
        @endforeach
    
    </div>
    

</div>

    <div class="pages">

            <div class="page not-active page-decrement" id="page-decrement">
                &#9664;
            </div>

            <div class="page-no">
            @for($i=1; $i<=$totalPages; $i++)
                @if($page === $i)
                    @if(str_contains($str, 'Category'))
                    <div class="page radio-activated" data-page="{{$i}}" data-url="{{url('/book/page')}}/{{str_replace(': ','/$i/',$str)}}" onclick="pageSwitch(this)">
                    @elseif(str_contains($str, 'New Arrivals'))
                    <div class="page radio-activated" data-page="{{$i}}" data-url="{{url('/book/page')}}/{{str_replace(' ','%20',$str)}}/{{$i}}" onclick="pageSwitch(this)">
                    @endif
                        <label for="{{$i}}" class="page_label">{{$i}}</label>
                        <input type="radio" name="page_no" class="radio-hidden" id="{{$i}}" value="{{$i}}" checked>
                    </div>

                @else
                    @if(str_contains($str, 'Category'))
                    <div class="page not-active" data-page="{{$i}}" data-url="{{url('/book/page')}}/{{str_replace(': ','/$i/',$str)}}" onclick="pageSwitch(this)">
                    @elseif(str_contains($str, 'New Arrivals'))
                    <div class="page not-active" data-page="{{$i}}" data-url="{{url('/book/page')}}/{{str_replace(' ','%20',$str)}}/{{$i}}" onclick="pageSwitch(this)">
                    @endif
                        <label for="{{$i}}" class="page_label">{{$i}}</label>
                        <input type="radio" name="page_no" class="radio-hidden" id="{{$i}}" value="{{$i}}">
                    </div>
                @endif

            @endfor

            </div>

            <div class="page not-active page-increment" id="page-increment">
                &#9654;
            </div>

        </div>



</div>
</div>

@include('footer')
<script src="{{asset('js/pagination.js')}}"></script>


@endsection