<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookbhandar signup</title>
    <link rel="stylesheet"  href="{{asset('css/style.css')}}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    
    <div class="form-container-signup">

        <div>
            <h1 class="signup-h1">SignUp</h1>
        </div>

        <form action="/signup" method="POST" class="signup-form" enctype="multipart/form-data">
    
            @csrf
            <div>

                @if($errors->has('username'))
                <p class="error-msg">{{$errors->first('username')}}</p>
                @endif

                <label for="username">Username</label>
                @if($errors->has('username'))
                <input type="text" name="username" id="username" class="signup-form-input signup-form-input-error">
                @else
                <input type="text" name="username" id="username" class="signup-form-input">
                @endif
            </div>

            <div>
                @if($errors->has('firstname'))
                    <p class="error-msg">{{$errors->first('firstname')}}</p>
                @endif
                <label for="firstname">First Name</label>
                @if($errors->has('firstname'))
                <input type="text" name="firstname" id="firstname" class="signup-form-input signup-form-input-error">
                @else
                <input type="text" name="firstname" id="firstname" class="signup-form-input">
                @endif
            </div>

            <div>
                @if($errors->has('lastname'))
                    <p class="error-msg">{{$errors->first('lastname')}}</p>
                @endif
                <label for="lastname">Last Name</label>
                @if($errors->has('lastname'))
                <input type="text" name="lastname" id="lastname" class="signup-form-input signup-form-input-error">
                @else
                <input type="text" name="lastname" id="lastname" class="signup-form-input">
                @endif
            </div>


            <div>
                @if($errors->has('password'))
                    <p class="error-msg">{{$errors->first('password')}}</p>
                @endif
                <label for="password">Password</label>

                @if($errors->has('password'))
                <input type="password" name="password" id="password" class="signup-form-input signup-form-input-error">
                @else
                <input type="password" name="password" id="password" class="signup-form-input">
                @endif
            </div>

            
            <div>
                @if($errors->has('password'))
                    <p class="error-msg">{{$errors->first('password')}}</p>
                @endif
                <label for="cpassword">Confirm Password</label>

                @if($errors->has('password'))
                <input type="password" name="password_confirmation" id="cpassword" class="signup-form-input signup-form-input-error">
                @else
                <input type="password" name="password_confirmation" id="cpassword" class="signup-form-input">
                @endif
            </div>

            <div>
                @if($errors->has('email'))
                    <p class="error-msg">{{$errors->first('email')}}</p>
                @endif
                <label for="email">E-mail</label>
                @if($errors->has('email'))
                <input type="email" name="email" id="email" class="signup-form-input signup-form-input-error">
                @else
                <input type="email" name="email" id="email" class="signup-form-input">
                @endif
            </div>

            <div>
                @if($errors->has('user-profile-image'))
                    <p class="error-msg">{{$errors->first('user-profile-image')}}</p>
                @endif
                <label for="upload-image">Upload image</label>

                @if($errors->has('user-profile-image'))
                <input type="file" name="user-profile-image" id="upload-image" class="signup-form-input signup-form-input-error">
                @else
                <input type="file" name="user-profile-image" id="upload-image" class="signup-form-input">
                @endif
            </div>



            <div>
                <input type="submit" value="Sign-Up" class="signup-form-btn">
            </div>
          

        </form>

        <div class="signup-form-links">
            <a href="/login">Already have an account?</a>
            <a href="/home">Go to home page</a>
        </div>

    </div>


</body>
</html>