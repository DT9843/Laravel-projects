@extends('base')

@section('head')

<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
@endsection

@section('title')

    {{$book->title}}

@endsection


@section('body')

    <div class="book-container">

        <div class="book-details">

            <div class="book-image">
                <img src="{{asset($book->image_path)}}" alt="" width="250px" height="400px">
                <h3 class="book-amount">NPR.{{$book->price}}</h3>

                @auth

                    @if(Auth::user()->book()->where('book_id',$book->id)->first())
                        <button class="cart-btn-view" onclick='window.location.href="{{url('/cart')}}"' >
                            View Cart
                        </button>
                    @else
                        <button class="cart-btn" onclick='addToCart("{{$book->title}}",this)'>
                         Add To Cart
                        </button>
                    @endif

                @else

                    <button class="cart-btn" onclick='window.location.href="{{url('/login')}}"'>Add To Cart</button>


                @endauth
            </div>

            <div class="book-info">

                <h1 class="book-title">{{$book->title}}</h1>
                <p class="book-authors">by
                @for($authors = 0; $authors < count($book->author()->get()); $authors++ )

                    @if( $authors + 1 === count($book->author()->get()) - 1 )
                        {{ $book->author()->get()[$authors]->first_name}} {{$book->author()->get()[$authors]->last_name}} and

                    @elseif($authors + 1 < count($book->author()->get()) - 1)
                        {{ $book->author()->get()[$authors]->first_name}} {{ $book->author()->get()[$authors]->last_name}} ,

                    @else
                        {{ $book->author()->get()[$authors]->first_name}} {{$book->author()->get()[$authors]->last_name}}.

                    @endif

                @endfor
                </p>

                <table>

                    <tr>
                        <td> <h3 class="book-publisher">Rating:</h3></td>
                        <td class="book-ratings"> 
                            @for($i=0; $i< 5; $i++)
                                @if($book -> rating > $i)
                                    <span class="fa fa-star checked rating"></span>
                                @else
                                    <span class="fa fa-star rating"></span>
                                @endif
                            @endfor
                            <b>({{count($book->userReview()->get())}})</b>
                        </td>
                    </tr>

                    <tr>
                        <td> <h3 class="book-publisher">Publisher:</h3></td>
                        <td><p>{{$book->publisher()->first()->name}}</p></td>
                    </tr>

                    <tr>
                        <td><h3>Category:</h3></td>
                        <td><p>
                            @foreach($book->category()->get() as $category)
                                {{$category->name}}
                            @endforeach
                        </p></td>
                    </tr>

                    <tr>
                        <td><h3>Published Date:</h3></td>
                        <td><p>{{$book->published_at}}</p></td>
                    </tr>

                    <tr>
                        <td><h3>Total Pages:</h3></td>
                        <td><p>{{$book->total_pages}}</p></td>
                    </tr>

                    <tr>
                        <td><h3>ISBN:</h3></td>
                        <td><p>{{$book->isbn_no}}</p></td>
                    </tr>

                    <tr>
                        <td><h3>Description</h3></td>
                        
                    </tr>

              
                </table>
                <tr>
            
                    <p class="book-description-para">
                        {{$book->description}}
                    </p>
                   
                </tr>
            </div>




        </div>

        <div class="user-review">
            <h2>Reviews</h2>
            <div class="reviews">
                @if(count($userReviews) > 0)
                  
                    @foreach($userReviews as $review)
                        <div class="review">
                            <div class="user-img">
                                <img src="{{asset($review->profile_pic)}}" height="70px" width="70px" alt="">
                            </div>
                            <div class="comment">
                                <p class="post-details">{{$review->first_name}} {{$review->last_name}} - {{$review->created_at}}</p>
                                <div class="user-given-rating">
                                    @for($i=0; $i< 5; $i++)
                                        @if($review->pivot->rating > $i)
                                            <span class="fa fa-star checked rating"></span>
                                        @else
                                            <span class="fa fa-star rating"></span>
                                        @endif
                                    @endfor
                                </div>
                                <p class="comment-text">{{$review->pivot->comment}}</p>
                                
                                @if(Auth::user())
                                    @if(Auth::user()->id === $review->pivot->user_id)
                                    <div class="comment-action">
                                        <a href="" class="comment-edit">EDIT</a>
                                        <a href="/delete/comment/{{$book->title}}/{{$review->pivot->id}}" class="comment-delete">DELETE</a>
                                    </div>
                                    @endif
                                @endif
                            </div>
                            
                         
                        </div>
                    @endforeach
                @else
                    <div class="no-reviews">
                        There are no comments yet.
                    </div>
                @endif
            </div>

            <div class="post-review">

                @auth
                    <form action="/book/{{$book->title}}" method="POST">

                        @csrf
                        <div>
                            <label for="star-1" onmouseover="setRatingsColor(1)" onmouseleave="resetRatings()" onclick="setRatings(1)" ><span class="fa fa-star rating review-star"></span></label>
                            <input type="radio" name="rating" id="star-1" class="star-rating" value="1">
                            <label for="star-2" onmouseover="setRatingsColor(2)" onmouseleave="resetRatings()" onclick="setRatings(2)"><span class="fa fa-star rating review-star"></span></label>
                            <input type="radio" name="rating" id="star-2" class="star-rating" value="2">
                            <label for="star-3" onmouseover="setRatingsColor(3)" onmouseleave="resetRatings()" onclick="setRatings(3)"><span class="fa fa-star rating review-star"></span></label>
                            <input type="radio" name="rating" id="star-3" class="star-rating" value="3">
                            <label for="star-4" onmouseover="setRatingsColor(4)" onmouseleave="resetRatings()" onclick="setRatings(4)"><span class="fa fa-star rating review-star"></span></label>
                            <input type="radio" name="rating" id="star-4" class="star-rating" value="4">
                            <label for="star-5" onmouseover="setRatingsColor(5)" onmouseleave="resetRatings()" onclick="setRatings(5)"><span class="fa fa-star rating review-star"></span></label>
                            <input type="radio" id="star-5" name="rating" class="star-rating" value="5">
                            <div id="review-status">Give Ratings</div>
                        </div>

                        <div>
                            <label for="comment-box">Enter your message here:</label>
                            <textarea name="comment" id="comment-box" >

                            </textarea>
                        </div>

                        <input type="submit" value="SUBMIT" id="comment-submit-btn">

                    </form>

                    <button id="reset-btn">
                        RESET
                    </button>
                @else
                    <h3>Authentication Required</h3>
                    <p>You must login to post a comment</p>
                    <a href="/login"><button>LOG IN</button></a>
                @endauth
            </div>

        </div>
        <!-- <p>{{$book->calculateRatings()}}</p>  -->
    </div>
    
    @include('footer')
    <script src="{{asset('js/cart.js')}}"></script>

    @auth
    <script src="{{asset('js/review.js')}}"></script>
    @endauth
    
@endsection