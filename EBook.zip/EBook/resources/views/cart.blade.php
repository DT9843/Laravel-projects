@extends('base')


@section('head')

<meta name="csrf-token" content="{{ csrf_token() }}">

@endsection

@section('title') View cart @endsection

@section('body')

@if($userCartTotalQty > 0)
    <div class="cart-container" id="cart-container">
@else
    <div class="cart-container cart-container-visibility" id="cart-container">
@endif
        <div class="cart-list">
            <div class="price-qty-info">
                <h3>MY CART</h3>
                <h3>PRICE</h3>
            </div>

<!-- ==========================================================================-->
        @foreach($cartItems as $cartItem)
       
            <div class="cart-items" id="{{$cartItem->id}}">

                <div class="item-img">
                    <img src="{{asset($cartItem->image_path)}}" height="100px" width="60px" alt="">
                </div>

                <div class="qty-info">
                    <h3 class="cart-title">{{$cartItem->title}}</h3>
                    <p>by
                    @for($authors = 0; $authors < count($cartItem->author()->get()); $authors++ )

                        @if( $authors + 1 === count($cartItem->author()->get()) - 1 )
                            {{ $cartItem->author()->get()[$authors]->first_name}} {{$cartItem->author()->get()[$authors]->last_name}} and

                        @elseif($authors + 1 < count($cartItem->author()->get()) - 1)
                            {{ $cartItem->author()->get()[$authors]->first_name}} {{ $cartItem->author()->get()[$authors]->last_name}} ,

                        @else
                            {{ $cartItem->author()->get()[$authors]->first_name}} {{$cartItem->author()->get()[$authors]->last_name}}.

                        @endif

                    @endfor

                    </p>

                    <div class="qty">
                        
                          
                        <button id="increment" onclick="increment('{{$cartItem->id}}')">+</button>
                        <input type="number" name="qty" id="qty-no" value="{{$cartItem->pivot->quantity}}" onclick="qtyNo(this, '{{$cartItem->id}}')">
                        <button id="decrement" onclick="decrement('{{$cartItem->id}}')">-</button>
                      
                    </div>

                    <div class="cart-action" >
                        <button id="delete" onclick="deleteCartItem('{{$cartItem->id}}')">delete</button>
                        <button class="update" onclick="updateItemQty('{{$cartItem->id}}')">update</button>
                    </div>
                </div>

                <div class="price-info">
                    <p>NPR.<span>{{$cartItem->price*$cartItem->pivot->quantity}}</span></p>
                </div>
            </div>
        @endforeach
<!-- ==========================================================================-->


        </div>

        <div class="checkout-info">

            <h3>Your Order Summary</h3>
            <div class="book-prices" id="cart-qty-price-info">
                @foreach($cartItems as $cartItem)

                    <div class="book-price">
                        <p class="book-price-child"><b><span>{{$cartItem->pivot->quantity}}</span> X</b> {{$cartItem->title}}</p>
                        <p>NPR.{{$cartItem->price*$cartItem->pivot->quantity}}</p>
                    </div>

                @endforeach
             
               
            </div>

            <div class="total-amt">
                <p>Total Amount</p>
                <p id="total-price">NPR.{{$totalAmt}}</p>
            </div>
            
            <a href="" class="chkout-btn"><button>CHECK OUT</button></a>
        </div>
</div>

@if($userCartTotalQty < 1)
    <div class="empt-cart-container" id="empt-cart-container">
@else
    <div class="empt-cart-container cart-container-visibility" id="empt-cart-container">
@endif

       <img src="{{asset('cart_pic/empty_cart.png')}}" height="325px" width="325px"alt=""> 
        <div class="empty-cart-info">
            <h1>Your cart is empty !</h1>

            <div class="empty-cart-para">
                <p>Looks like you have no items in your shopping cart.</p>
                <p>Explore around to add some items.</p>
            </div>

            <div class="browse-btn">
                <a href="">
                    <button>
                        Browse Books
                    </button>
                </a>
            </div>

        </div>
    </div>  

@include('footer')
<script src="{{asset('js/cart.js')}}"></script>



@endsection