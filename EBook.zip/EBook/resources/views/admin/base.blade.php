<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>
    <link rel="stylesheet"  href="{{asset('css/style.css')}}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<div class="admin-nav-bar">

<div >
    <h2 id="admin-logo">Bookbhandar Administration</h2>
</div>


<nav class="admin-nav-links" >
    <ul>
        <li class="nav-link"><a href="/admin/home"><i class="fa fa-home nav-icon"></i>Home</a></li>

        @if(Route::has('login'))
            @auth
            <li class="nav-link"><a href="/logout"><i class="fa fa-sign-out nav-icon"></i>Logout</a></li>
            @endauth
        
        @endif
    </ul>
</nav>

</div>

    @yield('body')

</body>
</html>