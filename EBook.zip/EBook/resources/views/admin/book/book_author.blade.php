@extends('admin.base')

@section('title') Add books authors @endsection

@section('body')

    <form action="/save/book/author" method="POST">
        @csrf
        <div>
            <label for="">Select book</label>
            <select name="book" id="">
                <option value="">None</option>
                @foreach($books as $book)
                    <option value="{{$book -> id}}">{{$book -> title}}</option>
                @endforeach
            </select>

        </div>
  
        <div>
            <label for="">Select author</label>
            <select name="author" id="">
                <option value="">None</option>
                @foreach($authors as $author)
                    <option value="{{$author->id}}">{{$author ->first_name}},{{$author -> last_name}}</option>
                @endforeach
            </select>

        </div>
    <input type="submit">
    </form>


@endsection
