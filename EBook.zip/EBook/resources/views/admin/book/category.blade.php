@extends('admin.base')

@section('title') Add category @endsection

@section('body')
<div class="admin-form-container">
    <fieldset>
    @if(isset($edit))
    <legend><h3>Category Info</h3></legend>
    <form action="/admin/edit/category/{{$category->id}}" method="POST">
        @csrf
        <div class="admin-book-info-container">
            @if($errors->has('category'))
                <p class="error-msg">{{$errors->first('category')}}</p>
            @endif
            <label for="" class="input-label">Category</label>
            @if($errors->has('category'))
            <input type="text" name="category" class="admin-book-info-input signup-form-input-error"  >

            @else
            <input type="text" name="category" class="admin-book-info-input" value="{{$category->name}}" >
            @endif
        </div>

        <div class="admin-book-info-container">
            <input type="submit" class="admin-edit-btn" value="EDIT">
        </div>

    </form>

    @else
    <legend><h3>Add Category</h3></legend>
    <form action="/save/category" method="POST">
        @csrf
        <div class="admin-book-info-container">
            @if($errors->has('category'))
                <p class="error-msg">{{$errors->first('category')}}</p>
            @endif
            <label for="" class="input-label">Category</label>
            @if($errors->has('category'))
            <input type="text" name="category" class="admin-book-info-input signup-form-input-error" >

            @else
            <input type="text" name="category" class="admin-book-info-input" >
            @endif
        </div>

        <div class="admin-book-info-container">
            <input type="submit" value="ADD" id="book-submit-btn"/>
        </div>

    </form>

    @endif

    </fieldset>
    @if(isset($edit))
    <div class="m-10">
        <a href="/admin/delete/category/{{$category->id}}"><button class="admin-delete-btn">DELETE</button></a>
    </div>
    @endif
</div>
@endsection