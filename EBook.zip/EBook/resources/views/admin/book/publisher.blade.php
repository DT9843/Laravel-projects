@extends('admin.base')

@section('title') Add publisher @endsection


@section('body')

<div class="admin-form-container">
    <fieldset>
        @if(isset($edit))
        <legend><h3>Publisher Info</h3></legend>
        <form action="/admin/edit/publisher/{{$publisher->id}}" method="POST">
        @else
        <legend><h3>Add Publisher</h3></legend>
        <form action="/save/publisher" method="POST">
        @endif

        @csrf
        <div class="admin-book-info-container">
        @if($errors->has('publisherName'))
            <p class="error-msg">{{$errors->first('publisherName')}}</p>
        @endif
            <label for="" class="input-label">Publisher Name</label>
            @if(isset($edit))
                @if($errors->has('publisherName'))
                <input type="text" name="publisherName" class="admin-book-info-input signup-form-input-error" require />
                @else
                <input type="text" name="publisherName" value="{{$publisher->name}}"  class="admin-book-info-input" require />
                @endif
          
            @else
                @if($errors->has('publisherName'))
                    <input type="text" name="publisherName"   class="admin-book-info-input signup-form-input-error" require />
                @else
                    <input type="text" name="publisherName"   class="admin-book-info-input" require />
                @endif
            @endif
        </div>

        <div class="admin-book-info-container">
            @if(isset($edit))
            
                <input type="submit" class="admin-edit-btn" value="EDIT">
            @else
                <input type="submit" value="ADD" id="book-submit-btn"/>
            @endif
        </div>
        
    </form>

       
    </fieldset>
    @if(isset($edit))
    <div class="m-10">
        <a href="/admin/delete/publisher/{{$publisher->id}}"><button class="admin-delete-btn">DELETE</button></a>
    </div>
    @endif
</div>
@endsection