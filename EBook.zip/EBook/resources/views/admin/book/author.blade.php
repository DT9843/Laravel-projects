@extends('admin.base')

@section('title') Create author @endsection

@section('body')

<div class="admin-form-container">

    @if(isset($edit))
    <div class="m-10">
        <fieldset>
            <legend><h3>Author Image</h3></legend>
            <form action="/admin/change/author/image/{{$author->id}}" method="POST" enctype="multipart/form-data">
                @csrf
                <div  class="admin-book-info-container">
                    <img src="{{asset($author->author_pic)}}" id="view-book-img" alt="">
                </div>
                @if($errors->has('authorPhoto'))
                    <p class="error-msg">{{$errors->first('authorPhoto')}}</p>
                @endif
                <div  class="admin-book-info-container">
                    <label for="" class="input-label">Choose New Photo</label>
                    @if($errors->has('authorPhoto'))
                    <input type="file" name="authorPhoto" class="admin-book-info-input signup-form-input-error" require />
                    @else
                    <input type="file" name="authorPhoto" class="admin-book-info-input" require />
                    @endif
                </div>

                <div  class="admin-book-info-container">
                    <input type="submit" class="admin-edit-btn" value="CHANGE">
                </div>
            </form>
        </fieldset>
    </div>

    <div class="m-10">

        <fieldset>

            <legend><h3>Author Info</h3></legend>
            <form action="/admin/edit/author/info/{{$author->id}}" method="POST">
                @csrf
                <div class="admin-book-info-container">
                    @if($errors->has('firstName'))
                        <p class="error-msg">{{$errors->first('firstName')}}</p>
                    @endif
                    <label for="" class="input-label">First Name</label>
                    @if($errors->has('firstName'))
                    <input type="text" class="admin-book-info-input signup-form-input-error" name="firstName" require />
                    @else
                    <input type="text" class="admin-book-info-input" value="{{$author->first_name}}" name="firstName" require />
                    @endif
                </div>


                <div class="admin-book-info-container">
                    @if($errors->has('lastName'))
                        <p class="error-msg">{{$errors->first('lastName')}}</p>
                    @endif
                    <label for="" class="input-label">Last Name</label>
                    @if($errors->has('lastName'))
                    <input type="text" class="admin-book-info-input signup-form-input-error" name="lastName" require />
                    @else
                    <input type="text" class="admin-book-info-input" value="{{$author->last_name}}" name="lastName" require />
                    @endif
                </div>

                <div class="admin-book-info-container">
                    @if($errors->has('bio'))
                        <p class="error-msg">{{$errors->first('bio')}}</p>
                    @endif
                    <label for="" class="input-label">Author description</label>
                    @if($errors->has('bio'))
                    <textarea name="bio" id="text-area" class="admin-book-info-input signup-form-input-error" require />
                        
                    </textarea>
                    @else
                    <textarea name="bio" id="text-area" class="admin-book-info-input" require />
                        {{$author->bio}}
                    </textarea>
                    @endif
                </div>

                <div class="admin-book-info-container">
                    <input type="submit" class="admin-edit-btn" value="EDIT">
                </div>

            </form>
        </fieldset>

    </div>
    <div class="m-10">
        <a href="/admin/delete/author/{{$author->id}}"><button class="admin-delete-btn">DELETE</button></a>
    </div>
    @else

        <fieldset>
            <legend><h3>Add author</h3></legend>

            <form action='/save/author' method="post" enctype="multipart/form-data">
                @csrf

                <div class="admin-book-info-container">
                    @if($errors->has('firstName'))
                        <p class="error-msg">{{$errors->first('firstName')}}</p>
                    @endif
                    <label for="" class="input-label">First Name</label>
                    @if($errors->has('firstName'))
                    <input type="text" class="admin-book-info-input signup-form-input-error" name="firstName" require />
                    @else
                    <input type="text" class="admin-book-info-input"  name="firstName" require />
                    @endif
                </div>

                <div class="admin-book-info-container">
                    @if($errors->has('lastName'))
                        <p class="error-msg">{{$errors->first('lastName')}}</p>
                    @endif
                    <label for="" class="input-label">Last Name</label>
                    @if($errors->has('lastName'))
                    <input type="text" class="admin-book-info-input signup-form-input-error" name="lastName" require />
                    @else
                    <input type="text" class="admin-book-info-input"  name="lastName" require />
                    @endif
                </div>

                <div class="admin-book-info-container">
                    @if($errors->has('bio'))
                        <p class="error-msg">{{$errors->first('bio')}}</p>
                    @endif
                    <label for="" class="input-label">Author description</label>
                    @if($errors->has('bio'))
                    <textarea name="bio" id="text-area" class="admin-book-info-input signup-form-input-error" require />
                        
                    </textarea>
                    @else
                    <textarea name="bio" id="text-area" class="admin-book-info-input" require />
                        
                    </textarea>
                    @endif
                </div>
           
                <div  class="admin-book-info-container">
                    @if($errors->has('authorPhoto'))
                        <p class="error-msg">{{$errors->first('authorPhoto')}}</p>
                    @endif
                    <label for="" class="input-label">Choose New Photo</label>
                    @if($errors->has('authorPhoto'))
                    <input type="file" name="authorPhoto" class="admin-book-info-input signup-form-input-error" require />
                    @else
                    <input type="file" name="authorPhoto" class="admin-book-info-input" require />
                    @endif
                </div>


                <div class="admin-book-info-container">
                    <input type="submit" value="ADD" id="book-submit-btn" />
                </div>
            </form>
        </fieldset>
       
    @endif
</div>
<!-- <img src="{{asset('authors_photos/davidtamang_614959e708ded.jpg')}}"  /> -->

@endsection