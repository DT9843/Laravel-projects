@extends('admin.base')

@section('title') Add language @endsection


@section('body')

    <div class="admin-form-container">

        <fieldset>
        @if(isset($edit))
        <legend><h3>Edit language</h3></legend>
        
        <form action="/admin/edit/language/{{$language->id}}" method="POST">
            @csrf
            <div class="admin-book-info-container">
                @if($errors->has('language'))
                    <p class="error-msg">{{$errors->first('language')}}</p>
                @endif
                <label for=""  class="input-label">Language</label>
                @if($errors->has('language'))
                <input type="text" name="language" class="admin-book-info-input  signup-form-input-error"  require/>
                @else
                <input type="text" name="language" value="{{$language->language}}" class="admin-book-info-input" require/>
                @endif
            </div>

            <div class="admin-book-info-container">
                <input type="submit" class="admin-edit-btn" value="EDIT">
            </div>
        </form>

  

        @else
        <legend><h3>Add language</h3></legend>
        <div>

        </div>
        <form action="/save/language" method="POST">
            @csrf
            <div class="admin-book-info-container">
                @if($errors->has('language'))
                    <p class="error-msg">{{$errors->first('language')}}</p>
                @endif
                <label for=""  class="input-label">Language</label>
                @if($errors->has('language'))
                <input type="text" name="language"  class="admin-book-info-input  signup-form-input-error"  require/>
                @else
                <input type="text" name="language"  class="admin-book-info-input" require/>
                @endif
            </div>

            <div class="admin-book-info-container">
                <input type="submit" value="ADD" id="book-submit-btn"/>
            </div>
        </form>

        @endif

        </fieldset>
        @if(isset($edit))
            <div class="m-10">
                <a href="/admin/delete/language/{{$language->id}}"><button class="admin-delete-btn">DELETE</button></a>
            </div>
        @endif
    </div>

@endsection