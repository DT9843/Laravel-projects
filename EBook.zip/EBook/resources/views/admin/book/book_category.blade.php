@extends('admin.base')

@section('title') Add book categories @endsection

@section('body')
    <h1>Add book category</h1>
    <form action="/save/book/category" method = "POST">
        @csrf
        <div>
            <label for="">Choose book</label>
            <select name="book">
                <option value="">None</option>
                @foreach($books as $book)
                    <option value="{{$book -> id}}">{{$book -> title}}</option>
                @endforeach
            </select>
        </div>

        <div>
            <label for="">Choose category</label>
            <select name="category">
                <option value="">None</option>
                @foreach($categories as $category)
                    <option value="{{$category -> id}}">{{$category -> name}}</option>
                @endforeach
            </select>
        </div>
        <input type="submit">
    </form>

@endsection