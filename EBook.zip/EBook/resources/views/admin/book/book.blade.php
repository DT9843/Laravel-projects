@extends('admin.base')

@section('title') Add Book @endsection


@section('body')
<div class="admin-form-container">
    @if(isset($edit))
    <div>
        <form action="/admin/change/book/image/{{$book->id}}" method="POST" enctype="multipart/form-data">
            <fieldset>
                @csrf
                <legend><h3>Book Image</h3></legend>
                <div class="admin-book-info-container">
                    <img src="{{asset($book->image_path)}}" id="view-book-img" alt="">
                </div>
                <div class="admin-book-info-container">
                    @if($errors->has('bookImage'))
                        <p class="error-msg">{{$errors->first('bookImage')}}</p>
                    @endif
                    <label for=""  class="input-label">Choose new image</label>
                    @if($errors->has('bookImage'))
                    <input type="file" class="admin-book-info-input signup-form-input-error" name="bookImage" />
                    @else
                    <input type="file" class="admin-book-info-input" name="bookImage" />
                    @endif
                </div>
                <div class="admin-book-info-container">
                    <input type="submit" class="admin-edit-btn" value="CHANGE">
                </div>
            </fieldset>
        </form>
    <div>

    <div class="m-10">
        <form action="/admin/edit/book/info/{{$book->id}}" method="POST">
        <fieldset>
            <legend><h3>Book Info</h3></legend>

            @csrf
            <div class="admin-book-info-container">
                @if($errors->has('bookTitle'))
                    <p class="error-msg">{{$errors->first('bookTitle')}}</p>
                @endif
                <label for="" class="input-label">Title</label>
                @if($errors->has('bookTitle'))
                <input type="text" class="admin-book-info-input signup-form-input-error"  name="bookTitle"/>
                @else
                <input type="text" class="admin-book-info-input" name="bookTitle" value="{{$book->title}}"/>
                @endif
            </div>

            <div class="admin-book-info-container">
                @if($errors->has('bookPrice'))
                    <p class="error-msg">{{$errors->first('bookPrice')}}</p>
                @endif
                <label for="" class="input-label">Price</label>
                @if($errors->has('bookPrice'))
                <input type="number" class="admin-book-info-input signup-form-input-error" name="bookPrice"/>
                @else
                <input type="number" class="admin-book-info-input" name="bookPrice" value="{{$book->price}}"/>
                @endif
            </div>

            <div class="admin-book-info-container">
                @if($errors->has('bookDescription'))
                    <p class="error-msg">{{$errors->first('bookDescription')}}</p>
                @endif
                <label for="" class="input-label">Description</label>
                @if($errors->has('bookDescription'))
                <textarea name="bookDescription" class="admin-book-info-input signup-form-input-error"  id="text-area" >
        
                </textarea>
                @else
                <textarea name="bookDescription" class="admin-book-info-input"  id="text-area" >
                {{$book->description}}
                </textarea>
                @endif


            </div>

            <div class="admin-book-info-container">
                @if($errors->has('bookIsbnNo'))
                    <p class="error-msg">{{$errors->first('bookIsbnNo')}}</p>
                @endif
                <label for="" class="input-label">Isbn No</label>
                @if($errors->has('bookIsbnNo'))
                <input type="text" name="bookIsbnNo" class="admin-book-info-input signup-form-input-error" />
                @else
                <input type="text" name="bookIsbnNo" class="admin-book-info-input" value="{{$book->isbn_no}}"/>
                @endif
            </div>

            <div class="admin-book-info-container">
                @if($errors->has('bookInstock'))
                    <p class="error-msg">{{$errors->first('bookInstock')}}</p>
                @endif
                <label for="" class="input-label">In stock</label>
                @if($errors->has('bookInstock'))
                <input type="number" name="bookInstock" class="admin-book-info-input signup-form-input-error" />
                @else
                <input type="number" name="bookInstock" class="admin-book-info-input" value="{{$book->in_stock}}"/>
                @endif
            </div class="admin-book-info-container">

            <div class="admin-book-info-container">
                @if($errors->has('bookPublisher'))
                    <p class="error-msg">{{$errors->first('bookPublisher')}}</p>
                @endif
                <label for="" class="input-label">Select publisher</label>
                @if($errors->has('bookPublisher'))
                <select name="bookPublisher" class="admin-book-info-input signup-form-input-error" id="">
                @else
                <select name="bookPublisher" class="admin-book-info-input" id="">
                @endif
                    @foreach($publishers as $publisher)
                        @if($publisher->name === $book->publisher()->first()->name)
                        <option value="{{$publisher -> id}}" selected>{{$publisher -> name}}</option>
                        @else
                        <option value="{{$publisher -> id}}">{{$publisher -> name}}</option>
                        @endif
                    @endforeach
                </select>

            </div>

            <div class="admin-book-info-container">
                @if($errors->has('bookPublishedDate'))
                    <p class="error-msg">{{$errors->first('bookPublishedDate')}}</p>
                @endif
                <label for="" class="input-label">Published date</label>
                @if($errors->has('bookPublishedDate'))
                <input type="date" name="bookPublishedDate" class="admin-book-info-input signup-form-input-error"/>
                @else
                <input type="date" name="bookPublishedDate" class="admin-book-info-input" value="{{$book->published_at}}"/>
                @endif
            </div>

            <div class="admin-book-info-container">
                @if($errors->has('bookTotalPages'))
                    <p class="error-msg">{{$errors->first('bookTotalPages')}}</p>
                @endif
                <label for="" class="input-label">Total pages</label>
                @if($errors->has('bookTotalPages'))
                <input type="number" name="bookTotalPages" class="admin-book-info-input signup-form-input-error" />
                @else
                <input type="number" name="bookTotalPages" class="admin-book-info-input"  value="{{$book->total_pages}}"/>
                @endif
            </div>
            <div class="admin-book-info-container">
                <input type="submit" class="admin-edit-btn" value="EDIT">
            </div>
            </fieldset>
        </form>
    </div>

    <div class="m-10">
        <fieldset>
            <legend><h3>Book Authors</h3></legend>
                @if($errors->has('author_name'))
                    <p class="error-msg">{{$errors->first('author_name')}}</p>
                @endif
                @foreach($authors as $author)
                <form action="/admin/edit/book/author/{{$book->id}}/{{$author->id}}" method="POST">
                    @csrf
                    <div class="admin-book-info-container">
                        @if($errors->has('author_name'))
                        <input type="text" name="author_name"  class="admin-book-info-input signup-form-input-error" />
                        @else
                        <input type="text" name="author_name"  class="admin-book-info-input" value="{{$author->first_name}} {{$author->last_name}}">
                        @endif
                        <select id="admin-select-author" class="admin-select" onchange="edit(this)">
                            
                            @foreach($allauthors as $allauthor)
                                @if($allauthor->first_name === $author->first_name && $allauthor->last_name === $author->last_name)
                                <option value="{{$allauthor->first_name}} {{$allauthor->last_name}}" selected >{{$allauthor->first_name}} {{$allauthor->last_name}}</option>

                                @else
                                <option value="{{$allauthor->first_name}} {{$allauthor->last_name}}" >{{$allauthor->first_name}} {{$allauthor->last_name}}</option>
                                @endif
                            @endforeach
                        </select>


                    </div>
                    <div class="admin-book-info-container">
                        <input type="submit" class="admin-edit-sm-btn" value="EDIT">
                        <a href="/admin/delete/book/author/{{$book->id}}/{{$author->id}}"><button type="button" class="admin-delete-sm-btn">DELETE</button></a>
                    </div>
                </form> 
                @endforeach

            <select id="admin-select-author-hidden" style="display:none" class="admin-select" onchange="edit(this)">
                @foreach($allauthors as $allauthor)
                    <option value="{{$allauthor->first_name}} {{$allauthor->last_name}}" >{{$allauthor->first_name}} {{$allauthor->last_name}}</option> 
                @endforeach
            </select>

            <div class="admin-book-info-container">

                <button class="add" data-book-id="{{$book->id}}" onclick="newForm('admin-select-author-hidden', this)"><span class="add-sign">+</span> Add Author</button>

            </div>
        </fieldset>
    </div>

    <div class="m-10">
        <fieldset>
            <legend><h3>Book Languages</h3></legend>
            @if($errors->has('book-language'))
                <p class="error-msg">{{$errors->first('book-language')}}</p>
            @endif
            @foreach($languages as $language)
                <form action="/admin/edit/book/language/{{$book->id}}/{{$language->id}}" method="POST">
                    @csrf
                    <div class="admin-book-info-container">
                        @if($errors->has('book-language'))
                            <input type="text" name="book-language"  class="admin-book-info-input signup-form-input-error" >
                        @else
                        <input type="text" name="book-language"  class="admin-book-info-input" value="{{$language->language}}">
                        @endif
                        <select name="" id="admin-select-language" class="admin-select" onchange="edit(this)">
                            
                            @foreach($all_languages as $all_language)
                                @if($all_language->language === $language->language)
                                  <option value="{{$all_language->language}}" selected>{{$all_language->language}}</option>
                                @else
                                  <option value="{{$all_language->language}}">{{$all_language->language}}</option>
                                @endif
                               
                            @endforeach
                        </select>

                    </div>
                    <div class="admin-book-info-container">
                        <input type="submit" class="admin-edit-sm-btn" value="EDIT">
                        <a href="/admin/delete/book/language/{{$book->id}}/{{$language->id}}"><button type="button" class="admin-delete-sm-btn">DELETE</button></a>
                    </div>
                </form>
            @endforeach

            <select name="" id="admin-select-language-hidden" style="display:none" class="admin-select" onchange="edit(this)">
                @foreach($all_languages as $all_language)
                    <option value="{{$all_language->language}}">{{$all_language->language}}</option>
                @endforeach
            </select>
            <div class="admin-book-info-container">

                 <button class="add" data-book-id="{{$book->id}}" onclick="newForm('admin-select-language-hidden', this)"><span class="add-sign">+</span> Add Language</button>

            </div>
        </fieldset>
    </div>

    <div class="m-10">
        <fieldset>
            <legend><h3>Book Categories</h3></legend>
            @if($errors->has('book-category'))
                <p class="error-msg">{{$errors->first('book-category')}}</p>
            @endif
            @foreach($categories as $category)
                <form action="/admin/edit/book/category/{{$book->id}}/{{$category->id}}" method="POST">
                    @csrf
                    <div class="admin-book-info-container">
                        @if($errors->has('book-category'))
                        <input type="text" name="book-category" class="admin-book-info-input signup-form-input-error">
                        @else
                        <input type="text" name="book-category" class="admin-book-info-input" value="{{$category->name}}">
                        @endif
                        <select name=""  id="admin-select-category" class="admin-select" onchange="edit(this)">
                            @foreach($all_categories as $all_category)
                                @if($all_category -> name === $category->name)
                                <option value="{{$all_category->name}}" selected>{{$all_category->name}}</option>

                                @else
                                <option value="{{$all_category->name}}">{{$all_category->name}}</option>

                                @endif
                            @endforeach
                        </select>
                    </div>

                    <div class="admin-book-info-container">
                        <input type="submit" class="admin-edit-sm-btn" value="EDIT">
                        <a href="/admin/delete/book/category/{{$book->id}}/{{$category->id}}" ><button class="admin-delete-sm-btn" type="button">DELETE</button></a>
                    </div>
                </form>
                @endforeach
                <select name=""  id="admin-select-category-hidden" style="display:none" class="admin-select" onchange="edit(this)">
                    @foreach($all_categories as $all_category)
                        <option value="{{$all_category->name}}">{{$all_category->name}}</option>
                    @endforeach
                </select>
            <div class="admin-book-info-container">

                <button class="add" data-book-id="{{$book->id}}" onclick="newForm('admin-select-category-hidden', this)"><span class="add-sign">+</span> Add Category</button>

            </div>
        </fieldset>
    </div>
    <div class="m-10">
        <a href="/admin/delete/book/{{$book->id}}"><button class="admin-delete-btn">DELETE</button></a>
    </div>
    @else
    <fieldset>
    <legend><h3>Add Book</h3></legend>
    <form action="/save/book" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="admin-book-info-container">
            @if($errors->has('bookTitle'))
                <p class="error-msg">{{$errors->first('bookTitle')}}</p>
            @endif
            <label for="" class="input-label">Title</label>
            @if($errors->has('bookTitle'))
            <input type="text" name="bookTitle signup-form-input-error" class="admin-book-info-input"/>
            @else
            <input type="text" name="bookTitle" class="admin-book-info-input"/>
            @endif
        </div>

        <div  class="admin-book-info-container">
            @if($errors->has('bookPrice'))
                <p class="error-msg">{{$errors->first('bookPrice')}}</p>
            @endif
            <label for="" class="input-label">Price</label>
            @if($errors->has('bookPrice'))
            <input type="number" name="bookPrice signup-form-input-error" class="admin-book-info-input"/>
            @else
            <input type="number" name="bookPrice" class="admin-book-info-input"/>
            @endif
        </div>

        <div  class="admin-book-info-container">
            @if($errors->has('bookDescription'))
                <p class="error-msg">{{$errors->first('bookDescription')}}</p>
            @endif
            <label for="" class="input-label">Description</label>
            @if($errors->has('bookDescription'))
            <textarea name="bookDescription" id="text-area" class="admin-book-info-input signup-form-input-error">

            </textarea>
            @else
            <textarea name="bookDescription" id="text-area" class="admin-book-info-input">

            </textarea>
            @endif
        </div>

        <div  class="admin-book-info-container">
            @if($errors->has('bookIsbnNo'))
                <p class="error-msg">{{$errors->first('bookIsbnNo')}}</p>
            @endif
            <label for="" class="input-label">Isbn No</label>
            @if($errors->has('bookIsbnNo'))
            <input type="text" name="bookIsbnNo" class="admin-book-info-input signup-form-input-error" />
            @else
            <input type="text" name="bookIsbnNo" class="admin-book-info-input" />
            @endif
        </div>

        <div class="admin-book-info-container">
            @if($errors->has('bookInstock'))
                <p class="error-msg">{{$errors->first('bookInstock')}}</p>
            @endif
            <label for="" class="input-label">In stock</label>
            @if($errors->has('bookInstock'))
            <input type="number" name="bookInstock"  class="admin-book-info-input signup-form-input-error"/>
            @else
            <input type="number" name="bookInstock"  class="admin-book-info-input"/>
            @endif
        </div>

        <div class="admin-book-info-container">
            @if($errors->has('bookImage'))
                <p class="error-msg">{{$errors->first('bookImage')}}</p>
            @endif
            <label for="" class="input-label">Book image</label>
            @if($errors->has('bookImage'))
            <input type="file" name="bookImage" class="admin-book-info-input signup-form-input-error"/>
            @else
            <input type="file" name="bookImage" class="admin-book-info-input"/>
            @endif
        </div>

        <div class="admin-book-info-container">
            @if($errors->has('admin-author'))
                <p class="error-msg">{{$errors->first('admin-author')}}</p>
            @endif
            <label for="" class="input-label">Authors</label>
            @if($errors->has('admin-author'))
            <input type="text" name="admin-author" id="admin-book-author" placeholder="Eg. J.K Rowling/Michael Jackson" class="admin-book-info-input signup-form-input-error"/>
            @else
            <input type="text" name="admin-author" id="admin-book-author" placeholder="Eg. J.K Rowling/Michael Jackson" class="admin-book-info-input"/>
            @endif
            <select id="admin-select-author" class="admin-select" onchange="multiInput('author', this)">
                <option value="" selected>None</option>
                @foreach($authors as $author)
                    <option value="{{$author->first_name}} {{$author->last_name}}" >{{$author->first_name}} {{$author->last_name}}</option>
                @endforeach       
            </select>
            <button type="button" id="author-reset" >Reset</button>
        </div>

        <div class="admin-book-info-container">
            @if($errors->has('admin-category'))
                <p class="error-msg">{{$errors->first('admin-category')}}</p>
            @endif
            <label for="" class="input-label">Category</label>
            @if($errors->has('admin-category'))
            <input type="text" name="admin-category" id="admin-book-category" placeholder="Eg. Action/Adventure" class="admin-book-info-input signup-form-input-error" />
            @else
            <input type="text" name="admin-category" id="admin-book-category" placeholder="Eg. Action/Adventure" class="admin-book-info-input" />
            @endif
            <select id="admin-select-category" class="admin-select" onchange="multiInput('category', this)">
                <option value="" selected>None</option>
                @foreach($categories as $category)
                    <option value="{{$category->name}}" >{{$category->name}}</option>
                @endforeach
            </select>
            <button type="button" id="category-reset">Reset</button>
        </div>
        
        <div class="admin-book-info-container">
            @if($errors->has('admin-language'))
                <p class="error-msg">{{$errors->first('admin-language')}}</p>
            @endif
            <label for="" class="input-label">Language</label>
            @if($errors->has('admin-language'))
            <input type="text" name="admin-language" id="admin-book-language"  placeholder="Eg. English/Germany" class="admin-book-info-input signup-form-input-error" />
            else
            <input type="text" name="admin-language" id="admin-book-language"  placeholder="Eg. English/Germany" class="admin-book-info-input" />
            @endif
            <select id="admin-select-language" class="admin-select" onchange="multiInput('language', this)">
                <option value="" selected>None</option>
                @foreach($languages as $language)
                    <option value="{{$language->language}}" >{{$language->language}}</option>
                @endforeach
            </select>
            <button type="button" id="language-reset">Reset</button>
        </div>


        <div class="admin-book-info-container">
            @if($errors->has('bookPublisher'))
                <p class="error-msg">{{$errors->first('bookPublisher')}}</p>
            @endif
            <label for="" class="input-label">Select publisher</label>
            @if($errors->has('bookPublisher'))
            <select name="bookPublisher" class="admin-select signup-form-input-error" id="">
            @else
            <select name="bookPublisher" class="admin-select" id="">
            @endif
                <option value="" selected>None</option>
                @foreach($publishers as $publisher)
                    <option value="{{$publisher -> id}}">{{$publisher -> name}}</option>

                @endforeach
            </select>
           
        </div>

        <div class="admin-book-info-container">
            @if($errors->has('bookPublishedDate'))
                <p class="error-msg">{{$errors->first('bookPublishedDate')}}</p>
            @endif
            <label for="" class="input-label">Published date</label>
            @if($errors->has('bookPublishedDate'))
            <input type="date" name="bookPublishedDate" class="admin-book-info-input signup-form-input-error"/>
            @else
            <input type="date" name="bookPublishedDate" class="admin-book-info-input"/>
            @endif
        </div>

        <div class="admin-book-info-container">
            @if($errors->has('bookTotalPages'))
                <p class="error-msg">{{$errors->first('bookTotalPages')}}</p>
            @endif
            <label for="" class="input-label">Total pages</label>
            @if($errors->has('bookTotalPages'))
            <input type="number" name="bookTotalPages" class="admin-book-info-input signup-form-input-error"/>
            @else
            <input type="number" name="bookTotalPages" class="admin-book-info-input"/>
            @endif
        </div>
        
        <div class="admin-book-info-container">
            <input type="submit" value="ADD" id="book-submit-btn">
        </div>

    </form>
    </fieldset>
    @endif
</div>
<script src="{{asset('js/book.js')}}"></script>
@endsection