@extends('admin.base')

@section('title') Add book language @endsection

@section('body')

    <form action="/save/book/language" method="POST">
        @csrf
        <div>
            <label for="">Choose Book</label>
            <select name="book" id="">
                <option value="">None</option>
                @foreach($books as $book)
                    <option value="{{$book -> id}}"> {{$book -> title}}</option>
                @endforeach
            </select>
        </div>

        <div>
            <label for="">Choose language</label>
            <select name="language" id="">
                <option value="">None</option>
                @foreach($languages as $language)
                    <option value="{{$language -> id}}"> {{$language -> language}}</option>
                @endforeach
            </select>
        </div>
        <input type="submit">
    </form>

@endsection