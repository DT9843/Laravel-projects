@extends('admin.base')

@section('title') Admin home page @endsection


@section('body')


<div class="admin-form-container">

    <div class="models">

        <h3 class="models-head">Models</h3>
        <ul class="models-list">
            <li class="model"><a href="/admin/view/books" class="model-link">Books</a></li>
            <li class="model"><a href="/admin/view/authors" class="model-link">Authors</a></li>
            <li class="model"><a href="/admin/view/publishers" class="model-link">Publishers</a></li>
            <li class="model"><a href="/admin/view/languages" class="model-link">Languages</a></li>
            <li class="model"><a href="/admin/view/categories" class="model-link">Categories</a></li>
        </ul>

    </div>
</div>
    
    
   
  
@endsection