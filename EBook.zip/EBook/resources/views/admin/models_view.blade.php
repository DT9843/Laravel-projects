@extends('admin.base')

@section('title')  @endsection


@section('body')

<div class="admin-form-container">
    @if($message = Session::get('created'))
        {{$message}}
    @endif
    @if(isset($books))
        <a href="/add/book"><button class="add"><span class="add-sign">+</span> Add Book</button></a>
        <div class="admin-search-bar">
         <input type="search" data-url="{{url('/books')}}/" name="findBooks" placeholder="Search by Title" id="admin-search-input" autocomplete="off">
        </div>
    @elseif(isset($authors))
        <a href="/add/author"><button class="add"><span class="add-sign">+</span> Add Author</button></a>
        <div class="admin-search-bar">
         <input type="search" name="findBooks" placeholder="Search by Author Name" id="admin-search-input" autocomplete="off">
        </div>
    @elseif(isset($publishers))
        <a href="/add/publisher"><button class="add"><span class="add-sign">+</span> Add Publisher</button></a>
        <div class="admin-search-bar">
         <input type="search" name="findBooks" placeholder="Search Publisher" id="admin-search-input" autocomplete="off">
        </div>
    @elseif(isset($languages))
        <a href="/add/language"><button class="add"><span class="add-sign">+</span> Add Language</button></a>
        <div class="admin-search-bar">
         <input type="search" name="findBooks" placeholder="Search Language" id="admin-search-input" autocomplete="off">
        </div>
    @elseif(isset($categories))
        <a href="/add/category"><button class="add"><span class="add-sign">+</span> Add Category</button></a>
        <div class="admin-search-bar">
         <input type="search" name="findBooks" placeholder="Search by Category" id="admin-search-input" autocomplete="off">
        </div>
    @endif



    <div class="model-scroll m-10">
    <table class="model-table">
            <thead >
        @if(isset($books))
                <tr >
                    <th class="model-th">Title</th>
                    <th class="date-th">Created At</th>
                    <th class="date-th">Update At</th>
                </tr>
            </thead>
            <tbody class="model-body">
                @foreach($books as $book)
                    <tr class="model-data-row">
                        <td class="model-data"><a class="model-link" href="/view/book/{{$book->id}}">{{$book->title}}</a></td>
                        <td class="model-data">{{$book->created_at}}</td>
                        <td class="model-data">{{$book->updated_at}}</td>
                    </tr>
                @endforeach
            </tbody>
        @elseif(isset($authors))
                <tr>
                    <th class="model-th">Full Name</th>
                    <th class="date-th">Created At</th>
                    <th class="date-th">Update At</th>
                </tr>
            </thead>
            <tbody>
                @foreach($authors as $author)
                    <tr class="model-data-row">
                        <td class="model-data"><a class="model-link" href="/view/author/{{$author->id}}">{{$author->first_name}} {{$author->last_name}}</a></td>
                        <td class="model-data">{{$author->created_at}}</td>
                        <td class="model-data">{{$author->updated_at}}</td>
                    </tr>
                @endforeach
            </tbody>
        @elseif(isset($publishers))
                <tr>
                    <th class="model-th">Publisher</th>
                    <th class="date-th">Created At</th>
                    <th class="date-th">Update At</th>
                </tr>
            </thead>
            <tbody>
                @foreach($publishers as $publisher)
                    <tr class="model-data-row">
                        <td class="model-data"><a class="model-link" href="/view/publisher/{{$publisher->id}}">{{$publisher->name}}</a></td>
                        <td class="model-data">{{$publisher->created_at}}</td>
                        <td class="model-data">{{$publisher->updated_at}}</td>
                    </tr>
                @endforeach
            </tbody>
        @elseif(isset($languages))
                <tr>
                    <th class="model-th">Language</th>
                    <th class="date-th">Created At</th>
                    <th class="date-th">Update At</th>
                </tr>
            </thead>
            <tbody>
                @foreach($languages as $language)
                    <tr class="model-data-row">
                        <td class="model-data"><a class="model-link" href="/view/language/{{$language->id}}">{{$language->language}}</a></td>
                        <td class="model-data">{{$language->created_at}}</td>
                        <td class="model-data">{{$language->updated_at}}</td>
                    </tr>
                @endforeach
            </tbody>
        @elseif(isset($categories))
                <tr>
                    <th class="model-th">Category</th>
                    <th class="date-th">Created At</th>
                    <th class="date-th">Update At</th>
                </tr>
            </thead>
            <tbody>
                @foreach($categories as $category)
                    <tr class="model-data-row">
                        <td class="model-data"><a class="model-link" href="/view/category/{{$category->id}}">{{$category->name}}</a></td>
                        <td class="model-data">{{$category->created_at}}</td>
                        <td class="model-data">{{$category->updated_at}}</td>
                    </tr>
                @endforeach
            </tbody>
        @endif
    </table>
    </div>
</div>

<script src="{{asset('js/admin_search.js')}}"></script>


@endsection