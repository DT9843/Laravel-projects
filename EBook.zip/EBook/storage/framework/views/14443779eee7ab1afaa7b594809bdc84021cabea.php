

<?php $__env->startSection('title'); ?> Create author <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<div class="admin-form-container">

    <?php if(isset($edit)): ?>
    <div class="m-10">
        <fieldset>
            <legend><h3>Author Image</h3></legend>
            <form action="/admin/change/author/image/<?php echo e($author->id); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div  class="admin-book-info-container">
                    <img src="<?php echo e(asset($author->author_pic)); ?>" id="view-book-img" alt="">
                </div>
                <?php if($errors->has('authorPhoto')): ?>
                    <p class="error-msg"><?php echo e($errors->first('authorPhoto')); ?></p>
                <?php endif; ?>
                <div  class="admin-book-info-container">
                    <label for="" class="input-label">Choose New Photo</label>
                    <?php if($errors->has('authorPhoto')): ?>
                    <input type="file" name="authorPhoto" class="admin-book-info-input signup-form-input-error" require />
                    <?php else: ?>
                    <input type="file" name="authorPhoto" class="admin-book-info-input" require />
                    <?php endif; ?>
                </div>

                <div  class="admin-book-info-container">
                    <input type="submit" class="admin-edit-btn" value="CHANGE">
                </div>
            </form>
        </fieldset>
    </div>

    <div class="m-10">

        <fieldset>

            <legend><h3>Author Info</h3></legend>
            <form action="/admin/edit/author/info/<?php echo e($author->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="admin-book-info-container">
                    <?php if($errors->has('firstName')): ?>
                        <p class="error-msg"><?php echo e($errors->first('firstName')); ?></p>
                    <?php endif; ?>
                    <label for="" class="input-label">First Name</label>
                    <?php if($errors->has('firstName')): ?>
                    <input type="text" class="admin-book-info-input signup-form-input-error" name="firstName" require />
                    <?php else: ?>
                    <input type="text" class="admin-book-info-input" value="<?php echo e($author->first_name); ?>" name="firstName" require />
                    <?php endif; ?>
                </div>

                <div class="admin-book-info-container">
                    <?php if($errors->has('lastName')): ?>
                        <p class="error-msg"><?php echo e($errors->first('lastName')); ?></p>
                    <?php endif; ?>
                    <label for="" class="input-label">Last Name</label>
                    <?php if($errors->has('lastName')): ?>
                    <input type="text" class="admin-book-info-input signup-form-input-error" name="lastName" require />
                    <?php else: ?>
                    <input type="text" class="admin-book-info-input" value="<?php echo e($author->last_name); ?>" name="lastName" require />
                    <?php endif; ?>
                </div>

                <div class="admin-book-info-container">
                    <?php if($errors->has('bio')): ?>
                        <p class="error-msg"><?php echo e($errors->first('bio')); ?></p>
                    <?php endif; ?>
                    <label for="" class="input-label">Author description</label>
                    <?php if($errors->has('bio')): ?>
                    <textarea name="bio" id="text-area" class="admin-book-info-input signup-form-input-error" require />
                        
                    </textarea>
                    <?php else: ?>
                    <textarea name="bio" id="text-area" class="admin-book-info-input" require />
                        <?php echo e($author->bio); ?>

                    </textarea>
                    <?php endif; ?>
                </div>

                <div class="admin-book-info-container">
                    <input type="submit" class="admin-edit-btn" value="EDIT">
                </div>

            </form>
        </fieldset>

    </div>
    <div class="m-10">
        <a href="/admin/delete/author/<?php echo e($author->id); ?>"><button class="admin-delete-btn">DELETE</button></a>
    </div>
    <?php else: ?>

        <fieldset>
            <legend><h3>Add author</h3></legend>

            <form action='/save/author' method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="admin-book-info-container">
                    <?php if($errors->has('firstName')): ?>
                        <p class="error-msg"><?php echo e($errors->first('firstName')); ?></p>
                    <?php endif; ?>
                    <label for="" class="input-label">First Name</label>
                    <?php if($errors->has('firstName')): ?>
                    <input type="text" class="admin-book-info-input signup-form-input-error" name="firstName" require />
                    <?php else: ?>
                    <input type="text" class="admin-book-info-input"  name="firstName" require />
                    <?php endif; ?>
                </div>

                <div class="admin-book-info-container">
                    <?php if($errors->has('lastName')): ?>
                        <p class="error-msg"><?php echo e($errors->first('lastName')); ?></p>
                    <?php endif; ?>
                    <label for="" class="input-label">Last Name</label>
                    <?php if($errors->has('lastName')): ?>
                    <input type="text" class="admin-book-info-input signup-form-input-error" name="lastName" require />
                    <?php else: ?>
                    <input type="text" class="admin-book-info-input"  name="lastName" require />
                    <?php endif; ?>
                </div>

                <div class="admin-book-info-container">
                    <?php if($errors->has('bio')): ?>
                        <p class="error-msg"><?php echo e($errors->first('bio')); ?></p>
                    <?php endif; ?>
                    <label for="" class="input-label">Author description</label>
                    <?php if($errors->has('bio')): ?>
                    <textarea name="bio" id="text-area" class="admin-book-info-input signup-form-input-error" require />
                        
                    </textarea>
                    <?php else: ?>
                    <textarea name="bio" id="text-area" class="admin-book-info-input" require />
                        
                    </textarea>
                    <?php endif; ?>
                </div>
           
                <div  class="admin-book-info-container">
                    <?php if($errors->has('authorPhoto')): ?>
                        <p class="error-msg"><?php echo e($errors->first('authorPhoto')); ?></p>
                    <?php endif; ?>
                    <label for="" class="input-label">Choose New Photo</label>
                    <?php if($errors->has('authorPhoto')): ?>
                    <input type="file" name="authorPhoto" class="admin-book-info-input signup-form-input-error" require />
                    <?php else: ?>
                    <input type="file" name="authorPhoto" class="admin-book-info-input" require />
                    <?php endif; ?>
                </div>


                <div class="admin-book-info-container">
                    <input type="submit" value="ADD" id="book-submit-btn" />
                </div>
            </form>
        </fieldset>
       
    <?php endif; ?>
</div>
<!-- <img src="<?php echo e(asset('authors_photos/davidtamang_614959e708ded.jpg')); ?>"  /> -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/admin/book/author.blade.php ENDPATH**/ ?>