<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet"  href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <?php echo $__env->yieldContent('css'); ?>
   <?php echo $__env->yieldContent('head'); ?>
</head>
<body>
   

    <div class="nav-bar">

        <div id="logo">
            <h1>Bookbhandar</h1>
        </div>

        
        <nav class="nav-links">
            <ul>
                <li class="nav-link"><a href="/home"><i class="fa fa-home nav-icon"></i>Home</a></li>
                <li class="nav-link" id="category">Category<i class="fa fa-angle-down drop-icon"></i>
                    <div id="category-list" class="drop-down-hide">
                        <ul>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="/view/all/books/Category/<?php echo e($category -> name); ?>"><?php echo e($category -> name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </li>
                <li class="nav-link"><a href="/cart" id="cart-link"><i class="fa fa-shopping-cart nav-icon"></i>Cart 
                <?php if($userCartTotalQty): ?>
                <span id="cart-link-qty"><?php echo e($userCartTotalQty); ?></span>
                <?php endif; ?>
                </a></li>

                <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                    <li class="nav-link"><a href="/logout"><i class="fa fa-sign-out nav-icon"></i>Logout</a></li>
                    <?php else: ?>
                    <li class="nav-link"><a href="/login"><i class="fa fa-sign-in nav-icon"></i>Login</a></li>

                    <?php if(Route::has('signup')): ?>
                    <li class="nav-link"><a href="/signup"><i class="fa fa-user-plus nav-icon"></i>Sign-Up</a></li>
                    <?php endif; ?>

                    <?php endif; ?>
                
                <?php endif; ?>
            </ul>
        </nav>

        <div class="search-bar">
            <form action="" method="POST">
                <input type="search" name="findBooks" placeholder="Search by Title/ISBN" id="search-input" autocomplete="off">

               
                <button id="search-btn">
                     <i class="fa fa-search"></i>
                </button>
            </form>
            <div class="search-results search-results-hidden" id="search-results">
                <!-- <a href="" class="search-item-link">
                    <div class="search-items">
                        <img src="http://127.0.0.1:8000/books_photos/A%20Promised%20Land_617a5ada8fc5e.jpg" width="70px" height="100px" alt="">

                        <div>
                            <h3>Harry Potter and the Philosopher's Stone</h3>
                            <p>by J.K Rowling</p>
                        </div>
                    </div>
                </a>

                <a href="" class="search-item-link">
                    <div class="search-items">
                        <img src="http://127.0.0.1:8000/books_photos/A%20Promised%20Land_617a5ada8fc5e.jpg" width="70px" height="100px" alt="">

                        <div>
                            <h3>Harry Potter and the Philosopher's Stone</h3>
                            <p>by J.K Rowling</p>
                        </div>
                    </div>
                </a> -->
            </div>
        </div>


    </div>

    <?php echo $__env->yieldContent('body'); ?>



    <script src="<?php echo e(asset('js/search.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dropdown.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/base.blade.php ENDPATH**/ ?>