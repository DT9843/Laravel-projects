

<?php $__env->startSection('title'); ?> Add language <?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

    <div class="admin-form-container">

        <fieldset>
        <?php if(isset($edit)): ?>
        <legend><h3>Edit language</h3></legend>
        
        <form action="/admin/edit/language/<?php echo e($language->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="admin-book-info-container">
                <?php if($errors->has('language')): ?>
                    <p class="error-msg"><?php echo e($errors->first('language')); ?></p>
                <?php endif; ?>
                <label for=""  class="input-label">Language</label>
                <?php if($errors->has('language')): ?>
                <input type="text" name="language" class="admin-book-info-input  signup-form-input-error"  require/>
                <?php else: ?>
                <input type="text" name="language" value="<?php echo e($language->language); ?>" class="admin-book-info-input" require/>
                <?php endif; ?>
            </div>

            <div class="admin-book-info-container">
                <input type="submit" class="admin-edit-btn" value="EDIT">
            </div>
        </form>

  

        <?php else: ?>
        <legend><h3>Add language</h3></legend>
        <div>

        </div>
        <form action="/save/language" method="POST">
            <?php echo csrf_field(); ?>
            <div class="admin-book-info-container">
                <?php if($errors->has('language')): ?>
                    <p class="error-msg"><?php echo e($errors->first('language')); ?></p>
                <?php endif; ?>
                <label for=""  class="input-label">Language</label>
                <?php if($errors->has('language')): ?>
                <input type="text" name="language"  class="admin-book-info-input  signup-form-input-error"  require/>
                <?php else: ?>
                <input type="text" name="language"  class="admin-book-info-input" require/>
                <?php endif; ?>
            </div>

            <div class="admin-book-info-container">
                <input type="submit" value="ADD" id="book-submit-btn"/>
            </div>
        </form>

        <?php endif; ?>

        </fieldset>
        <?php if(isset($edit)): ?>
            <div class="m-10">
                <a href="/admin/delete/language/<?php echo e($language->id); ?>"><button class="admin-delete-btn">DELETE</button></a>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/admin/book/language.blade.php ENDPATH**/ ?>