

<?php $__env->startSection('title'); ?> Add books authors <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <form action="/save/book/author" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="">Select book</label>
            <select name="book" id="">
                <option value="">None</option>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($book -> id); ?>"><?php echo e($book -> title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        </div>
  
        <div>
            <label for="">Select author</label>
            <select name="author" id="">
                <option value="">None</option>
                <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($author->id); ?>"><?php echo e($author ->first_name); ?>,<?php echo e($author -> last_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        </div>
    <input type="submit">
    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/admin/book/book_author.blade.php ENDPATH**/ ?>