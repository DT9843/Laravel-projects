<footer>

    <div>

        <div class="footer-flex flex-gap">
            <div>
                <h3 class="mb-10">ABOUT BOOKBHANDAR</h3>
                <p>BookBhandar is an online bookstore, physically based in Kathmandu, 
                Nepal, with an aim to create the largest community of book readers in Nepal.
                News and events At Booksmandala, you can browse and buy books online at the lowest 
                everyday prices.</p>
            </div>

            <div >
                <h3 class="w-100 mb-10">QUICK LINKS</h3>
                <ul class="footer-links">
                    <li> <a href="" class="footer-link">Best Sellers</a> </li>
                    <li> <a href="" class="footer-link">New Arrivals</a> </li>
                </ul>
            </div>

            <div>
                <h3 class="mb-10">OTHERS</h3>
                <ul class="footer-links">
                    <li> <a href="/aboutus" class="footer-link">About Us</a></li>
                    <!-- <li><a href="" class="footer-link">FAQ'S</a></li> -->
                </ul>
            </div>

            <div>

                <h3  class="w-300 mb-10">Submit your email address to receive BooksBhandar offers and updates</h3>
                <form action="">
                    <label for="email"> Subscribe to our newsletter</label>
                    <input type="email" name="email" id="email">
                    <input type="submit" id="subscribe" value="SUBSCRIBE">
                </form>
            </div>

        </div>
        
        <div class="footer-flex border">

            <h3>Connect With Us: <span href="#" class="fa fa-facebook"></span>
                <span href="#" class="fa fa-twitter"></span> 
                <span href="#" class="fa fa-instagram"></span></h3>

        </div>
        
        <div class="footer-flex">
            <div>
                <h3 class="mb-10">BookBhandar</h3>
                <p>Discover Something New!</p>
            </div>

            <div class="w-300">
                <p class="mb-10"><b>PHYSICAL STORE</b></p>
                <p>Nepal Book Bhandar Shop, Chandol Kathmandu</p>
                <p>bookBhandar@gmail.com</p>
                <p>+977-9843282376, +977-9854393487</p>
                <p>PO Box Number: 92</p>
            </div>
        </div>

    </div>

    <div class="developer">
        Developed By Herald IT Solutions Pvt.Ltd.
    </div>

</footer><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/footer.blade.php ENDPATH**/ ?>