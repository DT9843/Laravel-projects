

<?php $__env->startSection('title'); ?> Add publisher <?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

<div class="admin-form-container">
    <fieldset>
        <?php if(isset($edit)): ?>
        <legend><h3>Publisher Info</h3></legend>
        <form action="/admin/edit/publisher/<?php echo e($publisher->id); ?>" method="POST">
        <?php else: ?>
        <legend><h3>Add Publisher</h3></legend>
        <form action="/save/publisher" method="POST">
        <?php endif; ?>

        <?php echo csrf_field(); ?>
        <div class="admin-book-info-container">
        <?php if($errors->has('publisherName')): ?>
            <p class="error-msg"><?php echo e($errors->first('publisherName')); ?></p>
        <?php endif; ?>
            <label for="" class="input-label">Publisher Name</label>
            <?php if(isset($edit)): ?>
                <?php if($errors->has('publisherName')): ?>
                <input type="text" name="publisherName" value="<?php echo e($publisher->name); ?>"  class="admin-book-info-input signup-form-input-error" require />
                <?php else: ?>
                <input type="text" name="publisherName" value="<?php echo e($publisher->name); ?>"  class="admin-book-info-input" require />
                <?php endif; ?>
          
            <?php else: ?>
                <?php if($errors->has('publisherName')): ?>
                    <input type="text" name="publisherName"   class="admin-book-info-input signup-form-input-error" require />
                <?php else: ?>
                    <input type="text" name="publisherName"   class="admin-book-info-input" require />
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="admin-book-info-container">
            <?php if(isset($edit)): ?>
            
                <input type="submit" class="admin-edit-btn" value="EDIT">
            <?php else: ?>
                <input type="submit" value="ADD" id="book-submit-btn"/>
            <?php endif; ?>
        </div>
        
    </form>

       
    </fieldset>
    <?php if(isset($edit)): ?>
    <div class="m-10">
        <a href="/admin/delete/publisher/<?php echo e($publisher->id); ?>"><button class="admin-delete-btn">DELETE</button></a>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/admin/book/publisher.blade.php ENDPATH**/ ?>