

<?php $__env->startSection('title'); ?> Admin home page <?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>


<div class="admin-form-container">

    <div class="models">

        <h3 class="models-head">Models</h3>
        <ul class="models-list">
            <li class="model"><a href="/admin/view/books" class="model-link">Books</a></li>
            <li class="model"><a href="/admin/view/authors" class="model-link">Authors</a></li>
            <li class="model"><a href="/admin/view/publishers" class="model-link">Publishers</a></li>
            <li class="model"><a href="/admin/view/languages" class="model-link">Languages</a></li>
            <li class="model"><a href="/admin/view/categories" class="model-link">Categories</a></li>
        </ul>

    </div>
</div>
    
    
   
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/admin/index.blade.php ENDPATH**/ ?>