


<?php $__env->startSection('title'); ?>About us <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="container">
    <div class="w-30 aboutus-buttons f-left d-inline">
        <button id="aboutus-button-1" class="aboutus-button btn-activated">Nepal BookBhandar Book Shop</button>
        <button id="aboutus-button-2" class="aboutus-button">BookBhandar</button>
        <button id="aboutus-button-3" class="aboutus-button">Contact Us</button>
    </div>

    <div class="w-70 d-inline ml-20">

        <div id="aboutUs">
            <div>
                <h1>About Book Bhandar Shop:</h1>
                <p class="p-align p-lineheight">As of the present moment, Nepal Bhandar Book Shop is the sole vendor of Book Bhandar 
                and a local bookstore, based at Chandol, Kathmandu. Since 1991, Nepal Book Bhandar Book Shop 
                has existed as a tiny island of peace in a fast-moving world. Thriving and growing every year,
                the business that started from a post-card board selling postcards to tourists in the heart 
                of Lakeside has grown to be one of the hidden jewels of Kathmandu with floor-to-ceiling stacks 
                of books and a generally inclusive vibe that makes it seem like a neighborhood spot for anyone
                and everyone. The bookshop is one of the largest book distributors in Nepal. The shelves store
                an endless choice of books and the catalogue is always growing. You can take time browsing the 
                seemingly endless selection of rare coffee table books and attractive souvenir items.</p>
            </div>
            <div class="mt-20">
                <h1 class="mt-20">Contact:</h1>
                <p><i class="fa fa-phone"></i>  +977-9843282376, +977-9854393487</p>
                <p><i class="fa fa-envelope"></i>  bookBhandar@gmail.com</p>
            </div>

            <div class="mt-20 mb-20">
                <h1>Store Location:</h1>
                <iframe   class="mt-20" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d882.8671280121536!2d85.33416122916982!3d27.733691785962844!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb1940a281dab1%3A0x5c18d9015f5abe51!2sChandol%2C%20Kathmandu%2044600!5e0!3m2!1sen!2snp!4v1639797108347!5m2!1sen!2snp" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>

        <div class="d-none" id="bookBhandar">
            <div>
                <h1>Your favorite online bookstore!</h1>
                <p class="p-align p-lineheight">At Book Bhandar, we embody everything you love about books. Our mission is
                to share the power of books and we connect books with people by making discovering 
                and buying books easy, entertaining, informative, and socially engaging. Discover new books,
                browse and buy books online at the lowest everyday prices.</p>
            </div>

            <div class="mt-20">
                <h1>Nepal's Largest Online Bookstore</h1>
                <p class="p-align p-lineheight">Taking advantage of the collection at Nepal Mandala book 
                shop, we offer more than 25K titles for immediate delivery to most places in Nepal and 
                worldwide -- that's more titles than any other online booksellers. While the concept 
                started with #bookstagramming the lofty collection at the book shop, Books Mandala has 
                come a long way and now, we mean different things for different people. For our team, 
                the aim is to create the largest community of book readers in Nepal. It is about helping 
                to foster the love of reading and supporting new authors and fellow-readers from all 
                corners of the globe because we believe that books have the power to transform the world 
                around us. For our customers, we have tried to make Books Mandala the ultimate destination 
                for book lovers by offering an array of book related content. With so many titles, it is 
                vital to give customers an easy way to find precisely the books they are looking for.</p>

                <p class="p-align p-lineheight">Our search engine enables customers to locate books by title,
                author, or keyword in a few seconds at most. Customers with a general idea of what they browse
                pages through different categories to find exactly the right book. To further assist users, we
                offer descriptions, restock alerts for books that are out of stock and book requests as well as
                pre-order for books that are not available with us. It's also easy to stock shelves from the 
                comforts of home through our safe delivery system. We deliver to major cities of Nepal and 
                overseas.</p>
            </div>

            <div class="mt-20">
                <h1>Our Services</h1>
                <table class="mt-20">
                    <tbody>
                        <tr class="mb-10">
                            <td class="w-20"><img src="<?php echo e(asset('/logos/laptop.png')); ?>" class="services-img" alt=""></td>
                            <td class="w-90">
                                <h3>Buy Books Online</h3>
                                <p class="p-align p-lineheight">Easily discover new reads and stock your shelves at the comforts of your home through our safe delivery system. We deliver worldwide and to all districts in Nepal.</p>
                            </td>
                        </tr>
                        <tr class="mb-10">
                            <td class="w-20"><img src="<?php echo e(asset('/logos/book.png')); ?>" class="services-img" alt=""></td>
                            <td class="w-90">
                                <h3>Discover new books and people</h3>
                                <p class="p-align p-lineheight">Follow us at our socials to find book recommendations, discussion and more. We also have a community on Discord where bibliophiles can come together to talk about and share some of their favorite things: books.</p>
                            </td>
                        </tr>
                        <tr class="mb-10">
                            <td class="w-20"><img src="<?php echo e(asset('/logos/give_love.png')); ?>" class="services-img" alt=""></td>
                            <td class="w-90">
                                <h3>Request books</h3>
                                <p class="p-align p-lineheight">We also consider purchase requests for books that are not available with us. If any book you need is not in our collection, fill our book request form out and we’ll try our best to help you get it.</p>
                            </td>
                        </tr>
                        <tr class="mb-10">
                            <td class="w-20"><img src="<?php echo e(asset('/logos/note.png')); ?>" class="services-img" alt=""></td>
                            <td class="w-90">
                                <h3>Inspirational Content</h3>
                                <p class="p-align p-lineheight">We believe in co-creation and providing value to our customers so you will find more that just product promotions on our website and socials. Find beautiful stacks of books, well written blogs, inspirational quotes and take-away points.</p>
                            </td>
                        </tr>
                        <tr class="mb-10">
                            <td class="w-20"><img src="<?php echo e(asset('/logos/handshake.png')); ?>" class="services-img" alt=""></td>
                            <td class="w-90">
                                <h3>Deals and giveaways</h3>
                                <p class="p-align p-lineheight">Yes, it’s possible to win free stuff and gift cards at Books Mandala. Find the best bargains through our deals and get connected to discover quizzes, giveaways, contests and more!</p>
                            </td>
                        </tr>
                        <tr class="mb-10">
                            <td class="w-20"><img src="<?php echo e(asset('/logos/mike.png')); ?>" class="services-img" alt=""></td>
                            <td class="w-90">
                                <h3>Promote your book</h3>
                                <p class="p-align p-lineheight">If you are an author, promoting and marketing your book is vital to success. We can help promote your book by providing the exposure it needs and connect you to hungry readers and book buyers.</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

        </div>
        
        <div class="d-none" id="contactUs">
            <h1>Contact Us</h1>
            <form action="" method="POST">
                        
                <input type="text"class="admin-book-info-input" placeholder="Full Name">
                <input type="email"class="admin-book-info-input" placeholder="email">
                <input type="number"class="admin-book-info-input" placeholder="Phone Number">
                <input type="text"class="admin-book-info-input" placeholder="Subject">
                <textarea name=""class="admin-book-info-input" id="text-area" placeholder=" ">Write Message Here...
                </textarea>
                <input type="submit" value="CONTACT US" id="subscribe">
            </form>

        </div>
    
    </div>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('js/aboutus.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/aboutus.blade.php ENDPATH**/ ?>