

<?php $__env->startSection('title'); ?> Add book language <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <form action="/save/book/language" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="">Choose Book</label>
            <select name="book" id="">
                <option value="">None</option>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($book -> id); ?>"> <?php echo e($book -> title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label for="">Choose language</label>
            <select name="language" id="">
                <option value="">None</option>
                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($language -> id); ?>"> <?php echo e($language -> language); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <input type="submit">
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/admin/book/book_language.blade.php ENDPATH**/ ?>