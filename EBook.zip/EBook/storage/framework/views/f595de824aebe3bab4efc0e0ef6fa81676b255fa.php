

<?php $__env->startSection('title'); ?> Add book categories <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <h1>Add book category</h1>
    <form action="/save/book/category" method = "POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="">Choose book</label>
            <select name="book">
                <option value="">None</option>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($book -> id); ?>"><?php echo e($book -> title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label for="">Choose category</label>
            <select name="category">
                <option value="">None</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category -> id); ?>"><?php echo e($category -> name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <input type="submit">
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/admin/book/book_category.blade.php ENDPATH**/ ?>