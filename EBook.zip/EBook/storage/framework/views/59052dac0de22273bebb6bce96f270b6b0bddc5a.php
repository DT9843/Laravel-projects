


<?php $__env->startSection('head'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?> View cart <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<?php if($userCartTotalQty > 0): ?>
    <div class="cart-container" id="cart-container">
<?php else: ?>
    <div class="cart-container cart-container-visibility" id="cart-container">
<?php endif; ?>
        <div class="cart-list">
            <div class="price-qty-info">
                <h3>MY CART</h3>
                <h3>PRICE</h3>
            </div>

<!-- ==========================================================================-->
        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
            <div class="cart-items" id="<?php echo e($cartItem->id); ?>">

                <div class="item-img">
                    <img src="<?php echo e(asset($cartItem->image_path)); ?>" height="100px" width="60px" alt="">
                </div>

                <div class="qty-info">
                    <h3 class="cart-title"><?php echo e($cartItem->title); ?></h3>
                    <p>by
                    <?php for($authors = 0; $authors < count($cartItem->author()->get()); $authors++ ): ?>

                        <?php if( $authors + 1 === count($cartItem->author()->get()) - 1 ): ?>
                            <?php echo e($cartItem->author()->get()[$authors]->first_name); ?> <?php echo e($cartItem->author()->get()[$authors]->last_name); ?> and

                        <?php elseif($authors + 1 < count($cartItem->author()->get()) - 1): ?>
                            <?php echo e($cartItem->author()->get()[$authors]->first_name); ?> <?php echo e($cartItem->author()->get()[$authors]->last_name); ?> ,

                        <?php else: ?>
                            <?php echo e($cartItem->author()->get()[$authors]->first_name); ?> <?php echo e($cartItem->author()->get()[$authors]->last_name); ?>.

                        <?php endif; ?>

                    <?php endfor; ?>

                    </p>

                    <div class="qty">
                        
                          
                        <button id="increment" onclick="increment('<?php echo e($cartItem->id); ?>')">+</button>
                        <input type="number" name="qty" id="qty-no" value="<?php echo e($cartItem->pivot->quantity); ?>" onclick="qtyNo(this, '<?php echo e($cartItem->id); ?>')">
                        <button id="decrement" onclick="decrement('<?php echo e($cartItem->id); ?>')">-</button>
                      
                    </div>

                    <div class="cart-action" >
                        <button id="delete" onclick="deleteCartItem('<?php echo e($cartItem->id); ?>')">delete</button>
                        <button class="update" onclick="updateItemQty('<?php echo e($cartItem->id); ?>')">update</button>
                    </div>
                </div>

                <div class="price-info">
                    <p>NPR.<span><?php echo e($cartItem->price*$cartItem->pivot->quantity); ?></span></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- ==========================================================================-->


        </div>

        <div class="checkout-info">

            <h3>Your Order Summary</h3>
            <div class="book-prices" id="cart-qty-price-info">
                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="book-price">
                        <p class="book-price-child"><b><span><?php echo e($cartItem->pivot->quantity); ?></span> X</b> <?php echo e($cartItem->title); ?></p>
                        <p>NPR.<?php echo e($cartItem->price*$cartItem->pivot->quantity); ?></p>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
               
            </div>

            <div class="total-amt">
                <p>Total Amount</p>
                <p id="total-price">NPR.<?php echo e($totalAmt); ?></p>
            </div>
            
            <a href="" class="chkout-btn"><button>CHECK OUT</button></a>
        </div>
</div>

<?php if($userCartTotalQty < 1): ?>
    <div class="empt-cart-container" id="empt-cart-container">
<?php else: ?>
    <div class="empt-cart-container cart-container-visibility" id="empt-cart-container">
<?php endif; ?>

       <img src="<?php echo e(asset('cart_pic/empty_cart.png')); ?>" height="325px" width="325px"alt=""> 
        <div class="empty-cart-info">
            <h1>Your cart is empty !</h1>

            <div class="empty-cart-para">
                <p>Looks like you have no items in your shopping cart.</p>
                <p>Explore around to add some items.</p>
            </div>

            <div class="browse-btn">
                <a href="">
                    <button>
                        Browse Books
                    </button>
                </a>
            </div>

        </div>
    </div>  

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('js/cart.js')); ?>"></script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/cart.blade.php ENDPATH**/ ?>