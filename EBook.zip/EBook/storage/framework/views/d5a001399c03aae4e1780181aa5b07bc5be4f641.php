

<?php $__env->startSection('title'); ?> Add category <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="admin-form-container">
    <fieldset>
    <?php if(isset($edit)): ?>
    <legend><h3>Category Info</h3></legend>
    <form action="/admin/edit/category/<?php echo e($category->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="admin-book-info-container">
            <?php if($errors->has('category')): ?>
                <p class="error-msg"><?php echo e($errors->first('category')); ?></p>
            <?php endif; ?>
            <label for="" class="input-label">Category</label>
            <?php if($errors->has('category')): ?>
            <input type="text" name="category" class="admin-book-info-input signup-form-input-error" value="<?php echo e($category->name); ?>" >

            <?php else: ?>
            <input type="text" name="category" class="admin-book-info-input" value="<?php echo e($category->name); ?>" >
            <?php endif; ?>
        </div>

        <div class="admin-book-info-container">
            <input type="submit" class="admin-edit-btn" value="EDIT">
        </div>

    </form>

    <?php else: ?>
    <legend><h3>Add Category</h3></legend>
    <form action="/save/category" method="POST">
        <?php echo csrf_field(); ?>
        <div class="admin-book-info-container">
            <?php if($errors->has('category')): ?>
                <p class="error-msg"><?php echo e($errors->first('category')); ?></p>
            <?php endif; ?>
            <label for="" class="input-label">Category</label>
            <?php if($errors->has('category')): ?>
            <input type="text" name="category" class="admin-book-info-input signup-form-input-error" >

            <?php else: ?>
            <input type="text" name="category" class="admin-book-info-input" >
            <?php endif; ?>
        </div>

        <div class="admin-book-info-container">
            <input type="submit" value="ADD" id="book-submit-btn"/>
        </div>

    </form>

    <?php endif; ?>

    </fieldset>
    <?php if(isset($edit)): ?>
    <div class="m-10">
        <a href="/admin/delete/category/<?php echo e($category->id); ?>"><button class="admin-delete-btn">DELETE</button></a>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/admin/book/category.blade.php ENDPATH**/ ?>