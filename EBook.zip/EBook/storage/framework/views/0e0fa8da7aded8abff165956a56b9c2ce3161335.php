

<?php $__env->startSection('head'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?> Home <?php $__env->stopSection(); ?>

<!-- <?php $__env->startSection('css'); ?>  
    <link rel="stylesheet"  href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?> -->

<?php $__env->startSection('body'); ?>
    <div class="welcome">

        <h1 class="welcome-text">WELCOME TO BOOKBHANDAR</h1>

    </div>

    <div class="container">

        <div class="new-arrivals">
            <div class="common-heading">
                <h2>New Arrivals</h2>
                <a href="/view/all/books/New Arrivals">VIEW ALL</a>
                
            </div>

            <?php if(count($new_arrival_books) < 6): ?>
            <div class="new-arrivals-books">
            <?php else: ?>
            <div class="new-arrivals-books-2">
            <?php endif; ?>  
      
                <?php $__currentLoopData = $new_arrival_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new_book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="books" id="<?php echo e($new_book->id); ?>">
                    <img src="<?php echo e(asset($new_book -> image_path)); ?>" alt="" height="240px" width="158px">
                    <div class="book-info">
                      <a href="book/<?php echo e($new_book->title); ?>" class="title-link">  <h6 href="" class="title"><?php echo e($new_book -> title); ?></h6></a>
                        <!-- <p class="author"><b>by</b> <?php echo e($new_book->author()->first()->first_name); ?> <?php echo e($new_book->author()->first()->last_name); ?></p> -->
                        <p class="author"><b>by</b> 
                        <?php for($authors = 0; $authors < count($new_book->author()->get()); $authors++ ): ?>

                            <?php if( $authors + 1 === count($new_book->author()->get()) - 1 ): ?>
                               <?php echo e($new_book->author()->get()[$authors]->first_name); ?> <?php echo e($new_book->author()->get()[$authors]->last_name); ?> and

                            <?php elseif($authors + 1 < count($new_book->author()->get()) - 1): ?>
                               <?php echo e($new_book->author()->get()[$authors]->first_name); ?> <?php echo e($new_book->author()->get()[$authors]->last_name); ?> ,

                            <?php else: ?>
                               <?php echo e($new_book->author()->get()[$authors]->first_name); ?> <?php echo e($new_book->author()->get()[$authors]->last_name); ?>.

                            <?php endif; ?>


                        <?php endfor; ?>
                        
                        </p> 

                        <div>
                            <?php for($i=0; $i< 5; $i++): ?>
                                <?php if($new_book -> rating > $i): ?>
                                    <span class="fa fa-star checked rating"></span>
                                <?php else: ?>
                                    <span class="fa fa-star rating"></span>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </div>
                        <p class="price">NPR.<?php echo e($new_book -> price); ?></p>
                    </div>
                        <?php if(auth()->guard()->check()): ?>

                            <?php if(Auth::user()->book()->where('book_id',$new_book->id)->first()): ?>
                                <button class="cart-btn-view" onclick='window.location.href="<?php echo e(url('/cart')); ?>"' >
                                  View Cart
                                </button>
                            <?php else: ?>
                                <button class="cart-btn" onclick='addToCart("<?php echo e($new_book->title); ?>",this)'>
                                  Add To Cart
                                </button>
                            <?php endif; ?>
                        <?php else: ?>
                       
                            <button class="cart-btn" onclick='window.location.href="<?php echo e(url('/login')); ?>"'>Add To Cart</button>
                     

                        <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           

    
            </div>
            

        </div>
   </div>



   <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <script src="<?php echo e(asset('js/cart.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/index.blade.php ENDPATH**/ ?>