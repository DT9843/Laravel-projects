

<?php $__env->startSection('head'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>

    <?php echo e($book->title); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

    <div class="book-container">

        <div class="book-details">

            <div class="book-image">
                <img src="<?php echo e(asset($book->image_path)); ?>" alt="" width="250px" height="400px">
                <h3 class="book-amount">NPR.<?php echo e($book->price); ?></h3>

                <?php if(auth()->guard()->check()): ?>

                    <?php if(Auth::user()->book()->where('book_id',$book->id)->first()): ?>
                        <button class="cart-btn-view" onclick='window.location.href="<?php echo e(url('/cart')); ?>"' >
                            View Cart
                        </button>
                    <?php else: ?>
                        <button class="cart-btn" onclick='addToCart("<?php echo e($book->title); ?>",this)'>
                         Add To Cart
                        </button>
                    <?php endif; ?>

                <?php else: ?>

                    <button class="cart-btn" onclick='window.location.href="<?php echo e(url('/login')); ?>"'>Add To Cart</button>


                <?php endif; ?>
            </div>

            <div class="book-info">

                <h1 class="book-title"><?php echo e($book->title); ?></h1>
                <p class="book-authors">by
                <?php for($authors = 0; $authors < count($book->author()->get()); $authors++ ): ?>

                    <?php if( $authors + 1 === count($book->author()->get()) - 1 ): ?>
                        <?php echo e($book->author()->get()[$authors]->first_name); ?> <?php echo e($book->author()->get()[$authors]->last_name); ?> and

                    <?php elseif($authors + 1 < count($book->author()->get()) - 1): ?>
                        <?php echo e($book->author()->get()[$authors]->first_name); ?> <?php echo e($book->author()->get()[$authors]->last_name); ?> ,

                    <?php else: ?>
                        <?php echo e($book->author()->get()[$authors]->first_name); ?> <?php echo e($book->author()->get()[$authors]->last_name); ?>.

                    <?php endif; ?>

                <?php endfor; ?>
                </p>

                <table>

                    <tr>
                        <td> <h3 class="book-publisher">Rating:</h3></td>
                        <td class="book-ratings"> 
                            <?php for($i=0; $i< 5; $i++): ?>
                                <?php if($book -> rating > $i): ?>
                                    <span class="fa fa-star checked rating"></span>
                                <?php else: ?>
                                    <span class="fa fa-star rating"></span>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <b>(<?php echo e(count($book->userReview()->get())); ?>)</b>
                        </td>
                    </tr>

                    <tr>
                        <td> <h3 class="book-publisher">Publisher:</h3></td>
                        <td><p><?php echo e($book->publisher()->first()->name); ?></p></td>
                    </tr>

                    <tr>
                        <td><h3>Category:</h3></td>
                        <td><p>
                            <?php $__currentLoopData = $book->category()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($category->name); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p></td>
                    </tr>

                    <tr>
                        <td><h3>Published Date:</h3></td>
                        <td><p><?php echo e($book->published_at); ?></p></td>
                    </tr>

                    <tr>
                        <td><h3>Total Pages:</h3></td>
                        <td><p><?php echo e($book->total_pages); ?></p></td>
                    </tr>

                    <tr>
                        <td><h3>ISBN:</h3></td>
                        <td><p><?php echo e($book->isbn_no); ?></p></td>
                    </tr>

                    <tr>
                        <td><h3>Description</h3></td>
                        
                    </tr>

              
                </table>
                <tr>
            
                    <p class="book-description-para">
                        <?php echo e($book->description); ?>

                    </p>
                   
                </tr>
            </div>




        </div>

        <div class="user-review">
            <h2>Reviews</h2>
            <div class="reviews">
                <?php if(count($userReviews) > 0): ?>
                  
                    <?php $__currentLoopData = $userReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="review">
                            <div class="user-img">
                                <img src="<?php echo e(asset($review->profile_pic)); ?>" height="70px" width="70px" alt="">
                            </div>
                            <div class="comment">
                                <p class="post-details"><?php echo e($review->first_name); ?> <?php echo e($review->last_name); ?> - <?php echo e($review->created_at); ?></p>
                                <div class="user-given-rating">
                                    <?php for($i=0; $i< 5; $i++): ?>
                                        <?php if($review->pivot->rating > $i): ?>
                                            <span class="fa fa-star checked rating"></span>
                                        <?php else: ?>
                                            <span class="fa fa-star rating"></span>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                </div>
                                <p class="comment-text"><?php echo e($review->pivot->comment); ?></p>
                                
                                <?php if(Auth::user()): ?>
                                    <?php if(Auth::user()->id === $review->pivot->user_id): ?>
                                    <div class="comment-action">
                                        <a href="" class="comment-edit">EDIT</a>
                                        <a href="/delete/comment/<?php echo e($book->title); ?>/<?php echo e($review->pivot->id); ?>" class="comment-delete">DELETE</a>
                                    </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            
                         
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="no-reviews">
                        There are no comments yet.
                    </div>
                <?php endif; ?>
            </div>

            <div class="post-review">

                <?php if(auth()->guard()->check()): ?>
                    <form action="/book/<?php echo e($book->title); ?>" method="POST">

                        <?php echo csrf_field(); ?>
                        <div>
                            <label for="star-1" onmouseover="setRatingsColor(1)" onmouseleave="resetRatings()" onclick="setRatings(1)" ><span class="fa fa-star rating review-star"></span></label>
                            <input type="radio" name="rating" id="star-1" class="star-rating" value="1">
                            <label for="star-2" onmouseover="setRatingsColor(2)" onmouseleave="resetRatings()" onclick="setRatings(2)"><span class="fa fa-star rating review-star"></span></label>
                            <input type="radio" name="rating" id="star-2" class="star-rating" value="2">
                            <label for="star-3" onmouseover="setRatingsColor(3)" onmouseleave="resetRatings()" onclick="setRatings(3)"><span class="fa fa-star rating review-star"></span></label>
                            <input type="radio" name="rating" id="star-3" class="star-rating" value="3">
                            <label for="star-4" onmouseover="setRatingsColor(4)" onmouseleave="resetRatings()" onclick="setRatings(4)"><span class="fa fa-star rating review-star"></span></label>
                            <input type="radio" name="rating" id="star-4" class="star-rating" value="4">
                            <label for="star-5" onmouseover="setRatingsColor(5)" onmouseleave="resetRatings()" onclick="setRatings(5)"><span class="fa fa-star rating review-star"></span></label>
                            <input type="radio" id="star-5" name="rating" class="star-rating" value="5">
                            <div id="review-status">Give Ratings</div>
                        </div>

                        <div>
                            <label for="comment-box">Enter your message here:</label>
                            <textarea name="comment" id="comment-box" >

                            </textarea>
                        </div>

                        <input type="submit" value="SUBMIT" id="comment-submit-btn">

                    </form>

                    <button id="reset-btn">
                        RESET
                    </button>
                <?php else: ?>
                    <h3>Authentication Required</h3>
                    <p>You must login to post a comment</p>
                    <a href="/login"><button>LOG IN</button></a>
                <?php endif; ?>
            </div>

        </div>
        <!-- <p><?php echo e($book->calculateRatings()); ?></p>  -->
    </div>
    
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('js/cart.js')); ?>"></script>

    <?php if(auth()->guard()->check()): ?>
    <script src="<?php echo e(asset('js/review.js')); ?>"></script>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/book.blade.php ENDPATH**/ ?>