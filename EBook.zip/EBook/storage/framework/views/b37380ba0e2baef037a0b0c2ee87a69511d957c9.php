

<?php $__env->startSection('title'); ?>  <?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

<div class="admin-form-container">
    <?php if($message = Session::get('created')): ?>
        <?php echo e($message); ?>

    <?php endif; ?>
    <?php if(isset($books)): ?>
        <a href="/add/book"><button class="add"><span class="add-sign">+</span> Add Book</button></a>
        <div class="admin-search-bar">
         <input type="search" data-url="<?php echo e(url('/books')); ?>/" name="findBooks" placeholder="Search by Title" id="admin-search-input" autocomplete="off">
        </div>
    <?php elseif(isset($authors)): ?>
        <a href="/add/author"><button class="add"><span class="add-sign">+</span> Add Author</button></a>
        <div class="admin-search-bar">
         <input type="search" name="findBooks" placeholder="Search by Author Name" id="admin-search-input" autocomplete="off">
        </div>
    <?php elseif(isset($publishers)): ?>
        <a href="/add/publisher"><button class="add"><span class="add-sign">+</span> Add Publisher</button></a>
        <div class="admin-search-bar">
         <input type="search" name="findBooks" placeholder="Search Publisher" id="admin-search-input" autocomplete="off">
        </div>
    <?php elseif(isset($languages)): ?>
        <a href="/add/language"><button class="add"><span class="add-sign">+</span> Add Language</button></a>
        <div class="admin-search-bar">
         <input type="search" name="findBooks" placeholder="Search Language" id="admin-search-input" autocomplete="off">
        </div>
    <?php elseif(isset($categories)): ?>
        <a href="/add/category"><button class="add"><span class="add-sign">+</span> Add Category</button></a>
        <div class="admin-search-bar">
         <input type="search" name="findBooks" placeholder="Search by Category" id="admin-search-input" autocomplete="off">
        </div>
    <?php endif; ?>



    <div class="model-scroll m-10">
    <table class="model-table">
            <thead >
        <?php if(isset($books)): ?>
                <tr >
                    <th class="model-th">Title</th>
                    <th class="date-th">Created At</th>
                    <th class="date-th">Update At</th>
                </tr>
            </thead>
            <tbody class="model-body">
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="model-data-row">
                        <td class="model-data"><a class="model-link" href="/view/book/<?php echo e($book->id); ?>"><?php echo e($book->title); ?></a></td>
                        <td class="model-data"><?php echo e($book->created_at); ?></td>
                        <td class="model-data"><?php echo e($book->updated_at); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        <?php elseif(isset($authors)): ?>
                <tr>
                    <th class="model-th">Full Name</th>
                    <th class="date-th">Created At</th>
                    <th class="date-th">Update At</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="model-data-row">
                        <td class="model-data"><a class="model-link" href="/view/author/<?php echo e($author->id); ?>"><?php echo e($author->first_name); ?> <?php echo e($author->last_name); ?></a></td>
                        <td class="model-data"><?php echo e($author->created_at); ?></td>
                        <td class="model-data"><?php echo e($author->updated_at); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        <?php elseif(isset($publishers)): ?>
                <tr>
                    <th class="model-th">Publisher</th>
                    <th class="date-th">Created At</th>
                    <th class="date-th">Update At</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $publishers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publisher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="model-data-row">
                        <td class="model-data"><a class="model-link" href="/view/publisher/<?php echo e($publisher->id); ?>"><?php echo e($publisher->name); ?></a></td>
                        <td class="model-data"><?php echo e($publisher->created_at); ?></td>
                        <td class="model-data"><?php echo e($publisher->updated_at); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        <?php elseif(isset($languages)): ?>
                <tr>
                    <th class="model-th">Language</th>
                    <th class="date-th">Created At</th>
                    <th class="date-th">Update At</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="model-data-row">
                        <td class="model-data"><a class="model-link" href="/view/language/<?php echo e($language->id); ?>"><?php echo e($language->language); ?></a></td>
                        <td class="model-data"><?php echo e($language->created_at); ?></td>
                        <td class="model-data"><?php echo e($language->updated_at); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        <?php elseif(isset($categories)): ?>
                <tr>
                    <th class="model-th">Category</th>
                    <th class="date-th">Created At</th>
                    <th class="date-th">Update At</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="model-data-row">
                        <td class="model-data"><a class="model-link" href="/view/category/<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a></td>
                        <td class="model-data"><?php echo e($category->created_at); ?></td>
                        <td class="model-data"><?php echo e($category->updated_at); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        <?php endif; ?>
    </table>
    </div>
</div>

<script src="<?php echo e(asset('js/admin_search.js')); ?>"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/admin/models_view.blade.php ENDPATH**/ ?>