

<?php $__env->startSection('head'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection("title"); ?> View All Books <?php $__env->stopSection(); ?>


<?php $__env->startSection("body"); ?>

<div class="container">

    <div class="common-heading">
        <h2><?php echo e($str); ?></h2>
    </div>

<div class="new-arrivals">
    <?php if(count($books) < 6): ?>
    <div class="new-arrivals-books">
    <?php else: ?>
    <div class="new-arrivals-books-2">
    <?php endif; ?>    
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="books" id="<?php echo e($book->id); ?>">
          <img src="<?php echo e(asset($book -> image_path)); ?>" alt="" height="240px" width="158px">
            <div class="book-info">
               <a href="" class="title-link">  <h6 class="title"><?php echo e($book -> title); ?></h6></a>

              <p class="author"><b>by</b> 
                <?php for($authors = 0; $authors < count($book->author()->get()); $authors++ ): ?>

                    <?php if( $authors + 1 === count($book->author()->get()) - 1 ): ?>
                        <?php echo e($book->author()->get()[$authors]->first_name); ?> <?php echo e($book->author()->get()[$authors]->last_name); ?> and

                    <?php elseif($authors + 1 < count($book->author()->get()) - 1): ?>
                        <?php echo e($book->author()->get()[$authors]->first_name); ?> <?php echo e($book->author()->get()[$authors]->last_name); ?> ,

                    <?php else: ?>
                        <?php echo e($book->author()->get()[$authors]->first_name); ?> <?php echo e($book->author()->get()[$authors]->last_name); ?>.

                    <?php endif; ?>


                <?php endfor; ?>
                
                </p> 

                <div>
                    <?php for($i=0; $i< 5; $i++): ?>
                        <?php if($book -> rating > $i): ?>
                            <span class="fa fa-star checked rating"></span>
                        <?php else: ?>
                            <span class="fa fa-star rating"></span>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
                <p class="price">NPR.<?php echo e($book -> price); ?></p>
           </div>
                <?php if(auth()->guard()->check()): ?>

                    <?php if(Auth::user()->book()->where('book_id',$book->id)->first()): ?>
                        <button class="cart-btn-view" onclick='window.location.href="<?php echo e(url('/cart')); ?>"' >
                            View Cart
                        </button>
                    <?php else: ?>
                        <button class="cart-btn" onclick='addToCart("<?php echo e($book->title); ?>",this)'>
                            Add To Cart
                        </button>
                    <?php endif; ?>
                <?php else: ?>
                
                    <button class="cart-btn" onclick='window.location.href="<?php echo e(url('/login')); ?>"'>Add To Cart</button>
                

                <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </div>
    

</div>

    <div class="pages">

            <div class="page not-active page-decrement" id="page-decrement">
                &#9664;
            </div>

            <div class="page-no">
            <?php for($i=1; $i<=$totalPages; $i++): ?>
                <?php if($page === $i): ?>
                    <?php if(str_contains($str, 'Category')): ?>
                    <div class="page radio-activated" data-page="<?php echo e($i); ?>" data-url="<?php echo e(url('/book/page')); ?>/<?php echo e(str_replace(': ','/$i/',$str)); ?>" onclick="pageSwitch(this)">
                    <?php elseif(str_contains($str, 'New Arrivals')): ?>
                    <div class="page radio-activated" data-page="<?php echo e($i); ?>" data-url="<?php echo e(url('/book/page')); ?>/<?php echo e(str_replace(' ','%20',$str)); ?>/<?php echo e($i); ?>" onclick="pageSwitch(this)">
                    <?php endif; ?>
                        <label for="<?php echo e($i); ?>" class="page_label"><?php echo e($i); ?></label>
                        <input type="radio" name="page_no" class="radio-hidden" id="<?php echo e($i); ?>" value="<?php echo e($i); ?>" checked>
                    </div>

                <?php else: ?>
                    <?php if(str_contains($str, 'Category')): ?>
                    <div class="page not-active" data-page="<?php echo e($i); ?>" data-url="<?php echo e(url('/book/page')); ?>/<?php echo e(str_replace(': ','/$i/',$str)); ?>" onclick="pageSwitch(this)">
                    <?php elseif(str_contains($str, 'New Arrivals')): ?>
                    <div class="page not-active" data-page="<?php echo e($i); ?>" data-url="<?php echo e(url('/book/page')); ?>/<?php echo e(str_replace(' ','%20',$str)); ?>/<?php echo e($i); ?>" onclick="pageSwitch(this)">
                    <?php endif; ?>
                        <label for="<?php echo e($i); ?>" class="page_label"><?php echo e($i); ?></label>
                        <input type="radio" name="page_no" class="radio-hidden" id="<?php echo e($i); ?>" value="<?php echo e($i); ?>">
                    </div>
                <?php endif; ?>

            <?php endfor; ?>

            </div>

            <div class="page not-active page-increment" id="page-increment">
                &#9654;
            </div>

        </div>



</div>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('js/pagination.js')); ?>"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\EBook\resources\views/view_books.blade.php ENDPATH**/ ?>