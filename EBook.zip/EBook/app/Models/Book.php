<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Book extends Model
{
    use HasFactory;

    public $fillable = [
        'id',
        'title',
        'price',
        'rating',
       'description',
        'isbn_no',
        'in_stock',
        'image_path',
        'publisher_id',
        'published_at',
        'total_pages',
    ];

    public function publisher(){
        return $this -> belongsTo(Publisher::class, 'publisher_id', 'id');
    }

    public function author(){
        return $this -> belongsToMany(Author::class,'author_book', 'book_id','author_id')->withPivot('id') -> withTimestamps();
    }

    public function language(){
        return $this -> belongsToMany(Language::class, 'book_language', 'book_id', 'language_id')-> withPivot('id') ->withTimestamps();
    }

    public function category(){
        return $this -> belongsToMany(Categories::class, 'book_category', 'book_id', 'category_id')-> withPivot('id') ->withTimestamps();
    }

    public function user(){
        return $this -> belongsToMany(User::class, 'book_user','book_id','user_id')->withPivot('quantity')-> withTimestamps();
    }

    public function userReview(){
        return $this -> belongsToMany(User::class, 'book_review', 'book_id', 'user_id')->withPivot('id','rating', 'comment')->withTimeStamps();
    }

    public function calculateRatings(){

        if(count($this->userReview()->get()) > 0){
            $totalFive = count($this->userReview()->where('rating', 5)->get());
            $totalFour = count($this->userReview()->where('rating', 4)->get());
            $totalThree = count($this->userReview()->where('rating', 3)->get());
            $totalTwo = count($this->userReview()->where('rating', 2)->get());
            $totalOne = count($this->userReview()->where('rating', 1)->get());
    
    
            $rating = (5*$totalFive + 4*$totalFour + 3*$totalThree + 2*$totalTwo + $totalOne)/ 
            ($totalFive + $totalFour + $totalThree + $totalTwo + $totalOne);
    
            return round($rating);

        }
            
        return 0;
        

    }
}
