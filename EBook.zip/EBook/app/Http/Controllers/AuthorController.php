<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Author;
use Illuminate\Support\Facades\Storage;
class AuthorController extends Controller
{

    public function __construct(){

        $this -> middleware('auth');
        $this -> middleware('isAdmin');

    }

    public function isValidImageExtension(string $extensionName) : bool{

        $extensions = ['jpg' => 'jpg', 'jpeg' => 'jpeg', 'png' => 'png'];

        if( array_key_exists($extensionName, $extensions) ){
            return true;
        }

        return false;
    }

    public function imageNameBuilder(...$arg) : string{
        $newName = '';
        for($i = 0; $i < count($arg); $i++){
            $newName .= $arg[$i];
        }
        $newName .= '_';

        return uniqid($newName);
    }

    public function getInputValue(Request $request, string $inputName){
        return $request -> input($inputName);
    }

    public function trimAndUcfirst(string $str):string{
        return ucfirst(trim($str));
    }
    
    public function create($edit=null){
        if($edit){
            $author = Author::find((int)$edit);
            return view('admin.book.author', ["edit"=>true, "author"=>$author]);
        }
        return view('admin.book.author');
    }

    public function store(Request $request, $edit = null, $authorId=null){

  
        
        if($edit){
            $request -> validate([
                'firstName'=>['required'],
                'lastName'=>['required'],
                'bio' => ['required', 'string', 'min:100']
            ]);
            $firstName = $this->trimAndUcfirst($this->getInputValue($request, 'firstName'));
            $lastName = $this->trimAndUcfirst($this->getInputValue($request, 'lastName'));
            $bio = $this->trimAndUcfirst($this->getInputValue($request, 'bio'));

            $author = Author::find($authorId);
            $author -> first_name = $firstName;
            $author -> last_name = $lastName;
            $author -> bio = $bio;
            $author ->save();

            return redirect("view/author/$authorId");
         }
         else{ 
            $request -> validate([
                'firstName'=>['required'],
                'lastName'=>['required'],
                'bio' => ['required', 'string', 'min:100'],
                'authorPhoto' =>['required','mimes:jpeg,png,jpg']
            ]);
            $firstName = $this->trimAndUcfirst($this->getInputValue($request, 'firstName'));
            $lastName = $this->trimAndUcfirst($this->getInputValue($request, 'lastName'));
            $bio = $this->trimAndUcfirst($this->getInputValue($request, 'bio'));

            $file = $request -> file('authorPhoto');
            //Getting file extension like .jpg, .png
            $fileExtension = strtolower($file -> getClientOriginalExtension());
            //Creating unique name for an image
            $newName = $this -> imageNameBuilder($firstName,$lastName).".$fileExtension";
            //image directory name
            $destinationPath = 'authors_photos';

            //instantiating Author 
            $author = new Author();
            //setting value of author properties
            $author -> first_name = $firstName;
            $author -> last_name = $lastName;
            $author -> bio = $bio;
            $author -> author_pic = "$destinationPath/$newName";

        
            //Moving image to destination path
            $file -> move($destinationPath, $newName);
            //inserting data into the database
            $author ->save();


            return redirect("admin/view/authors");
            

        }
        
        //Redirecting to another page
        return "not saved";
    }

    public function delete($authorId){
        $author = Author::find((int)$authorId);
        Storage::delete($author->author_pic);
        $author->delete();

        return "author deleted";
    }

    public function updateImage(Request $request, $authorId){
        $request -> validate([
            'authorPhoto' =>['required','mimes:jpeg,png,jpg']
        ]);
        $author = Author::find((int)$authorId);
        $file = $request -> file('authorPhoto');
        $fileExtension = strtolower($file -> getClientOriginalExtension());
        $newImageName = explode('/',$author->author_pic)[1];
        Storage::delete($author->author_pic);
        $destinationPath = 'authors_photos';
        $file -> move($destinationPath, $newImageName);
        

        return redirect("view/author/$authorId");
    }



    public function update(Request $request, $authorId){
        return $this->store($request, true, (int)$authorId);
    }

    public function viewAuthors(){
        $authors = Author::orderBy('created_at','desc')->get();
        return view('admin.models_view',["authors"=>$authors]);
    }
}
