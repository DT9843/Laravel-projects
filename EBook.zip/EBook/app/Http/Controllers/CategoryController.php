<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Categories;
class CategoryController extends Controller
{

    public function __construct(){

        $this -> middleware('auth');
        $this -> middleware('isAdmin');

    }


    public function getInputValue(Request $request, string $inputName){
        return $request -> input($inputName);
    }

    public function trimAndUcfirst(string $str):string{
        return ucfirst(trim($str));
    }
    
    public function create($edit=null){
        if($edit){
            $category = Categories::find((int)$edit);
            return view('admin.book.category',["edit"=>true, "category"=>$category]);
        }
        return view('admin.book.category');
    }

    public function store(Request $request, $edit=null, $categoryId=null){

       

        if($edit){
            $request->validate([
                'category' => ['required']
            ]);
            $category = $this->trimAndUcfirst($this -> getInputValue($request, 'category'));
            $c =  Categories::find($categoryId);
            $c -> name = $category;
            $c -> save();
            
            return redirect("view/category/$categoryId");
        }
        else{
            $request->validate([
                'category' => ['required', 'unique:categories,name']
            ]);
            $category = $this->trimAndUcfirst($this -> getInputValue($request, 'category'));
            $c = new Categories();
            $c -> name = $category;
            $c -> save();

            return redirect("admin/view/categories");
        }
    }
    public function delete($categoryId){
        $c =  Categories::find((int)$categoryId);
        $c -> delete();

        return redirect("admin/view/categories");
    }

    public function update(Request $request, $categoryId){
        return $this -> store($request, true, (int)$categoryId);
    }

    public function viewCategories(){
        $categories = Categories::orderBy('created_at','desc')->get();

        return view('admin.models_view', ['categories'=>$categories]);
    }
}
