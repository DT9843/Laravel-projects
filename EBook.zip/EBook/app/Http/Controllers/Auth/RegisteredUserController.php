<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;

class RegisteredUserController extends Controller
{
    public function isValidImageExtension(string $extensionName) : bool{

        $extensions = ['jpg' => 'jpg', 'jpeg' => 'jpeg', 'png' => 'png'];

        if( array_key_exists($extensionName, $extensions) ){
            return true;
        }

        return false;
    }

    public function imageNameBuilder(...$arg) : string{
        $newName = '';
        for($i = 0; $i < count($arg); $i++){
            $newName .= $arg[$i];
        }
        $newName .= '_';

        return uniqid($newName);
    }

    public function trimAndUcfirst(string $str):string{
        return ucfirst(trim($str));
    }

    /**
     * Display the registration view.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        //password_confirmation
        if(Auth::check()){
            return redirect('/home');
        }
        return view('signup');
    }

    /**
     * Handle an incoming registration request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        $username = $request ->input('username');
        $pwd = $request -> input('password');
        $cpwd = $request -> input('password_confirmation');
        $img = $request -> file('user-profile-image');
        $imgExtension = $img!=null ? strtolower($img -> getClientOriginalExtension()) : null;
        $destination = 'users_profile_img';

        // if($imgExtension !== null ){
        //     if(!($this -> isValidImageExtension($imgExtension))){
        //         return "Image not valid";
        //     }
        // }

       
        
        $request->validate([
            'username' => ['required', 'string', 'max:35', 'unique:users'],
            'firstname' => ['required', 'string', 'max:35'],
            'lastname' => ['required', 'string', 'max:35'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'confirmed', 'min:8'],
            'user-profile-image' =>['mimes:jpeg,png,jpg']
        ]);
        
        if($imgExtension){
            $img->move($destination, "$username.$imgExtension");
        }


        $user = new User;
        $user -> username =  $request->username;
        $user ->first_name = $this->trimAndUcfirst($request->firstname);
        $user ->last_name = $this->trimAndUcfirst($request->lastname);
        $user -> email = $request->email;
        $user ->password = Hash::make($request->password);
        $user ->is_active = false;
        $user ->is_staff = false;
        $user ->profile_pic = $img!=null ? "$destination/$username.$imgExtension" : "$destination/user.png";
        $user ->save();
               
    
        return redirect('login');
        
        
        // return redirect('/signup');
    }
}
