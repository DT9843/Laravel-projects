<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Book;
use App\Models\Categories;

use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    //

    public function index(){


        return redirect('/home');
    }

    public function dashboard(){
        return redirect('/home');
    }

    public function showHomePage(){
        $new_arrival_books = collect(Book::orderBy('created_at', 'desc') -> get())->slice(0,6) -> all();

        $categories = Categories::all();

        $userCartTotalQty = null;
        if(Auth::check()){

            $userCartTotalQty = Auth::user()->book()->sum('quantity');

        }
          
        return view('index', ["new_arrival_books" => $new_arrival_books, 
        'userCartTotalQty'=>$userCartTotalQty, "categories"=>$categories]);

        
    }

    public function showBookInfo($bookTitle){

        $categories = Categories::all();
        
        $getBook = Book::where('title', $bookTitle) -> first();
       
        $getAllReview = $getBook->userReview();


        $userCartTotalQty = null;

        if(Auth::check()){

            $userCartTotalQty = Auth::user()->book()->sum('quantity');

        }

        return view('book', ['book'=>$getBook,
        'userCartTotalQty'=>$userCartTotalQty,
        'userReviews'=>$getAllReview,
        "categories"=>$categories]);

    }

    public function sendJson($inputText){

        if(is_numeric($inputText) && strlen($inputText) === 13){

            $books = Book::where('isbn_no', (int)$inputText)->get();
            $authors = [];
            foreach($books as $book){
               array_push( $authors ,$book -> author()->get());
            }
            return response()->json(["books"=>$books, "authors"=>$authors]);
        }

        else{
            $books = Book::where('title','like','%'.$inputText.'%')->get();
            $authors = [];
            foreach($books as $book){
            array_push( $authors ,$book -> author()->get());
            }

            return response()->json(["books"=>$books, "authors"=>$authors]);
        }
    }

    public function sendAuthorJson($bookId){ 
        $authors = Book::where('id', $bookId)->author()->get();
        return response()->json(["authors"=>$authors]);
    }


    // def start(pageNo):
    // start_no = (pageNo - 1) * 10
    // return start_no

    // def end(pageNo):
    //     end_no = pageNo * 10
    //     return end_no

    public function start($pageNo){

        $start_no = ($pageNo - 1) * 12;
        return $start_no;

    }

    public function end($pageNo){
        $end_no = ($pageNo * 12);
        return $end_no;
    }


    public function showAllBooks($str, $category = null, $pageNo=null){

        $userCartTotalQty = null;
        $books = null;
        $page = is_null($pageNo) ? 1 : (int) $pageNo;
        $totalPages = null;
        $categories = Categories::all();

        if(Auth::check()){

            $userCartTotalQty = Auth::user()->book()->sum('quantity');

        }

        $strt =  $this->start($page);
        $end = $this->end($page);

        if($str === "New Arrivals"){
    
            $books = Book::orderBy('created_at', 'desc')->get();
            $totalPages =(int)ceil(count($books) / 12);
            $books = collect($books)->slice($strt, $end) -> all();
                      
        }
        elseif($str === "Category"){
            $c = Categories::where('name', $category)->first();
            $books = $c -> book() -> get(); 
            $totalPages =(int)ceil(count($books) / 12);
            $books = collect($books)->slice($strt, $end) -> all();
            $str = "$str: $category";
        }
        return view("view_books",["books"=>$books, 
        "page" => $page ,
        "totalPages" => $totalPages,
        'userCartTotalQty'=>$userCartTotalQty,
        'str'=>$str, "categories"=>$categories]);
    }

    public function jsonShowAllBooks($str,$pageNo,$category=null){

        $books = null;
        $page = is_null($pageNo) ? 1 : (int) $pageNo;
        $strt =  $this->start($page);
        $end = $this->end($page);
        $authors = [];
        $hasBookInCart = [];

        if($str === "New Arrivals"){
            $books = Book::orderBy('created_at', 'desc')->get();      
        }
        elseif($str === "Category"){
            $c = Categories::where('name', $category)->first();
            $books = $c->book()->orderBy('created_at', 'desc')->get();
        }

        $arr = [];
        for($i=$strt; $i < $end; $i++){
            if(isset($books[$i])){

                array_push($arr, $books[$i]);
                array_push($authors, $books[$i]->author()->get());
                if(Auth::check()){
                    $has = is_null(Auth::user()->book()->where('book_id',$books[$i]->id)->first());
                    array_push($hasBookInCart,!$has);       
                }

            }
 
        }
        $books = $arr;

        return response()->json(["books"=>$books, "authors"=>$authors, 'isLoggedIn'=>Auth::check(), 'isInCart'=>$hasBookInCart]);
    }

    public function sendAllBooksJson(){
        $books = Book::all();

        return response()->json(["books"=>$books]);
    }

    public function aboutus(){
        $userCartTotalQty = null;
        $categories = Categories::all();
        if(Auth::check()){

            $userCartTotalQty = Auth::user()->book()->sum('quantity');

        }

        return view('aboutus', ['userCartTotalQty'=>$userCartTotalQty, 'categories'=>$categories ]);
    }
}
