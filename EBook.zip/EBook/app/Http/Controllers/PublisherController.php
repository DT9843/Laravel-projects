<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Publisher;
class PublisherController extends Controller
{

    public function __construct(){

        $this -> middleware('auth');
        $this -> middleware('isAdmin');

    }


    public function trimAndUcfirst(string $str):string{
        return ucfirst(trim($str));
    }

    public function getInputValue(Request $request, string $inputName){
        return $request -> input($inputName);
    }

    public function create($edit=null){
        if($edit){
            $publisher = Publisher::find((int)$edit);
            return view('admin.book.publisher',["publisher"=>$publisher, "edit"=>true]);
        }
        return view('admin.book.publisher');
    }

    public function store(Request $request, $edit=null, $publisherId = null){
   
       
        if($edit){
            $request->validate([
                'publisherName'=>['required']
            ]);

            $publisher = Publisher::find($publisherId);
            $publisher -> name =$this->trimAndUcfirst($this -> getInputValue($request, 'publisherName'));
            $publisher -> save();

            return redirect("view/publisher/$publisherId");
        }
        else{
            $request->validate([
                'publisherName'=>['required', 'unique:publishers,name']
            ]);
            $publisher = new Publisher();
            $publisher -> name =$this->trimAndUcfirst($this -> getInputValue($request, 'publisherName'));
            $publisher -> save();

            return redirect("admin/view/publishers");
        }
       
        
        
    }

    public function delete($publisherId){
        $publisher = Publisher::find((int)$publisherId);
        $publisher->delete();

        return redirect("admin/view/publishers");
    }

    public function update(Request $request, $publisherId){
        return $this->store($request, true, (int)$publisherId);
    }

    public function viewPublishers(){
        $publishers = Publisher::orderBy('created_at','desc')->get();
        return view('admin.models_view',['publishers'=>$publishers]);
    }
}
