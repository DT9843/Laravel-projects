<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Language;
class LanguageController extends Controller
{

    public function __construct(){

        $this -> middleware('auth');
        $this -> middleware('isAdmin');

    }

    public function getInputValue(Request $request, string $inputName){
        return $request -> input($inputName);
    }

    public function trimAndUcfirst(string $str):string{
        return ucfirst(trim($str));
    }
    
    public function create($edit = null){

        if($edit){
            $language = Language::find((int)$edit);
            return view('admin.book.language', ['edit'=>true, "language"=>$language]);
        }
        return view('admin.book.language');
    }

    public function store(Request $request, $edit=null, $languageId=null){

        if($edit){
            $request->validate([
                'language' => ['required']
            ]);
            $language = Language::find($languageId);
            $language -> language = $this->trimAndUcfirst($this -> getInputValue($request,'language'));
            $language -> save();

            return redirect("view/language/$languageId");
        }
        else{
            $request->validate([
                'language' => ['required', 'unique:languages,language']
            ]);

            $language = new Language();
            $language -> language = $this->trimAndUcfirst($this -> getInputValue($request,'language'));
            $language -> save();
            
            return redirect("admin/view/languages");
        }
     
    }

    public function delete($languageId){
        $language = Language::find((int)$languageId);
        $language->delete();

        return redirect("admin/view/languages");
    }

    public function update(Request $request, $languageId){
        return $this->store($request, true, (int)$languageId);
    }

    public function viewLanguages(){
        $languages = Language::orderBy('created_at','desc')->get();
        return view('admin.models_view',['languages'=>$languages]);
    }
}
