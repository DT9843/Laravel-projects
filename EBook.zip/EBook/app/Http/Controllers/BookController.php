<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Author;
use App\Models\Publisher;
use App\Models\Language;
use App\Models\Book;
use App\Models\Categories;
use Illuminate\Support\Facades\Storage;
class BookController extends Controller
{
    //

    public function __construct(){

        $this -> middleware('auth');
        $this -> middleware('isAdmin');

    }
  
    public function isValidImageExtension(string $extensionName) : bool{

        $extensions = ['jpg' => 'jpg', 'jpeg' => 'jpeg', 'png' => 'png'];

        if( array_key_exists($extensionName, $extensions) ){
            return true;
        }

        return false;
    }

    public function imageNameBuilder(...$arg) : string{
        $newName = '';
        for($i = 0; $i < count($arg); $i++){
            if(str_contains($arg[$i],":")){
                $newName .= str_replace(":","",$arg[$i]);
            }
            else{
                $newName .= $arg[$i];
            }
            
        }
        $newName .= '_';

        return uniqid($newName);
    }

    public function getInputValue(Request $request, string $inputName){
        return $request -> input($inputName);
    }

    public function trimAndUcfirst(string $str):string{
        return ucfirst(trim($str));
    }
   
  


    public function create(Request $request, $edit=null){

        $publishers = Publisher::all();
        
        if(isset($edit)){
            $book = Book::find((int)$edit);
            $allauthors = Author::all();
            $languages = $book->language()->get();
            $authors = $book->author()->get();
            $all_languages = Language::all();
            $all_categories = Categories::all();
            $categories = $book->category()->get();

            return view('admin.book.book', ["publishers" => $publishers, "book"=>$book,
            "authors"=>$authors,"categories"=>$categories,"all_categories"=>$all_categories,"languages"=>$languages,"all_languages"=>$all_languages,"allauthors"=>$allauthors,"edit"=>true]);
        }
        else{

            
            $authors = Author::all();
            $categories = Categories::all();
            $languages = Language::all();
    
            return view('admin.book.book', ["publishers" => $publishers, 
            "authors"=>$authors,
            "categories"=>$categories,
            "languages"=>$languages]);

        }

    }

    public function store(Request $request, $edit = null, $bookId = null){
       
        if($edit){

            $request -> validate([
                'bookTitle' => ['required'],
                'bookPrice' => ['required', 'numeric'],
                'bookDescription' => ['required', 'string', 'min:100'],
                'bookIsbnNo'=> ['required', 'string', 'unique:books,isbn_no' ,'min:13', 'max:13'],
                'bookInstock'=>['required'],
                'bookPublisher'=>['required'],
                'bookPublishedDate'=>['required', 'date'],
                'bookTotalPages'=>['required', 'numeric']
            ]);

            $title = $this->trimAndUcfirst($this -> getInputValue($request, 'bookTitle'));
            $price = (int)$this ->getInputValue($request, 'bookPrice');
            $rating = 0;
            $description = $this->trimAndUcfirst($this -> getInputValue($request, 'bookDescription'));
            $isbnNo = $this->trimAndUcfirst($this -> getInputValue($request, 'bookIsbnNo'));
            $stock = (int)$this ->getInputValue($request, 'bookInstock');
            $publisher = (int)$this -> getInputValue($request, 'bookPublisher');
            $publishedAt = $this -> getInputValue($request, 'bookPublishedDate');
            $totalPages = (int)$this -> getInputValue($request, 'bookTotalPages');

            $book = Book::find($bookId);

            $book -> title = $title;
            $book -> price =$price;
            $book -> description = $description;
            $book -> isbn_no = $isbnNo;
            $book -> in_stock = $stock;
            $book -> publisher_id = $publisher;
            $book -> published_at = $publishedAt;
            $book -> total_pages = $totalPages;
    
            $book->save();

            return redirect("view/book/$book->id");
        }
        else{
            $request -> validate([
                'bookTitle' => ['required', 'unique:books,title'],
                'bookPrice' => ['required', 'numeric'],
                'bookDescription' => ['required', 'string', 'min:100'],
                'bookIsbnNo'=> ['required', 'string', 'unique:books,isbn_no' ,'min:13', 'max:13'],
                'bookInstock'=>['required'],
                'bookPublisher'=>['required'],
                'bookPublishedDate'=>['required', 'date'],
                'bookTotalPages'=>['required', 'numeric'],
                'admin-author'=>['required'],
                'admin-category'=>['required'],
                'admin-language'=>['required'],
                'bookImage'=>['required','mimes:jpeg,png,jpg']
            ]);


                        
            $title = $this->trimAndUcfirst($this -> getInputValue($request, 'bookTitle'));
            $price = (int)$this ->getInputValue($request, 'bookPrice');
            $rating = 0;
            $description = $this->trimAndUcfirst($this -> getInputValue($request, 'bookDescription'));
            $isbnNo = $this->trimAndUcfirst($this -> getInputValue($request, 'bookIsbnNo'));
            $stock = (int)$this ->getInputValue($request, 'bookInstock');
            $publisher = (int)$this -> getInputValue($request, 'bookPublisher');
            $publishedAt = $this -> getInputValue($request, 'bookPublishedDate');
            $totalPages = (int)$this -> getInputValue($request, 'bookTotalPages');


            $book = new Book();
            $image = $request -> file('bookImage');
            $imageExtension = strtolower($image -> getClientOriginalExtension());
            $newImageName = $this->imageNameBuilder($title).".$imageExtension";
            $destinationPath = "books_photos";
            $image -> move($destinationPath, $newImageName);

            $book -> title = $title;
            $book -> price =$price;
            $book -> rating = $rating;
            $book -> description = $description;
            $book -> isbn_no = $isbnNo;
            $book -> in_stock = $stock;
            $book -> image_path = "$destinationPath/$newImageName";
            $book -> publisher_id = $publisher;
            $book -> published_at = $publishedAt;
            $book -> total_pages = $totalPages;
    
            $book->save();
    
    
            $authors = trim($request -> input('admin-author'));
    
            if(str_contains($authors, '/')){
                $authors = explode("/", $authors);
                foreach($authors as $author){
                    $full_name = explode(" ", $author);
                    $last_name = null;
                    if(count($full_name) > 2){
                        $last_name = join(" ", array_slice($full_name, 1, count($full_name) - 1));
                    }
                    else{
                        $last_name = $full_name[1];
                    }
                    $this->saveBookAuthor($book, $full_name[0], $last_name);
                }
            }
            else{
                $full_name = explode(" ", $authors);
                $last_name = null;
                if(count($full_name) > 2){
                    $last_name = join(" ", array_slice($full_name, 1, count($full_name) - 1));
                }
                else{
                    $last_name = $full_name[1];
                }
                $this->saveBookAuthor($book, $full_name[0], $last_name);
            }
           
            
            $categories = trim($request -> input('admin-category'));
            if(str_contains($categories, "/")){
                $categories = explode("/", $categories);    
                foreach($categories as $category){
                    $this->saveBookCategory($book, $category);
    
                }
            }
            else{
                $this->saveBookCategory($book, $categories);
            }
            
            
            
            $languages = trim($request -> input('admin-language'));
            if(str_contains($languages, "/")){
                $languages = explode("/", $languages);
                foreach($languages as $language){
                    $this->saveBookLanguage($book, $language);
                }
            }
            else{
                $this->saveBookLanguage($book, $languages);
            }
    
            
            return redirect("admin/view/books");
        }

        
       
    }


    public function updateBookAuthor(Request $request, $bookId, $id){
        
        $request -> validate([
            "author_name" => ['required']
        ]);

        $book = Book::find((int)$bookId);
        $full_name = explode(' ', $request->input('author_name'));
        $newAuthor = null;
        $last_name = null;

        if(count($full_name) > 2){
            $last_name = join(" ", array_slice($full_name, 1, count($full_name) - 1));
        }
        else{
            $last_name = $full_name[1];
        }

        $newAuthor = Author::where('first_name', $full_name[0])->where('last_name', $last_name)->first();
        $book->author()->updateExistingPivot((int)$id, ["author_id"=>$newAuthor->id]);

        return redirect("view/book/$book->id");
     
    }

    public function updateBookLanguage(Request $request, $bookId, $id){
        $request -> validate([
            "book-language" => ['required']
        ]);
        $book = Book::find((int)$bookId);
        $newLanguage = Language::where('language', $request->input('book-language'))->first();

        $book->language()->updateExistingPivot((int)$id, ["language_id"=>$newLanguage->id]);

        return redirect("view/book/$bookId");

    }

    public function updateBookCategory(Request $request, $bookId, $id){

        $request -> validate([
            "book-category" => ['required']
        ]);

        $book = Book::find((int)$bookId);
        $newCategory = Categories::where('name', $request->input('book-category'))->first();

        $book->category()->updateExistingPivot((int)$id, ["category_id"=>$newCategory->id]);

        return redirect("view/book/$bookId");
    }
    public function addNewBookAuthor(Request $request, $bookId){
        $request -> validate([
            "author_name" => ['required']
        ]);

        $full_name = explode(' ',$request -> input('author_name'));
        $book = Book::find((int)$bookId);
        $author = null;
        $last_name = null;
        if(count($full_name) > 2){
            $last_name = join(" ", array_slice($full_name,1, count($full_name) - 1));
        }
        else{
            $last_name = $full_name[1];
        }

        $author = Author::where('first_name', $full_name[0])->where('last_name', $last_name)->first();
        $this->saveBookAuthor($book, $full_name[0], $last_name);
        
        return redirect("view/book/$bookId");
    }

    public function addNewBookLanguage(Request $request, $bookId){
        $request -> validate([
            "book_language" => ['required']
        ]);
        $book = Book::find((int)$bookId);
        $this->saveBookLanguage($book, $request->input('book_language'));
        
        return redirect("view/book/$bookId");
    }

    public function addNewBookCategory(Request $request, $bookId){
        $request -> validate([
            "book_category" => ['required']
        ]);
        $book = Book::find((int)$bookId);
        $this->saveBookCategory($book, $request->input('book_category'));
        
        return redirect("view/book/$bookId");
    }

    public function saveBookAuthor($book, $first_name, $last_name){
        $author = Author::where('first_name', $first_name)->where('last_name', $last_name)->first();
        $book -> author() -> attach($author);
    }


    public function saveBookLanguage($book, $language){

        $languageObj = Language::where('language', $language)->first();
        $book -> language() -> attach($languageObj);

    }

    public function saveBookCategory($book, $category){
        $categoryObj = Categories::where('name', $category)->first();
        $book -> category() -> attach($categoryObj);
    }


    public function deleteBookAuthor(Request $request, $bookId, $id){

        Book::find((int)$bookId)->author()->detach((int)$id);

        return redirect("view/book/$bookId");
    }

    public function deleteBookLanguage(Request $request, $bookId, $id){
    
        Book::find((int)$bookId)->language()->detach((int)$id);

        return redirect("view/book/$bookId");
    }

    public function deleteBookCategory(Request $request, $bookId, $id){
      
        Book::find((int)$bookId)->category()->detach((int)$id);

        return redirect("view/book/$bookId");
    }


    public function changeBookImage(Request $request, $bookId){
        $request->validate([
            'bookImage'=>['required', 'mimes:jpeg,png,jpg']
        ]);
        $book = Book::find((int)$bookId);

        $image = $request -> file('bookImage');
        $imageExtension = strtolower($image -> getClientOriginalExtension());

        if($this->isValidImageExtension($imageExtension)){
           
            $newImageName = explode('/',$book->image_path)[1];
            $destinationPath = "books_photos";
            Storage::delete("$destinationPath/$newImageName");
            $image -> move($destinationPath, $newImageName);
        }

        return redirect("view/book/$bookId");
    }

    public function update(Request $request, $bookId){
       return $this->store($request, true, (int)$bookId);
    }

    public function viewBooks(){

        $books = Book::orderBy('created_at','desc')->get();
        return view('admin.models_view', ['books'=>$books]);

    }
}
