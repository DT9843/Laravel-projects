<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;
use App\Models\Categories;
use Illuminate\Support\Facades\Auth;
class CartController extends Controller
{
    
    public function show(){
        $userCartTotalQty = Auth::user()->book()->sum('quantity');
        $cartItems = Auth::user()->book()->get();
        $totalAmt = 0;
        $categories = Categories::all();
        foreach($cartItems as $cartItem){
            $price = $cartItem->price * $cartItem->pivot->quantity;
            $totalAmt += $price;
        }
        return view('cart', ["userCartTotalQty"=>$userCartTotalQty, "cartItems"=>$cartItems, "totalAmt"=>$totalAmt, "categories"=>$categories]);
    }

    public function store(Request $request){
        
       $title =  $request->input('Title');
       $qty = $request->input('Qty');

       $book = Book::where('title',$title)->first();
       $request->user()-> book()->attach($book->id, ['quantity'=>$qty]);

       return response()->json(["success"=>"Add to cart successful"]);
    }

    public function update(Request $request){
        $title =  $request->input('Title');
        $qty = (int) $request->input('Qty');

        $book = Book::where('title',$title)->first();
        $request->user()->book()->updateExistingPivot($book->id,["quantity"=>$qty]);
        
        return response()->json(["success"=>"Update cart item successful"]);
    }

    public function delete($id){
        Auth::user()->book()->detach((int)$id);
        return response()->json(["success"=>"Delete cart item successful"]);

    }

}
