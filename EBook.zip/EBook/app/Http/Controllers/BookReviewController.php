<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;
use Illuminate\Support\Facades\Auth;

class BookReviewController extends Controller
{  

    
    public function create($bookTitle,Request $request){

        $ratings = $request -> input('rating');
        $comment = $request -> input('comment');

        $book = Book::where('title', $bookTitle) -> first();
      

        $request -> user() -> bookReview() -> attach($book -> id, 
        ["rating"=>$ratings, "comment"=>$comment]);

        $book->rating = $book -> calculateRatings();
        $book->save();

        return redirect("book/$bookTitle");

    }

    public function delete($bookTitle, $id){
       
        Auth::user()->bookReview()->wherePivot('id','=', (int)$id)->detach();

        $book = Book::where('title', $bookTitle)->first();
        $book->rating = $book -> calculateRatings();
        $book->save();

        return redirect("book/$bookTitle");
        
    }

}
