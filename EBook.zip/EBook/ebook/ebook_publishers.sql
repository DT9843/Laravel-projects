-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: ebook
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `publishers`
--

DROP TABLE IF EXISTS `publishers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publishers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `publishers_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publishers`
--

LOCK TABLES `publishers` WRITE;
/*!40000 ALTER TABLE `publishers` DISABLE KEYS */;
INSERT INTO `publishers` VALUES (1,'Bloomsbury Publishing','2021-10-27 00:42:30','2021-10-27 00:42:30'),(2,'Crown','2021-10-28 01:48:19','2021-10-28 01:48:19'),(3,'‎Signet Classic','2021-11-11 21:39:54','2021-11-11 21:39:54'),(4,'HarperCollins','2021-11-27 23:32:19','2021-11-27 23:32:19'),(7,'Bantam','2021-12-06 22:22:25','2021-12-06 22:22:25'),(8,'Pottermore Publishing','2021-12-06 23:57:25','2021-12-06 23:57:25'),(9,'Fingerprint! Publishing','2021-12-07 20:59:40','2021-12-07 21:21:43'),(10,'Razorbill','2021-12-07 21:01:16','2021-12-07 21:01:16'),(11,'Shambhala','2021-12-07 21:02:31','2021-12-07 21:02:31'),(12,'Independently','2021-12-07 21:03:45','2021-12-07 21:03:45'),(13,'Penguin Ananda','2021-12-07 21:04:21','2021-12-07 21:04:21'),(14,'G.P. Putnam\'s Sons Books for Young Readers','2021-12-07 21:05:05','2021-12-07 21:05:05'),(15,'Scholastic Inc.','2021-12-07 21:06:21','2021-12-07 21:06:21'),(16,'Random House Trade Paperbacks','2021-12-07 21:07:14','2021-12-07 21:07:14'),(17,'Margaret K. McElderry Books','2021-12-07 21:08:03','2021-12-07 21:08:03'),(18,'Mariner Books','2021-12-07 21:09:06','2021-12-07 21:09:06'),(19,'HarperOne','2021-12-07 21:12:28','2021-12-07 21:12:28'),(20,'Bloomsbury USA','2021-12-07 21:13:23','2021-12-07 21:13:23'),(21,'Little, Brown Spark','2021-12-07 21:16:10','2021-12-07 21:16:10'),(22,'Simon & Schuster India','2021-12-07 21:16:59','2021-12-07 21:16:59'),(23,'Ballantine Books','2021-12-07 21:17:39','2021-12-07 21:17:39'),(24,'Little, Brown and Company','2021-12-07 21:19:30','2021-12-07 21:19:30'),(25,'‎ Allen Lane','2021-12-08 00:42:55','2021-12-08 00:42:55'),(26,'Sangri-La Books','2022-01-04 21:05:08','2022-01-04 21:05:08'),(27,'McGraw-Hill','2022-01-04 21:48:38','2022-01-04 21:48:38');
/*!40000 ALTER TABLE `publishers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-19 15:31:55
