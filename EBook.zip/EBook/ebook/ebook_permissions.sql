-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: ebook
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (2,'Create book','web','2021-12-21 20:47:04','2021-12-21 20:51:37'),(3,'Edit book','web','2021-12-21 20:47:13','2021-12-21 20:47:13'),(4,'Delete book','web','2021-12-21 20:47:23','2021-12-21 20:47:23'),(5,'View book','web','2021-12-21 20:51:11','2021-12-21 20:51:11'),(6,'Create author','web','2021-12-21 20:51:25','2021-12-21 20:51:25'),(7,'Edit author','web','2021-12-21 20:51:53','2021-12-21 20:51:53'),(8,'Delete author','web','2021-12-21 20:52:05','2021-12-21 20:52:05'),(9,'View author','web','2021-12-21 20:53:23','2021-12-21 20:53:23'),(10,'Create publisher','web','2021-12-21 20:53:47','2021-12-21 20:53:47'),(11,'Edit publisher','web','2021-12-21 20:53:56','2021-12-21 20:53:56'),(12,'Delete publisher','web','2021-12-21 20:54:13','2021-12-21 20:54:13'),(13,'View publisher','web','2021-12-21 20:54:21','2021-12-21 20:54:21'),(14,'Create category','web','2021-12-21 20:54:42','2021-12-21 20:54:42'),(15,'Edit category','web','2021-12-21 20:54:50','2021-12-21 20:54:50'),(16,'Delete category','web','2021-12-21 20:55:00','2021-12-21 20:55:00'),(17,'View category','web','2021-12-21 20:55:09','2021-12-21 20:55:09'),(18,'Create language','web','2021-12-21 20:55:45','2021-12-21 20:55:45'),(19,'Edit language','web','2021-12-21 20:55:54','2021-12-21 20:55:54'),(20,'Delete language','web','2021-12-21 20:56:08','2021-12-21 20:56:08'),(21,'View language','web','2021-12-21 20:56:15','2021-12-21 20:56:15'),(22,'Create role','web','2021-12-21 20:57:11','2021-12-21 20:57:11'),(23,'Edit role','web','2021-12-21 20:57:17','2021-12-21 20:57:17'),(24,'Delete role','web','2021-12-21 20:57:43','2021-12-21 20:57:43'),(25,'View role','web','2021-12-21 20:57:49','2021-12-21 20:57:49'),(26,'Create permission','web','2021-12-21 20:58:01','2021-12-21 20:58:01'),(27,'Edit permission','web','2021-12-21 20:58:25','2021-12-21 20:58:25'),(28,'Delete permission','web','2021-12-21 20:58:34','2021-12-21 20:58:34'),(29,'View permission','web','2021-12-21 20:58:49','2021-12-21 20:58:49'),(30,'Delete user','web','2021-12-23 21:29:16','2021-12-23 21:29:41'),(31,'Create user','web','2021-12-27 23:59:50','2021-12-27 23:59:50'),(32,'Edit user','web','2021-12-28 00:00:11','2021-12-28 00:00:11'),(33,'View user','web','2021-12-28 00:00:58','2021-12-28 00:00:58');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-19 15:31:58
