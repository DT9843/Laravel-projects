-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: ebook
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (3,'Admin','web','2021-12-20 22:02:09','2021-12-20 22:02:09'),(4,'Book creator','web','2021-12-21 20:38:13','2021-12-21 20:42:22'),(5,'Book editor','web','2021-12-21 20:38:22','2021-12-21 20:38:22'),(6,'Book delete','web','2021-12-21 20:41:04','2021-12-21 20:41:04'),(7,'Author creator','web','2021-12-21 20:41:59','2021-12-21 20:42:43'),(8,'Author editor','web','2021-12-21 20:42:59','2021-12-21 20:42:59'),(9,'Author delete','web','2021-12-21 20:43:29','2021-12-21 20:43:29'),(10,'Publisher creator','web','2021-12-21 20:44:51','2021-12-21 20:44:51'),(11,'Publisher editor','web','2021-12-21 20:45:00','2021-12-21 20:45:00'),(12,'Publisher delete','web','2021-12-21 20:45:10','2021-12-21 20:45:10'),(13,'Language creator','web','2021-12-21 20:45:35','2021-12-21 20:45:35'),(14,'Language editor','web','2021-12-21 20:45:46','2021-12-21 20:45:46'),(15,'Language delete','web','2021-12-21 20:45:56','2021-12-21 20:45:56'),(16,'Category creator','web','2021-12-21 20:46:11','2021-12-21 20:46:11'),(17,'Category editor','web','2021-12-21 20:46:22','2021-12-21 20:46:22'),(18,'Category delete','web','2021-12-21 20:46:31','2021-12-21 20:46:31'),(19,'Role creator','web','2021-12-21 20:59:27','2021-12-21 20:59:27'),(20,'Role editor','web','2021-12-21 20:59:38','2021-12-21 20:59:38'),(21,'Role delete','web','2021-12-21 20:59:47','2021-12-21 20:59:47'),(22,'Permission creator','web','2021-12-21 21:00:04','2021-12-21 21:00:04'),(23,'Permission editor','web','2021-12-21 21:00:13','2021-12-21 21:00:13'),(24,'Permission delete','web','2021-12-21 21:00:22','2021-12-21 21:00:22'),(25,'User creator','web','2021-12-28 00:02:05','2021-12-28 00:02:05'),(26,'User editor','web','2021-12-28 00:02:53','2021-12-28 00:02:53'),(27,'User delete','web','2021-12-28 00:03:20','2021-12-28 00:03:20');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-19 15:31:58
