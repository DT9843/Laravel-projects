-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: ebook
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Fantasy','2021-10-28 01:32:46','2021-10-28 01:32:46'),(2,'Autobiography','2021-10-28 02:21:56','2021-10-28 02:21:56'),(3,'Political memoir','2021-10-28 02:22:10','2021-10-28 02:22:10'),(4,'Political Fiction','2021-11-11 21:58:22','2021-11-11 21:58:22'),(5,'Adventure','2021-11-28 00:28:55','2021-11-28 00:28:55'),(6,'Dark Comedy','2021-11-28 00:29:09','2021-11-28 00:29:09'),(7,'Comedy','2021-11-28 00:29:26','2021-11-28 00:29:26'),(9,'Science','2021-12-06 22:24:12','2021-12-06 22:24:12'),(17,'Classic','2021-12-08 03:15:00','2021-12-08 03:22:00'),(18,'Buddhism','2021-12-08 03:15:00','2021-12-08 03:22:00'),(19,'Non fiction','2021-12-08 03:15:00','2021-12-08 03:22:00'),(20,'Health','2021-12-08 03:15:00','2021-12-08 03:22:00'),(21,'Leadership','2021-12-08 03:15:00','2021-12-08 03:22:00'),(22,'History','2021-12-08 03:15:00','2021-12-08 03:22:00'),(23,'Kids','2022-01-04 20:59:56','2022-01-04 20:59:56'),(24,'Teens','2022-01-04 21:00:03','2022-01-04 21:00:03'),(25,'Self Development','2022-01-04 21:01:03','2022-01-04 21:01:03'),(26,'Motivation','2022-01-04 21:01:12','2022-01-04 21:01:12');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-19 15:32:00
