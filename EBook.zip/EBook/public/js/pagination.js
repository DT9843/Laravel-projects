

let labels = document.getElementsByClassName('page_label');
for(let i =0; i < labels.length; i++){
    labels[i].onclick = function(event){
        event.stopPropagation();
    }
}

function sendJson(bookTitle, qty, url){

    let token = document.querySelector('meta[name="csrf-token"]').content;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.open("POST", url, true);
    xmlhttp.setRequestHeader('X-CSRF-TOKEN', token);
    xmlhttp.setRequestHeader('Content-Type','application/json');
    xmlhttp.send(JSON.stringify({"Title":bookTitle, "Qty":qty}));
}

function incrementCartLinkNo(qty){
    let cartQtyNoObj = document.getElementById("cart-link-qty");
    if(cartQtyNoObj){

        let currentCartQty = Number(cartQtyNoObj.innerHTML);
        currentCartQty += qty;
        cartQtyNoObj.innerHTML = currentCartQty;

    }
    else{
        let cartLinkObj =document.getElementById('cart-link');
        let newSpan = document.createElement('span');
        newSpan.id = "cart-link-qty";
        newSpan.innerHTML = qty;

        cartLinkObj.appendChild(newSpan);
    }
   
}


function addToCart(bookTitle,obj){

    const url = "http://127.0.0.1:8000/cart/add/item";
    const cartUrl= "http://127.0.0.1:8000/cart";
    // const qtyUrl ="http://127.0.0.1:8000/user/cart/qty";


    const qty = 1;

    sendJson(bookTitle, qty, url);
    incrementCartLinkNo(qty);
    
    obj.classList.remove('cart-btn');
    obj.classList.add('cart-btn-view');
    obj.textContent = "View Cart";
    obj.onclick=function(){
        window.location.href=cartUrl;
    }

}


    document.getElementById('page-increment').addEventListener('click', function(){
        let active = document.querySelector('.radio-activated');
        let next = active.nextElementSibling;
        if(next){
            pageSwitch(next);
        }
        
    });
    
   
    



    document.getElementById('page-decrement').addEventListener('click', function(){
        let active = document.querySelector('.radio-activated');
        let previous = active.previousElementSibling;
        if(previous){
            pageSwitch(previous);
        }
        
    });




function pageSwitch(obj){
    if(!obj.classList.contains('radio-activated')){
        let url = obj.dataset.url;
        let bookContainer = document.querySelector("div[class='new-arrivals-books-2']");
        let http = new XMLHttpRequest();
        http.onreadystatechange=function(){            
            if(http.readyState == 4 && http.status == 200) {
                bookContainer.innerHTML = "";
                let responseJson = JSON.parse(http.responseText);

                responseJson.books.forEach((item, index)=>{
                    let div1 = document.createElement('div');
                    div1.classList.add('books');
                    div1.id = item.id;

                    let img = document.createElement('img');
                    img.src = `http://127.0.0.1:8000/${item.image_path}`;
                    img.height = "240";
                    img.width = "158";

                    let div2 = document.createElement('div');
                    div2.classList.add('book-info');

                    let a1 = document.createElement('a');
                    a1.classList.add('title-link');
                    a1.href= `/book/${item.title}`;

                    let h6 = document.createElement('h6');
                    h6.classList.add('title');
                    h6.textContent = item.title;
                    
                    a1.appendChild(h6);

                    let p1 = document.createElement('p');
                    p1.classList.add('author');
                    let b1 = document.createElement('b');
                    b1.textContent = "by ";
                    p1.appendChild(b1);

                    let str = "";
                    let authors =  responseJson.authors[index];
                    authors.forEach((item, index)=>{
                        if(index+1 == authors[index].length-1){
                            str += `${item.first_name} ${item.last_name} and `;
                        }
                        else if(index+1 < authors[index].length-1){
                            str += `${item.first_name} ${item.last_name}, `;
                        }
                        else{
                            str += `${item.first_name} ${item.last_name}.`;
                        }
                    });

                    let text = document.createTextNode(str);
                    p1.appendChild(text);

                    let div3 = document.createElement('div');
                    for(let $i=0; $i< 5; $i++){
                        let span = document.createElement('span');
                        if(item.rating > $i){
                            span.classList.add("fa");
                            span.classList.add("fa-star");
                            span.classList.add("checked");
                            span.classList.add("rating");
                        }
                        else{
                            span.classList.add("fa");
                            span.classList.add("fa-star");
                            span.classList.add("rating");
                        }
                        div3.append(span);
                    }

                    let p2 = document.createElement('p');
                    p2.classList.add('price');
                    p2.textContent = `NPR.${item.price}`;

                    div2.appendChild(a1);
                    div2.appendChild(p1);
                    div2.appendChild(div3);
                    div2.appendChild(p2);

                    div1.appendChild(img);
                    div1.appendChild(div2);
                    
                    let button = document.createElement('button');
                    let addToCartStr = "Add To Cart";
                  
                    
                    if(Boolean(responseJson.isLoggedIn)){

                        if(Boolean(responseJson.isInCart[index])){
                            button.classList.add('cart-btn-view');
                            button.textContent = addToCartStr;
                            button.onclick = function(){
                                windows.location.href = "http://127.0.0.1:8000/cart";
                            }
                        }
                        else{
                            button.classList.add('cart-btn');
                            button.textContent = addToCartStr;
                            button.onclick = function(){
                                addToCart(item.title, button)
                            };
                        }

                    }
                    else{
                        button.classList.add('cart-btn');
                        button.textContent = addToCartStr;
                        button.onclick = function(){
                            window.location.href = "http://127.0.0.1:8000/login";
                            
                        }
                    }
                    div1.appendChild(button);
                    bookContainer.appendChild(div1);
                });

                let findActive = document.querySelector('.radio-activated');
                findActive.classList.remove('radio-activated');
                findActive.classList.add('not-active');
        
                obj.classList.remove('not-active');
                obj.classList.add('radio-activated');
            }


        }
        http.open('GET', url);
        http.setRequestHeader('Content-Type','application/json');
        http.send();
        


    
    }

}
