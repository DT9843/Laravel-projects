let ratingsObj = document.getElementsByClassName("review-star");
let labelObj = document.querySelector('.post-review div:nth-child(2)').querySelectorAll('label');
let ratingScale = ['Poor', 'Fair', 'Good', 'Very Good', 'Excellent'];
let ratingStatus= document.getElementById('review-status');
let radioBtnObj = document.querySelectorAll('.star-rating');

function setRatingsColor(ratings){

    for(let i = 0; i<Number(ratings); i++){
        ratingsObj[i].classList.add('checked');
        ratingStatus.innerHTML = ratingScale[i];
    }
}

function resetRatings(){
    
    for(let i = 0; i<5; i++){
        ratingsObj[i].classList.remove('checked');
    }
    ratingStatus.innerHTML = "Give Ratings";
}

function setRatings(ratings){

    for(let i=0; i<5; i++){
        if(ratings > i){
            ratingsObj[i].classList.add('checked');
        }
        
        labelObj[i].onmouseleave="";
        labelObj[i].onmouseover="";
        labelObj[i].onclick="";
    }
    
}

let resetBtn = document.getElementById('reset-btn');
resetBtn.addEventListener('click', function(){
    ratingStatus.innerHTML = "Give Ratings";
    for(let i=0; i<5; i++){
        radioBtnObj[i].checked = false;
        ratingsObj[i].classList.remove('checked');


        labelObj[i].onmouseover = function(){
            for(let x = 0; x<i+1; x++){
                ratingsObj[x].classList.add('checked');
                ratingStatus.innerHTML = ratingScale[x];
            }
        }
        
        labelObj[i].onmouseleave = function(){
            for(let x = 0; x<i+1; x++){
                ratingsObj[x].classList.remove('checked');
            } 
            ratingStatus.innerHTML = "Give Ratings";
        }

        labelObj[i].onclick = function(){
            for(let x = 0; x<5; x++){
                if(i+1 > x){
                    ratingsObj[x].classList.add('checked');
                }
                labelObj[x].onmouseleave="";
                labelObj[x].onmouseover="";
                labelObj[x].onclick="";
            }
        }
        
      
    }
});