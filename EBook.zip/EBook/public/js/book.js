let author = document.getElementById('admin-book-author');
let category = document.getElementById('admin-book-category');
let language = document.getElementById('admin-book-language');


// author.disabled = true;
// category.disabled = true;
// language.disabled = true;

function multiInput(str, obj){
    let option = obj.options[obj.selectedIndex];
    let value = option.value;



    if(value !== ""){
     
        
        switch(str){

            case "author":
                if(author.value === ""){
                   
                    author.value = value;
                    
                }
                else{
                    author.value += `/${value}`;
                }
                break;
            
            case "category":
                if(category.value === ""){
                    
                    category.value = value;
                }
                else{
                    category.value += `/${value}`;
                }
                break;
            
            case "language":
                if(language.value === ""){
                    
                    language.value = value;
                }
                else{
                    language.value += `/${value}`;
                }
                break;

            case "":
                
                break;
        }
        option.style.display = "none";


    }
  
 

}

if(author || category || language){

    document.getElementById('author-reset').addEventListener('click', function(){
        let select = document.getElementById('admin-select-author');
        author.value = "";
        unHide(select);
    });
    
    document.getElementById('category-reset').addEventListener('click', function(){
        let select = document.getElementById('admin-select-category');
        category.value = "";
        unHide(select);
    });
    
    document.getElementById('language-reset').addEventListener('click', function(){
        let select = document.getElementById('admin-select-language');
        language.value = "";
        unHide(select);
    });
    
}


function unHide(select){
    let children = select.children;
    for(let i =1; i < children.length; i++){
        
        children[i].style.display = "block";
    }
    children[0].selected = true;
}

function edit(obj){

    let option = obj.options[obj.selectedIndex];
    let value = option.value;
    
    let sibling = obj.previousElementSibling;
    sibling.value = value;
}

function newForm(select,obj){

    let csrf = document.querySelector('input[type="hidden"]');
    // csrf.type="hidden";
    // csrf.name="_token";
    // csrf.value="1UKmD9jxZy5VyhAZKv03vwiCc5ws4b5rrSVRA4DS";

    let selectObj= document.getElementById(select);
    let clone = document.cloneNode(true);
    let newClone = clone.getElementById(select);
    newClone.options[0].selected = true; 
    newClone.style.display = "block";

    let newform = document.createElement('form');
    newform.method = "POST";
    newform.appendChild(csrf);

    let submit = document.createElement('input');
    submit.type="submit";
    submit.value="Add";
    submit.classList.add("admin-add-sm-btn");

    let input = document.createElement('input');
    input.classList.add("admin-book-info-input");
    input.type="text";

    let div = document.createElement('div');
    div.classList.add('admin-book-info-container');
    let div2 = document.createElement('div');
    div2.classList.add('admin-book-info-container');
    div2.appendChild(submit);

    switch(select){
        case 'admin-select-author-hidden':
            
            newform.action = `/admin/add/new/book/author/${obj.dataset.bookId}`;
            input.name="author_name";
            input.placeholder = "Please select an author given below";
            break;
        
        case 'admin-select-language-hidden':
                
            newform.action = `/admin/add/new/book/language/${obj.dataset.bookId}`;
            input.name="book_language";
            input.placeholder = "Please select a language given below";
            break;

        case 'admin-select-category-hidden':
    
            newform.action = `/admin/add/new/book/category/${obj.dataset.bookId}`;
            input.name="book_category";
            input.placeholder = "Please select a category given below";
            break;
    }
 
    
    div.appendChild(csrf);
    div.appendChild(input);
    div.appendChild(newClone);

    newform.appendChild(div);
    newform.appendChild(div2);

    obj.parentElement.parentElement.insertBefore(newform, obj.parentElement);
   
}