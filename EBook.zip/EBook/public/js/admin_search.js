let adminSrch = document.getElementById('admin-search-input');
let tbody = document.querySelector('tbody');


function unHideTr(){
    let tr = tbody.querySelectorAll('tr');
    tr.forEach(item=>{
        item.style.display = "table-row";
    });
}

adminSrch.addEventListener('input', function(){
    unHideTr();
    value = this.value.toLowerCase();
    if(value !== ""){
        let tr = document.querySelectorAll('tr a');
        tr.forEach(item=>{
            grandParent = item.parentElement.parentElement;
            if(!item.textContent.toLowerCase().includes(value)){
                grandParent.style.display = "none";
            }
        });
    }

});
 // let url = this.dataset.url+value.trim();
        // let http = new XMLHttpRequest();
        // http.onreadystatechange = function(){
        //     if(http.readyState == 4 && http.status == 200){
        //         let response = JSON.parse(this.responseText);
        //         tbody.innerHTML = "";
        //         if(response.books){
        //             response.books.forEach((item, index)=>{
        //                 let tr = document.createElement('tr');
        //                 tr.classList.add('model-data-row');
        //                 let td1 = document.createElement('td');
        //                 td1.classList.add('model-data');

        //                 let a = document.createElement('a');
        //                 a.classList.add('model-link');
        //                 a.href=`http://127.0.0.1:8000/view/book/${item.title}`;
        //                 a.textContent = item.title;
        //                 td1.appendChild(a);

        //                 let td2 = document.createElement('td');
        //                 td2.classList.add('model-data');
        //                 td2.textContent = item.created_at;
        //                 let td3 = document.createElement('td');
        //                 td3.classList.add('model-data');
        //                 td3.textContent = item.updated_at;

        //                 tr.appendChild(td1);
        //                 tr.appendChild(td2);
        //                 tr.appendChild(td3);
        //                 tbody.appendChild(tr);
        //             });
        //         }
        //         else if(response.authors){

        //         }
        //         else{

        //         }
        //     }
        // }

        // http.open('GET', url);
        // http.setRequestHeader('Content-Type','application/json');
        // http.send();