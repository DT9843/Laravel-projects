let srcInput = document.getElementById('search-input');
let srcResult = document.getElementById('search-results');
const url = "";


window.onclick = function(){
 
    srcResult.classList.add('search-results-hidden');
    srcResultChildRemove();
}

function srcResultChildRemove(){
    // rmchild = srcResult.children;
    // for(let i = 0; i<rmchild.length; i++){
    //     srcResult.removeChild(rmchild[i]);
    // }
    srcResult.innerHTML = "";
}


srcInput.addEventListener('input', function(){
    if(srcResult.classList.contains('search-results-hidden')){
        srcResult.classList.remove('search-results-hidden');
    }
   
    if(this.value !== ""){
       
        let xmlhttp = new XMLHttpRequest();

        
        xmlhttp.onreadystatechange=function(){
            
            if(xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                srcResultChildRemove();
                let responseJson =JSON.parse(xmlhttp.responseText);
                let books = responseJson.books;
                let authors = responseJson.authors;
            //    srcResult.classList.remove('search-results-hidden');

                
           
                
                for(let i = 0; i < books.length; i++){
                    let aObj = document.createElement('a');
                    aObj.href = `book/${books[i].title}`;
                    aObj.classList.add('search-item-link');

                    let div1 = document.createElement('div');
                    div1.classList.add('search-items');

                    let img = document.createElement('img');
                    img.src = `http://127.0.0.1:8000/${books[i].image_path}`;
                    img.style.height = "100px";
                    img.style.width = "70px";

                    let div2 = document.createElement('div');
                    let h3 = document.createElement('h3');
                    h3.textContent = books[i].title;
                    let p = document.createElement('p');
                    let str = "by ";


                    authors[i].forEach((item, index)=>{

                        if(index+1 == authors[i].length-1){
                            str += `${item.first_name} ${item.last_name} and `;
                        }
                        else if(index+1 < authors[i].length-1){
                            str += `${item.first_name} ${item.last_name}, `;
                        }
                        else{
                            str += `${item.first_name} ${item.last_name}.`;
                        }

                    });

                  

                    p.textContent = str;



                    div2.append(h3);
                    div2.append(p);

                    div1.append(img);
                    div1.append(div2);
                    
                    aObj.append(div1);

                   

                    srcResult.append(aObj);
                }

            
            }
           
        }

        xmlhttp.open("GET", `http://127.0.0.1:8000/books/${this.value.trim()}`);
        xmlhttp.setRequestHeader('Content-Type','application/json');
        xmlhttp.send();

        
       
       
    }
    else{
        srcResult.classList.add('search-results-hidden');
        srcResultChildRemove();
    }

});