let category = document.querySelector('#category');
let categoryList = document.getElementById('category-list');

category.addEventListener('click', function(){



    if(categoryList.classList.contains('drop-down-hide')){
        categoryList.classList.remove('drop-down-hide')
    }
    else{
        categoryList.classList.add('drop-down-hide')
    }

});


