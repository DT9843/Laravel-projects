let rememberMeChkBox = document.getElementById('remember-me');

let changeChkBoxVal = (val, isChecked)=>{
    rememberMeChkBox.value = val;
    rememberMeChkBox.checked = isChecked;
}

rememberMeChkBox.addEventListener('click', function(){
    if(rememberMeChkBox.value === "0"){
        changeChkBoxVal("1", true);
    }
    else{
        changeChkBoxVal("0", false);
    }
});