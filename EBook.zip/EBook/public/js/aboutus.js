let aboutUs = document.getElementById('aboutUs');
let bookBhandar = document.getElementById('bookBhandar');
let contactUs = document.getElementById('contactUs');

document.getElementById('aboutus-button-1').addEventListener('click', function(){
    let activeBtn = document.querySelector('.btn-activated');
    if(!this.classList.contains('btn-activated')){
        let aboutUs = document.getElementById('aboutUs');
        activeBtn.classList.remove('btn-activated');
        this.classList.add('btn-activated')
        aboutUs.classList.remove('d-none');
        bookBhandar.classList.add('d-none');
        contactUs.classList.add('d-none');
    }
});

document.getElementById('aboutus-button-2').addEventListener('click', function(){
    let activeBtn = document.querySelector('.btn-activated');
    if(!this.classList.contains('btn-activated')){
        activeBtn.classList.remove('btn-activated');
        this.classList.add('btn-activated')
        aboutUs.classList.add('d-none');
        bookBhandar.classList.remove('d-none');
        contactUs.classList.add('d-none');
    }
});

document.getElementById('aboutus-button-3').addEventListener('click', function(){
    let activeBtn = document.querySelector('.btn-activated');
    if(!this.classList.contains('btn-activated')){
        activeBtn.classList.remove('btn-activated');
        this.classList.add('btn-activated')
        aboutUs.classList.add('d-none');
        bookBhandar.classList.add('d-none');
        contactUs.classList.remove('d-none');
    }
});