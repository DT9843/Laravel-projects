function sendJson(bookTitle, qty, url){

    let token = document.querySelector('meta[name="csrf-token"]').content;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.open("POST", url, true);
    xmlhttp.setRequestHeader('X-CSRF-TOKEN', token);
    xmlhttp.setRequestHeader('Content-Type','application/json');
    xmlhttp.send(JSON.stringify({"Title":bookTitle, "Qty":qty}));
}


function getChild(id){
    return document.getElementById(id).childNodes;
}



function qtyNo(obj, id){
    let cartItemChild = getChild(id);
    let updateBtn = cartItemChild[3].childNodes[7].childNodes[3];

    if( !(updateBtn.classList.contains('update-visibility')) ){

        updateBtn.classList.add('update-visibility');

    }
    
    
}

function getBookName(cartItemChild){
    let bookName = cartItemChild[3].childNodes[1].textContent;
    return bookName;
}

function getItemQtyObj(cartItemChild){
    let itemQtyObj = cartItemChild[3].childNodes[5].childNodes[3];
    return itemQtyObj;
}

function getPreviousQty(bookTitle){
    let orderSummaryObj = document.getElementById('cart-qty-price-info');
    let orderSummaryObjChild = [].slice.call(orderSummaryObj.getElementsByClassName("book-price-child"));
    let qty;
    orderSummaryObjChild.forEach(element=>{
       if(bookTitle == element.childNodes[1].textContent.trim()){
         
        
        qty= Number(element.childNodes[0].childNodes[0].textContent);
        return;
       }

    });

    return qty;
}

function updateItemQty(id){
    let url =  "http://127.0.0.1:8000/cart/update/item";
    let cartItemChild = getChild(id);
    let bookName = getBookName(cartItemChild);
    let itemQtyObj = getItemQtyObj(cartItemChild);
    let priceObj = getPriceObj(cartItemChild);


    let itemQty = Number(itemQtyObj.value);
    if(itemQty > 0){
        let previousQty = getPreviousQty(bookName);
        let actualBookPrice = Number(priceObj.textContent) / previousQty;
        
        sendJson(bookName, itemQty, url);

        itemQtyObj.value = itemQty;
        actualBookPrice *= itemQty;

        priceObj.textContent = actualBookPrice;
        updateOrderSummary();

        let cartQtyNoObj = document.getElementById("cart-link-qty");
        let currentCartQty = Number(cartQtyNoObj.innerHTML);
        currentCartQty -= previousQty;
        cartQtyNoObj.innerHTML = currentCartQty + itemQty;
        // decrementCartLinkNo(1);
        
    
    }

}

function deleteFromAjax(url){
    let token = document.querySelector('meta[name="csrf-token"]').content;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.open('DELETE', url, true);
    xmlhttp.setRequestHeader('X-CSRF-TOKEN', token);
    xmlhttp.setRequestHeader('Content-Type','application/json');
    xmlhttp.send();
}

function deleteCartItem(id){

    let cartItem = document.getElementById(id);
    let url =  `http://127.0.0.1:8000/cart/delete/item/${id}`;
    deleteFromAjax(url);
    let cartItemChild = getChild(id);
    let itemQtyObj = getItemQtyObj(cartItemChild);
    let itemQty = Number(itemQtyObj.value);
    decrementCartLinkNo(itemQty);
    cartItem.remove();
    updateOrderSummary();
}


function decrement(id){
    let url =  "http://127.0.0.1:8000/cart/update/item";
    let cartItemChild = getChild(id);
    let bookName = getBookName(cartItemChild);
    let itemQtyObj = getItemQtyObj(cartItemChild);
    let priceObj = getPriceObj(cartItemChild);

    let itemQty = Number(itemQtyObj.value);

    if(itemQty > 1){
        let actualBookPrice = Number(priceObj.textContent) / itemQty;
        itemQty -= 1;

        sendJson(bookName, itemQty, url);

        itemQtyObj.value = itemQty;
        actualBookPrice *= itemQty;

        priceObj.textContent = actualBookPrice;
        updateOrderSummary();
        decrementCartLinkNo(1);
    }
    

}

function getPriceObj(cartItemChild){

    return cartItemChild[5].childNodes[1].childNodes[1];
}


function increment(id){
    let url =  "http://127.0.0.1:8000/cart/update/item";
    let cartItemChild = getChild(id);
    let bookName = getBookName(cartItemChild);
    let itemQtyObj = getItemQtyObj(cartItemChild);
    let priceObj = getPriceObj(cartItemChild);

    let itemQty = Number(itemQtyObj.value);
    let actualBookPrice = Number(priceObj.textContent) / itemQty;
    itemQty += 1;

    sendJson(bookName, itemQty, url);

    itemQtyObj.value = itemQty;
    actualBookPrice *= itemQty;

    priceObj.textContent = actualBookPrice;
    updateOrderSummary();
    incrementCartLinkNo(1);
}

function incrementCartLinkNo(qty){
    let cartQtyNoObj = document.getElementById("cart-link-qty");
    if(cartQtyNoObj){

        let currentCartQty = Number(cartQtyNoObj.innerHTML);
        currentCartQty += qty;
        cartQtyNoObj.innerHTML = currentCartQty;

    }
    else{
        let cartLinkObj =document.getElementById('cart-link');
        let newSpan = document.createElement('span');
        newSpan.id = "cart-link-qty";
        newSpan.innerHTML = qty;

        cartLinkObj.appendChild(newSpan);
    }
   
}

function decrementCartLinkNo(qty){
    let cartQtyNoObj = document.getElementById("cart-link-qty");
    let currentCartQty = Number(cartQtyNoObj.innerHTML);
    currentCartQty -= qty;
    if(currentCartQty == 0){
        let emptyCartContainerObj = document.getElementById('empt-cart-container');
        let cartContainerObj = document.getElementById('cart-container');

        emptyCartContainerObj.classList.remove('cart-container-visibility');
        cartContainerObj.classList.add('cart-container-visibility');

        cartQtyNoObj.remove();
    }
    else{
        cartQtyNoObj.innerHTML = currentCartQty;
    }
      
}

function addToCart(bookTitle,obj){

    const url = "http://127.0.0.1:8000/cart/add/item";
    const cartUrl= "http://127.0.0.1:8000/cart";
    // const qtyUrl ="http://127.0.0.1:8000/user/cart/qty";


    const qty = 1;

    sendJson(bookTitle, qty, url);
    incrementCartLinkNo(qty);
    
    obj.classList.remove('cart-btn');
    obj.classList.add('cart-btn-view');
    obj.textContent = "View Cart";
    obj.onclick=function(){
        window.location.href=cartUrl;
    }

}

function updateOrderSummary(){
    let orderSummaryObj = document.getElementById('cart-qty-price-info');
    let children = [].slice.call(orderSummaryObj.children);
    let totalAmount = document.getElementById('total-price');
   
    children.forEach(element => {
        orderSummaryObj.removeChild(element);
    });

    let cartItems = [].slice.call(document.getElementsByClassName('cart-items'));
    let totalPrice = 0;
    
    cartItems.forEach(element =>{
        let bookName = getBookName(element.childNodes);
        let price = Number(getPriceObj(element.childNodes).textContent);
        let itemQty = getItemQtyObj(element.childNodes).value;
        
        totalPrice += price;

        let div = document.createElement('div');
        div.classList.add("book-price");
        
        let p1 = document.createElement('p');
        p1.classList.add("book-price-child");
        let b = document.createElement('b');
        let span = document.createElement('span');
        span.innerHTML = itemQty;
        let text1 = document.createTextNode(" X");
        let text2 = document.createTextNode(` ${bookName}`);
        b.appendChild(span);
        b.appendChild(text1);
        p1.appendChild(b);
        p1.appendChild(text2);

        let p2 = document.createElement('p');
        p2.innerHTML = `NPR.${price}`;

        div.append(p1);
        div.append(p2);

        orderSummaryObj.append(div);
    });
    totalAmount.innerHTML = `NPR.${totalPrice}`;
}

