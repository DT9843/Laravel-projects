<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\BookController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\BookReviewController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthorController;
use App\Http\Controllers\PublisherController;
use App\Http\Controllers\LanguageController;
use App\Http\Controllers\CategoryController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/




Route::get('/',[HomeController::class, 'index']);
Route::get('/home',[HomeController::class, 'showHomePage']);
Route::get('/dashboard', [HomeController::class, 'dashboard']);

Route::get('/signup',[RegisteredUserController::class,'create'])->name('signup');
Route::post('/signup',[RegisteredUserController::class,'store']);

Route::get('/logout', [AuthenticatedSessionController::class, 'destroy']);
Route::get('/login', [AuthenticatedSessionController::class, 'create']);
Route::post('/login', [AuthenticatedSessionController::class, 'store']);


Route::get('/add/book', [BookController::class, 'create']);
Route::get('/view/book/{edit}', [BookController::class, 'create']);
Route::post('/save/book',[BookController::class, 'store']);
Route::post('/admin/change/book/image/{bookId}', [BookController::class, 'changeBookImage']);
Route::post('/admin/edit/book/info/{bookId}', [BookController::class, 'update']);
Route::post('/admin/edit/book/author/{bookId}/{id}', [BookController::class, 'updateBookAuthor']);
Route::post('/admin/edit/book/language/{bookId}/{id}', [BookController::class, 'updateBookLanguage']);
Route::post('/admin/edit/book/category/{bookId}/{id}', [BookController::class, 'updateBookCategory']);
Route::post('/admin/add/new/book/author/{bookId}', [BookController::class, 'addNewBookAuthor']);
Route::post('/admin/add/new/book/language/{bookId}', [BookController::class, 'addNewBookLanguage']);
Route::post('/admin/add/new/book/category/{bookId}',[BookController::class, 'addNewBookCategory']);

Route::get('/view/all/books/{str}',[HomeController::class, 'showAllBooks']);

Route::get('/admin/delete/book/author/{bookId}/{id}', [BookController::class, 'deleteBookAuthor']);
Route::get('/admin/delete/book/language/{bookId}/{id}', [BookController::class, 'deleteBookLanguage']);
Route::get('/admin/delete/book/category/{bookId}/{id}', [BookController::class, 'deleteBookCategory']);


Route::get('/add/publisher',[PublisherController::class, 'create']);
Route::get('/view/publisher/{edit}', [PublisherController::class, 'create']);
Route::get('/admin/delete/publisher/{publisherId}', [PublisherController::class, 'delete']);
Route::post('/save/publisher',[PublisherController::class, 'store']);
Route::post('/admin/edit/publisher/{publisherId}', [PublisherController::class, 'update']);


Route::get('/add/category', [CategoryController::class, 'create']);
Route::post('/save/category', [CategoryController::class, 'store']);
Route::get('/view/category/{edit}',[CategoryController::class,'create']);
Route::post('/admin/edit/category/{categoryId}', [CategoryController::class, 'update']);
Route::get('/admin/delete/category/{categoryId}', [CategoryController::class, 'delete']);

Route::get('/add/author',[AuthorController::class, 'create']);
Route::post('/save/author',[AuthorController::class, 'store']);
Route::get('/view/author/{edit}',[AuthorController::class, 'create']);
Route::post('/admin/change/author/image/{authorId}', [AuthorController::class, 'updateImage']);
Route::post('/admin/edit/author/info/{authorId}', [AuthorController::class, 'update']);
Route::get('/admin/delete/author/{authorId}', [AuthorController::class, 'delete']);

Route::get('/add/language',[LanguageController::class, 'create']);
Route::post('/save/language',[LanguageController::class, 'store']);
Route::get('/view/language/{edit}', [LanguageController::class, 'create']);
Route::post('/admin/edit/language/{languageId}',[LanguageController::class, 'update']);
Route::get('/admin/delete/language/{languageId}',[LanguageController::class, 'delete']);

// Route::get('/add/book/author',[AuthorController::class, 'create']);
// Route::post('/save/book/author',[AuthorController::class, 'store']);

// Route::get('/add/book/category', [CategoryController::class, 'create']);
// Route::post('/save/book/category',[CategoryController::class, 'store']);

// Route::get('/add/book/language',[LangaugeController::class, 'create']);
// Route::post('/save/book/language',[LanguageController::class, 'store']);

Route::get('/cart', [CartController::class, 'show'])->middleware('auth');
Route::post('/cart/add/item',[CartController::class, 'store'])->middleware('auth');

Route::get('/books/{inputText}',[HomeController::class, 'sendJson']);

Route::post('/cart/update/item',[CartController::class, 'update'])->middleware('auth');

Route::delete('/cart/delete/item/{id}', [CartController::class, 'delete'])->middleware('auth');

// Route::get('/book/{bookTitle}', [HomeController::class, 'showBookInfo']);
Route::post('/book/{bookTitle}', [BookReviewController::class, 'create']);

Route::get('/delete/comment/{bookTitle}/{id}', [BookReviewController::class, 'delete']);

Route::get('/admin/home', [AdminController::class, 'index'])->middleware('auth');


Route::get('/admin/view/books',[BookController::class,'viewBooks']);
Route::get('/admin/view/authors',[AuthorController::class, 'viewAuthors']);
Route::get('/admin/view/publishers',[PublisherController::class, 'viewPublishers']);
Route::get('/admin/view/languages',[LanguageController::class, 'viewLanguages']);
Route::get('/admin/view/categories',[CategoryController::class, 'viewCategories']);

Route::get('/book/page/{str}/{pageNo}',[HomeController::class, 'jsonShowAllBooks']);
Route::get('/view/all/books/{str}/{category}', [HomeController::class, 'showAllBooks']);
Route::get('/book/page/{str}/{pageNo}/{category}', [HomeController::class, 'jsonShowAllBooks']);
Route::get('/aboutus', [HomeController::class, 'aboutus']);

require __DIR__.'/auth.php';
