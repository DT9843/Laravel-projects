<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('trips', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('destination_id');
            $table->bigInteger('activity_id');
            $table->bigInteger('agency_id');
            $table->bigInteger('trekking_region_id');
            $table->string('trip_name');
            $table->integer('trip_cost');
            $table->tinyInteger('duration');
            $table->longText('description');
            $table->string('trip_photo');
            $table->string('route_photo');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('trips');
    }
};
