function buttonToggle(){

    let currentBtn = document.querySelector(`.${this.innerHTML.toLowerCase()}`);
    currentBtn.classList.remove('dp-none');
    
    document.querySelectorAll('.td').forEach(item=>{
        if(currentBtn !== item){
            item.classList.add('dp-none');
        }
    });
    
}
    
document.querySelectorAll('.td-btn').forEach(item=>{
    item.addEventListener('click', buttonToggle);
});