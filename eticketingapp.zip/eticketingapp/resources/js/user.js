let roles = document.getElementById('roles');
let uRoles = document.getElementById('userRoles');

roles.addEventListener('change', function(event){

    let role = event.target;

    if(role.value !== ""){

        if(uRoles.value === ""){

            uRoles.value = role.value;
    
        }
        else{
    
            uRoles.value += ","+role.value;
    
        }

        role.options[role.selectedIndex].style.display="none";
    }

});

uRoles.addEventListener('input',function (event){

    let input = event.target.value;
    if(input === ""){
        roles.querySelectorAll('option').forEach(element => {
            element.style.display="block";      
        });
    }

});