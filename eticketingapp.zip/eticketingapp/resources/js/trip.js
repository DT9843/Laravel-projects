
function elementCreator(tagName){
    return document.createElement(tagName);
}

function createCsrf(){
    let csrf = elementCreator('input');
    csrf.type = "hidden";
    csrf.name = "_token";
    csrf.value = document.querySelector("meta[name='csrf-token']").content;

    return csrf;
}

document.querySelector('#add-itinerary').addEventListener('click', function(){
    
    //let tripId = parseInt(this.dataset.tripId);
    let form = elementCreator('form');
    form.method="post";
    form.action= this.dataset.tripItinerary;

    let div1 = elementCreator('div');
    let div2 = elementCreator('div');

    let label1 = elementCreator('label');
    label1.innerHTML = "Activity";
    let label2 = elementCreator('label');
    label2.innerHTML = "Description";

    let input = elementCreator('input');
    input.name = "activity";
    input.required = true;

    let description = elementCreator('textarea');
    description.name = "activity_description";
    description.required = true;

    let submit = elementCreator('input');
    submit.type = "submit";
    submit.value = "Add";

    let csrf = createCsrf();


    div1.appendChild(label1);
    div1.appendChild(input);

    div2.appendChild(label2);
    div2.appendChild(description);

    form.appendChild(csrf);
    form.appendChild(div1);
    form.appendChild(div2);

    form.appendChild(submit);
    document.querySelector('.itinerary').insertBefore(form, this);
});


function createField(inputName, labelName, dataset){
    let form = elementCreator('form');
    form.action = dataset;
    form.method = 'post';

    let div = elementCreator('div');
    
    let label = elementCreator('label');
    label.innerHTML = labelName;

    let input = elementCreator('input');
    input.name = inputName;
    input.type = "text";
    input.required = true;

    let submit = elementCreator('input');
    submit.type = "submit";
    submit.value = "Add";

    div.appendChild(label);
    div.appendChild(input);

    form.appendChild(createCsrf());
    form.appendChild(div);
    form.appendChild(submit);
    
   return form;
}


function addCost(){

    let form =  createField("description", "Description", this.dataset.costId);
    document.querySelector('.costs').insertBefore(form, this);
}

function addGearEquipment(){
    
    let form = createField("list", "List", this.dataset.ge);
    document.querySelector('.gearequipment').insertBefore(form, this);
}

function addHighlight(){
    let form = createField("highlight", "Highlight", this.dataset.highlight);
    document.querySelector('.highlights').insertBefore(form, this);
}

function addFaq(){
    let form = elementCreator('form');
    form.action = this.dataset.faq;
    form.method = 'post';

    let div1 = elementCreator('div');
    let div2 = elementCreator('div');

    let label1 = elementCreator('label');
    label1.innerHTML = "Question";

    let label2 = elementCreator('label');
    label2.innerHTML = "Answer";

    let input1 = elementCreator('input');
    input1.name = "question";
    input1.type = "text";
    input1.required = true;

    let input2 = elementCreator('textarea');
    input2.name = "answer";
    input2.col = "30";
    input2.row = "30";
    input2.required = true;



    let submit = elementCreator('input');
    submit.type = "submit";
    submit.value = "Add";

    div1.appendChild(label1);
    div1.appendChild(input1);

    div2.appendChild(label2);
    div2.appendChild(input2);

    form.appendChild(createCsrf());
    form.appendChild(div1);
    form.appendChild(div2);
    form.appendChild(submit);

    document.querySelector('.faqs').insertBefore(form, this);
    
}


document.querySelector('.highlight').addEventListener('click', addHighlight);

document.querySelector('.faq').addEventListener('click', addFaq);


document.querySelectorAll('.cost').forEach(item=>{
    item.addEventListener('click', addCost);
})

document.querySelectorAll('.ge').forEach(item=>{
    item.addEventListener('click', addGearEquipment);
})