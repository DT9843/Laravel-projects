document.querySelector('#region').addEventListener('change', function(event){

   if(event.target.value === "All"){
      window.location = this.dataset.all;
   }
   else{
      window.location = `${this.dataset.link}/${event.target.value}`;
   }

});

