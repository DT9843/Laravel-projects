@extends('base')


@section('title', 'Search result')


@section('body')

@include('nav')

<div class="container">
<div class="d-flex justify-content-between">
<fieldset>


<legend>Search Trips</legend>

<form action="{{route('searchTrips')}}" class="d-flex"  method="post">
    @csrf

    <div>

        <label for=""> <b>Destination</b> </label>
        <select name="destination" id="">
    
            @foreach($destinations as $d)

                @if($destination->country === $d->country)
                    <option value="{{$d->country}}" selected>{{$d->country}}</option>
            
                @else
                    <option value="{{$d->country}}">{{$d->country}}</option>
            
                @endif

            @endforeach
        </select>

    </div>

    <div class="mx-2">

        <label for=""><b>Activities</b></label>
        <select name="activity" id="">

            @foreach($activities as $a)
                @if($activity->activity === $a->activity)
                    <option value="{{$a->activity}}" selected>{{$a->activity}}</option>
                @else
                    <option value="{{$a->activity}}">{{$a->activity}}</option>
                @endif
            @endforeach
        </select>

    </div>



    <input type="submit" value="Search" class="btn btn-success">
</form>

</fieldset>


<fieldset>
    <legend>Select Region</legend>
    <select name="" id="region"
    data-all="{{route('searchResults', ['destination'=>$destination->country, 'activity'=>$activity->activity])}}"
    data-link="/search/trips/{{$destination->country}}/{{$activity->activity}}">

        <option value="All" >All</option>
        @foreach($regions as $r)
            @if($region)
                @if($region->region === $r->region)
                    <option value="{{$r->region}}" selected>{{$r->region}}</option>
                @else
                    <option value="{{$r->region}}">{{$r->region}}</option>
                @endif
            @else
                <option value="{{$r->region}}">{{$r->region}}</option>
            @endif
        
        @endforeach
    </select>
</fieldset>
</div>
    <div class="my-3">
        @forelse($trips as $trip)
            <!-- <p>{{$trip->trip_name}}</p> -->

            <div class="card" style="width:410px;">

                <img class="card-img-top" width='410' height="250" src="{{url($trip->trip_photo)}}" alt="">

                <div class="card-body">
                    <h4 class="card-title"> <a href="" class="card-link">{{$trip->trip_name}}</a></h4>

                    <h5>Starting From: {{$trip->trip_cost}}</h5>
                    <h5>Destination: {{$trip->destination->country}}</h5>
                    <h5>Duration: {{$trip->duration}} days</h5>

                    <a href="{{route('tripDetails',['activity'=>$activity->activity,'tripName'=>$trip->trip_name])}}" class="btn btn-primary d-grid">View Details</a>
                </div>


            </div>

            @empty

            <p>Search Not Found</p>
        @endforelse
    </div>
</div>
    @vite('resources/js/home.js')
@endsection