@extends('base')


@section('title', 'Gear And Equipments')


@section('body')
@include('admin.nav')
    <a href="{{route('createGearEquipment')}}">create</a>

    <table class="table">

        <thead>

            <tr>

                <th>Gear And Equipment</th>
                <th>Action</th>

            </tr>


        </thead>

        <tbody>
            @foreach($ges as $ge)
                <tr>

                    <td><a href="{{route('editGearEquipment',['geId'=>$ge->id])}}">{{$ge->list}}</a></td>
                    <td>
                        <a href="{{route('deleteGearEquipment',['geId'=>$ge->id])}}" class="btn btn-danger">Delete</a>
                    </td>

                </tr>
            @endforeach
        </tbody>



    </table>


@endsection