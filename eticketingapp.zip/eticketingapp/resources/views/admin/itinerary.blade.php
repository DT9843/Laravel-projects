@extends('base')


@section('title','Edit itinerary details')

@section('body')

@include('admin.nav')
    <form action="{{route('updateItinerary', ['tripId'=>$tripId, 'itnId'=>$itnId])}}" method="post">
        @csrf
        <div>
            <label for="">Activity</label>
            <input type="text" name="activity" value="{{$itn->activity}}" required>
        </div>
        
        <div>
            <label for="">Description</label>
            <textarea name="description" id="" cols="30" rows="10" required>
                {{$itn->activity_description}}
            </textarea>
        </div>

        <input type="submit" value="Edit" class="btn btn-warning">
    </form>



@endsection