@extends('base')


@section('title', 'Trekking Region Create Form')


@section('body')
@include('admin.nav')

    @if($edit)
    <form action="{{route('saveEditActivity',['aId'=>$activity->id])}}" method="post">
    @else
    <form action="{{route('saveActivity')}}" method="post">
    @endif
    
        @csrf

        <div>
            <label for="">Activity</label>
            @if($edit)
            <input type="text" name="activity" value="{{$activity->activity}}" required>
            @else
            <input type="text" name="activity" required>
            @endif
        </div>
        @if($edit)
        <input type="submit" value="Edit" class="btn btn-warning">
        @else
        <input type="submit" value="Add" class="btn btn-primary">
        @endif
    </form>


@endsection