@extends('base')


@section('title', 'Edit gear and equipment list')


@section('body')
@include('admin.nav')
    <form action="{{route('updateGearAndEquipment', ['tripId'=>$tripId, 'geId'=>$geId, 'gePid'=>$ge->pivot->id])}}" method="post">

        @csrf
        <div>
            <label for="">List</label>
            <input type="text" name="list" value="{{$ge->pivot->list}}" required>
        </div>

        <input type="submit" class="btn btn-warning" value="Edit">

    </form>



@endsection