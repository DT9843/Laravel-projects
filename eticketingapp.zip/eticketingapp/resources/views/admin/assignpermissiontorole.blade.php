@extends('base')


@section('title', 'Assign permission to role')

@section('body')
@include('admin.nav')
    <h2>Role details</h2>

    <form action="{{route('editRole', ['roleId'=>$role->id])}}" method="post">
        @csrf
        <div>

            <label for="">Role</label>
            <input type="text" name="role" value="{{$role->name}}">

        </div>


        <input type="submit" value="Edit role" class="btn btn-warning">
    </form>



    <h2>Role permissions</h2>
    <table class="table">
        <thead>

            <tr>
                <th>Permission</th>
                <th>Action</th>
            </tr>

        </thead>

        <tbody>

            @forelse($role->permissions as $rp)
            <tr>
                <td>{{$rp->name}}</td>
                <td><a href="{{route('deleteRolePermission',['roleId'=>$role->id, 'pId'=>$rp->id])}}" class="btn btn-danger">Delete</a></td>
            </tr>
                @empty
            <tr>
                <td>No permission is given to the role.</td>
                <td>No action</td>
            </tr>
            @endforelse


        </tbody>
     
    </table>
    <form action="{{route('assignPermissionToRole', ['roleId'=>$role->id])}}" method="post">
        @csrf

        <div>
            <input type="text" id="rolePermissions" name="permissions" placeholder="please select permission" required>
            <select id="permissions">
                <option value="" selected>None</option>
                @foreach($permissions as $p)

                    @if(!$role -> hasPermissionTo($p))
                        <option value="{{$p->name}}">{{$p->name}}</option>    
                    @endif

                @endforeach

            </select>

        </div>

        <input type="submit" value="Add permission to role" class="btn btn-primary">

    </form>

<a href="{{route('deleteRole',['roleId'=>$role->id])}}" class="btn btn-danger">Delete</a>

@vite('resources/js/role.js')
@endsection

