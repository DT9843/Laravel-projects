@extends('base')


@section('title', 'Trip Create Form')


@section('body')
@include('admin.nav')

    <form action="{{route('saveTrip')}}" enctype="multipart/form-data"  method="post">

        @csrf

        <div>
            <label for="">Trip Name</label>
            <input type="text" name="trip_name" required>
        </div>

        
        <div>
            <label for="">Trip Cost</label>
            <input type="number" name="trip_cost" required>
        </div>

        <div>
            <label for="">Trip Duration</label>
            <input type="number" name="duration" required>
        </div>

        <div>
            <label for="">Trip Destination</label>
            <select name="destination" id="">
                <option value="" selected>None</option>
                @foreach($destinations as $destination)
                    <option value="{{$destination->id}}">{{$destination->country}}</option>
                @endforeach
            </select>
        </div>

        <div>
            <label for="">Region</label>
            <select name="region" id="">
                <option value="" selected>None</option>
                @foreach($regions as $region)
                    <option value="{{$region->id}}">{{$region->region}}</option>
                @endforeach
            </select>
        </div>

        <div>
            <label for="">Activity</label>
            <select name="activity" id="">
                <option value="" selected>None</option>
                @foreach($activities as $activity)
                    <option value="{{$activity->id}}">{{$activity->activity}}</option>
                @endforeach
            </select>
        </div>

        <div>
            <label for="">Agency</label>
            <select name="agency" id="">
                <option value="" selected>None</option>
                @foreach($agencies as $agency)
                    <option value="{{$agency->id}}">{{$agency->agency_name}}</option>
                @endforeach
            </select>
        </div>

        <div>
            <label for="">Description</label>
            <textarea name="description" id="" cols="80" rows="20">
                
            </textarea>
        </div>

        <div>
            <label for="">Front Image</label>
            <input type="file" name="front_image" id="" required>
        </div>

        <div>
            <label for="">Route Image</label>
            <input type="file" name="route_image" required>
        </div>

        <input type="submit" value="Add">
    </form>


@endsection