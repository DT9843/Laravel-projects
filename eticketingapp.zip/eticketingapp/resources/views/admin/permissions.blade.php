@extends('base')


@section('title', 'permissions')


@section('body')
@include('admin.nav')

    <a href="{{route('createPermission')}}">Create permission</a>
    <table class="table">

      <thead>

        <tr>
          <th>Permission</th>
          <th>Action</th>
        </tr>

      </thead >

      <tbody>

        @forelse($permissions as $permission)

        <tr>
          <td><a href="{{route('editPermission', ['pId'=>$permission->id])}}">{{$permission->name}}</a></td>
          <td><a href="{{route('deletePermission', ['pId'=>$permission->id])}}" class="btn btn-danger">Delete</a> </td>
        </tr>
      
        @empty
          <tr>
            <td>There are no permissions</td>
            <td>No action</td>
          </tr>
        @endforelse

      </tbody>

    </table>




@endsection