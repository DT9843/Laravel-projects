@extends('base')

@section('title', 'Admin dashboard')

@section('body')
@include('admin.nav')
<div class="container">

    @canany(['view activities','view destinations','view regions','view trips','view all'])


        <table class="table">

            <thead>
                <tr>
                    <th>Trip models</th>
                </tr>
            </thead>

            <tbody>
                @canany(['view activities','view all'])
                    <tr>
                    <td> <a href="{{route('activities')}}">Activities</a></td>
                    </tr>
                @endcanany


                @canany(['view destinations','view all'])
                    <tr>
                    <td><a href="{{route('destinations')}}">Destinations</a></td>
                    </tr>
                @endcanany


                @canany(['view regions','view all'])
                    <tr>
                    <td><a href="{{route('trekkingRegions')}}">Trekking Regions</a></td>
                    </tr>
                @endcanany

                @canany(['view costs','view all'])
                    <tr>
                    <td><a href="{{route('costs')}}">Costs</a></td>
                    </tr>
                @endcanany

                @canany(['view gearandequipments','view all'])
                    <tr>
                    <td><a href="{{route('gearequipments')}}">Gear And Equipments</a></td>
                    </tr>
                @endcanany

                @canany(['view trips','view all'])
                    <tr>
                    <td><a href="{{route('trips')}}">Trips</a></td>
                    </tr>
                @endcanany



            </tbody>

        </table>
    @endcanany

    @canany(['view agencies','view locations','view all'])    
        <table class="table">

            <thead>
                <tr>
                    <th>Agnecy models</th>
                </tr>
            </thead>

            <tbody>
                @canany(['view agencies','view all'])
                    <tr>
                    <td>  <a href="{{route('agencies')}}">Agencies</a></td>
                    </tr>
                @endcanany

                @canany(['view locations','view all'])
                    <tr>
                    <td><a href="{{route('locations')}}">Locations</a></td>
                    </tr>
                @endcanany
            </tbody>

        </table>

    @endcanany

    @canany(['view users','view roles','view permissions','view all'])    
        
        <table class="table">

            <thead>
                <tr>
                    <th>User Authorization</th>
                </tr>
            </thead>

            <tbody>
                @canany(['view users','view all'])
                    <tr>
                        <td><a href="{{route('users')}}">Users</a></td>
                    </tr>
                @endcanany


                @canany(['view roles','view all'])
                    <tr>
                        <td><a href="{{route('roles')}}">Roles</a></td>
                    </tr>
                @endcanany


                @canany(['view permissions','view all'])
                    <tr>
                        <td><a href="{{route('permissions')}}">Permissions</a></td>
                    </tr>
                @endcanany

            </tbody>

        </table>

    @endcanany

</div>

@endsection