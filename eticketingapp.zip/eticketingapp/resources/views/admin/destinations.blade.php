@extends('base')


@section('title', 'Destinations')


@section('body')
@include('admin.nav')
    <a href="{{route('createDestination')}}">create</a>

    <table class="table">

        <thead>

            <tr>

                <th>Activity</th>
                <th>Action</th>

            </tr>


        </thead>

        <tbody>
            @forelse($destinations as $destination)
                <tr>

                    <td><a href="{{route('editDestination',['dId'=>$destination->id])}}">{{$destination->country}}</a></td>
                    <td>
                        <a href="{{route('deleteDestination',['dId'=>$destination->id])}}" class="btn btn-danger">Delete</a>
                    </td>

                </tr>
            @empty
                <tr>
                    <td>There are no destinations.</td>
                    <td>Action not available</td>
                </tr>
            @endforelse
        </tbody>



    </table>


@endsection