@extends('base')


@section('title', 'Agencies')


@section('body')
@include('admin.nav')
    <a href="{{route('createAgency')}}">create</a>

    <table class="table">

        <thead>

            <tr>

                <th>Agency Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Tel Number</th>
                <th>Location</th>
                <th>Action</th>

            </tr>


        </thead>

        <tbody>
            @foreach($agencies as $ag)
                <tr>

                    <td><a href="{{route('editAgency',['aId'=>$ag->id])}}">{{$ag->agency_name}}</a></td>
                    <td>{{$ag->email}}</td>
                    <td>{{$ag->phone_number}}</td>
                    <td>{{$ag->tel_number}}</td>
                    <td>{{$ag->location->name}}</td>
                    <td>
                        <a href="{{route('deleteAgency',['aId'=>$ag->id])}}" class="btn btn-danger">Delete</a>
                    </td>

                </tr>
            @endforeach
        </tbody>



    </table>


@endsection