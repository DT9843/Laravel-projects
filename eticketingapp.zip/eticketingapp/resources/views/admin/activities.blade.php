@extends('base')


@section('title', 'Activities')


@section('body')

    @include('admin.nav')


    <a href="{{route('createActivity')}}">create</a>

    <table class="table">

        <thead>

            <tr>

                <th>Activity</th>
                <th>Action</th>

            </tr>


        </thead>

        <tbody>
            @foreach($activities as $activity)
                <tr>

                    <td><a href="{{route('editActivity',['aId'=>$activity->id])}}">{{$activity->activity}}</a></td>
                    <td>
                        <a href="{{route('deleteActivity',['aId'=>$activity->id])}}" class="btn btn-danger">Delete</a>
                    </td>

                </tr>
            @endforeach
        </tbody>



    </table>


@endsection