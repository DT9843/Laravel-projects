@extends('base')


@section('title', "Edit faq's")

@section('body')
@include('admin.nav')
    <form action="{{route('updateFaq', ['tripId'=>$tripId, 'fId'=>$fId])}}" method="post">

        @csrf

        <div>
            <label for="">Question</label>
            <input type="text" name="question" value="{{$faq->question}}" required>
        </div>

        
        <div>
            <label for="">Answer</label>
            <textarea name="answer" id="" cols="30" rows="10">
                {{$faq->answer}}
            </textarea>
        </div>

        <input type="submit" class="btn btn-warning" value="Edit">

    </form>


@endsection