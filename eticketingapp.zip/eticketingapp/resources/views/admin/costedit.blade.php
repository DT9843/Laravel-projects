@extends('base')


@section('title', 'Edit cost description')


@section('body')
@include('admin.nav')
    <form action="{{route('updateCost', ['tripId'=>$tripId, 'cId'=>$cId, 'cPid'=>$cost->pivot->id])}}" method="post">

        @csrf
        <div>
            <label for="">Description</label>
            <input type="text" name="description" value="{{$cost->pivot->description}}" required>
        </div>

        <input type="submit" class="btn btn-warning" value="Edit">

    </form>



@endsection