@extends('base')

@if($edit)
    @section('title', 'Edit gear and equipment')
@else
    @section('title', 'Create gear and equipment')
@endif


@section('body')
@include('admin.nav')
    @if($edit)

        <form action="{{route('saveEditGearEquipment',['geId'=>$ge->id])}}" method="post">

            @csrf
            <div>
                <label for="">Gear Or Equipment</label>
                <input type="text" name="ge" value="{{$ge->list}}" required>
            </div>

            <input type="submit" value="Edit" class="btn btn-warning">
        </form>

    @else
        <form action="{{route('saveGearEquipment')}}" method="post">

        @csrf
            <div>
                <label for="">Gear Or Equipment</label>
                <input type="text" name="ge" required>
            </div>

            <input type="submit" value="Add" class="btn btn-primary">
        </form>
    @endif


@endsection