@extends('base')


@section('title', 'Create permission')


@section('body')
@include('admin.nav')
    @if($edit)
    <form action="{{route('editSavePermission',['pId'=>$permission->id])}}" method="post">
    @else
    <form action="{{route('savePermission')}}" method="post">
    @endif
        @csrf
        <div>
            <label for="">Permission</label>
            @if($edit)
            <input type="text" name="permission" value="{{$permission->name}}" required>
            
            @else
            <input type="text" name="permission" required>
            
            @endif
        </div>

        @if($edit)
        <input type="submit" value="Edit Permission" class="btn btn-warning">
        @else
        <input type="submit" value="Add Permission" class="btn btn-primary">
        @endif
    </form>

@endsection



