@extends('base')

@if($edit)
    @section('title', 'Edit user')
@else
    @section('title', 'Create new user')
@endif

@section('body')
@include('admin.nav')
    @if($edit)

        <form action="{{route('saveEditUser',['uId'=>$user->id])}}" method="post">
            @csrf
            <div>

                <label for="">Full Name</label>
                <input type="text" name="full_name" value="{{$user->full_name}}" required>

            </div>

            <div>

                <label for="">Email</label>
                <input type="email" name="email" value="{{$user->email}}" required>

            </div>

            <div>

                <label for=""></label>
                <input type="number" name="phone_number" value="{{$user->phone_number}}" min="10" required>

            </div>

            <div>

                <label for="">Gender</label>
                <br/>
                @foreach($genders as $gender)
                    @if($gender->id === $user->gender_id)
                        <label for="">{{$gender->sex}}</label>
                        <input type="radio" name="gender" value="{{$gender->id}}" checked>
                    @else
                        <label for="">{{$gender->sex}}</label>
                        <input type="radio" name="gender" value="{{$gender->id}}">
                    @endif
                @endforeach
            </div>

            <input type="submit" value="Edit" class="btn btn-warning">
        </form>

        <h2>User Roles</h2>

        <table class="table">

            <thead>

                <tr>
                    <th>Role</th>
                    <th>Action</th>
                </tr>

            </thead>


            <tbody>

                @foreach($user->roles as $ur)  

                    <tr>
                        <td>{{$ur->name}}</td>
                        <td> <a href="{{route('deleteUserRole', ['uId'=>$user->id, 'role'=>$ur->name])}}">Delete</a> </td>
                    </tr>

                @endforeach
            </tbody>


        </table>

        <form action="{{route('assignRoleToUser', ['uId'=>$user->id])}}" method = "post">
            @csrf
            <input type="text" name="roles" id="userRoles" placeholder="Donot type select only" required>
            <select id="roles">

                <option value="">None</option>
                @foreach($roles as $r)

                    <option value="{{$r->name}}">{{$r->name}}</option>

                @endforeach

            </select>

            <input type="submit" value="Assign role to user" class="btn btn-primary">
        </form>



        <a href="{{route('deleteUser',['uId'=>$user->id])}}" class="btn btn-danger">Delete</a>

        @vite('resources/js/user.js')
    @else

        <form action="{{route('saveUser')}}" method="post">
            @csrf
            <div>

                <label for="">Full Name</label>
                <input type="text" name="full_name" required>

            </div>

            <div>

                <label for="">Email</label>
                <input type="email" name="email" required>

            </div>

            <div>

                <label for="">Phone Number</label>
                <input type="number" name="phone_number" min="10" required>

            </div>

            <div>

                <label for="">Password</label>
                <input type="password" name="password" min="10" required>

            </div>

            <div>

                <label for="">Confirm Password</label>
                <input type="password" name="password_confirmation" min="10" required>

            </div>

            <div>
                <label for="">Gender</label>
         
                @foreach($genders as $gender)
                        <label for="">{{$gender->sex}}</label>
                        <input type="radio" name="gender" value="{{$gender->id}}">
                @endforeach
            </div>

            <input type="submit" value="Create" class="btn btn-primary">

        </form>


    @endif



@endsection