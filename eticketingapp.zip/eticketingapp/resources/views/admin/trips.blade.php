@extends('base')

@section('title' , 'Display trips')


@section('body')
@include('admin.nav')
    @canany(['create trip', 'create all'])
        <a href="{{route('createTrip')}}" class="btn btn-primary">Create trip</a>
    @endcanany

    <table class="table">

        <thead>


            <tr>
                <th>Trips</th>
            </tr>


        </thead>

        <tbody>


            @foreach($trips as $trip)
                <tr>
                    <td> <a href="{{route('trip',['id'=>$trip->id])}}">{{$trip->trip_name}}</a></td>
                </tr>
               
            @endforeach



        </tbody>

    </table>


@endsection