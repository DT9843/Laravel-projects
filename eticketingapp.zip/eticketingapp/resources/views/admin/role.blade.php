@extends('base')


@section('title', 'Create role')


@section('body')
@include('admin.nav')
    <form action="{{route('saveRole')}}" method="post">
        @csrf
        <div>
            <label for="">Role</label>
            <input type="text" name="role" required>
        </div>

        <input type="submit" value="Add Role" class="btn btn-primary">
    </form>

@endsection



