@extends('base')

@if($edit)
    @section('title', 'Trekking Region Edit Form')
@else
    @section('title', 'Trekking Region Create Form')
@endif

@section('body')
@include('admin.nav')
    @if($edit)
    <form action="{{route('saveEditDestination',['dId'=>$destination->id])}}" method="post">
    @else
    <form action="{{route('saveDestination')}}" method="post">
    @endif
    
        @csrf

        <div>
            <label for="">Destination</label>
            @if($edit)
            <input type="text" name="destination" value="{{$destination->country}}" required>
            @else
            <input type="text" name="destination" required>
            @endif
        </div>
        @if($edit)
        <input type="submit" value="Edit" class="btn btn-warning">
        @else
        <input type="submit" value="Add" class="btn btn-primary">
        @endif
    </form>


@endsection