@extends('base')


@section('title', 'Users')


@section('body')    
@include('admin.nav')

    <a href="{{route('createUser')}}">create</a>

    <table class="table">

        <thead>

            <tr>
                <th>Full Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Gender</th>

            </tr>


        </thead>

        <tbody>
            @foreach($users as $user)
                <tr>

                    <td><a href="{{route('editUser',['uId'=>$user->id])}}">{{$user->full_name}}</a></td>
                    <td>{{$user->email}}</td>
                    <td>{{$user->phone_number}}</td>
                    <td>{{$user->gender->sex}}</td>

                </tr>
            @endforeach
        </tbody>



    </table>


@endsection