@extends('base')

@if($edit)
@section('title', 'Trekking Region Edit Form')
@else
@section('title', 'Trekking Region Create Form')
@endif

@section('body')
@include('admin.nav')
    @if($edit)
    <form action="{{route('saveEditTrekkingRegion',['rId'=>$region->id])}}" method="post">

            @csrf

        <div>

            <label for="">Country</label>
            <select name="country" id="region" required>
                <option value="">None</option>
                @foreach($countries as $country)
                    @if($country->id == $region->country_id)

                        <option value="{{$country->id}}" selected>{{$country->country}}</option>

                    @else

                        <option value="{{$country->id}}">{{$country->country}}</option>

                    @endif
                @endforeach
            </select>
        </div>


        <div>
            <label for="">Region</label>
            <input type="text" name="trekkingregion" value="{{$region->region}}" required>
        </div>


        <input type="submit" value="Edit" class="btn btn-warning">
        </form>
    @else
        <form action="{{route('saveTrekkingRegion')}}" method="post">
    
            @csrf

            <div>

                <label for="">Country</label>
                <select name="country" id="region" required>
                    <option value="">None</option>
                    @foreach($countries as $country)
                    <option value="{{$country->id}}">{{$country->country}}</option>
                    @endforeach
                </select>
            </div>


            <div>
                <label for="">Region</label>
                <input type="text" name="trekkingregion" required>
            </div>


            <input type="submit" value="Add" class="btn btn-primary">
        </form>
    @endif

@endsection