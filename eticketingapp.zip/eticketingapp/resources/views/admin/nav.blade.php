
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid ">
		<a class="navbar-brand " href="#">Admin Panel</a>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		  <span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
		  <ul class="navbar-nav ">
			<li class="nav-item">
			  <a class="nav-link active" href="{{route('adminDashboard')}}">Home</a>
			</li>
			@auth
				<!-- <li class="nav-item">
				<a class="nav-link active" href="">Profile</a>
				</li>		 -->
				<li class="nav-item">
				<a class="nav-link active" href="{{route('logout')}}">Logout</a>
				</li>			
			@endauth


		  </ul>		  
		</div>
	</div>
</nav>