@extends('base')

@if($edit)
    @section('title', 'Agency Edit Form')
@else
    @section('title', 'Agency Create Form')
@endif

@section('head')
  @vite('resources/css/style.css')
@endsection

@section('body')
@include('admin.nav')
@if($edit)

    <form action="{{route('saveEditAgency', ['aId'=>$agency->id])}}" method="post">

        @csrf

        <div>
            <label for="">Agency Name</label>
            <input type="text" name="agency_name" value="{{$agency->agency_name}}" required>
        </div>

        <div>

            <label for="">Location</label>
            <select name="location" id="locations" required>
                @foreach($countries as $country)
                    @foreach($country->location as $location)
                        @if($country->id == $agency->country_id && $location->id == $agency->location_id)
                            <option value="{{$location->id}} {{$country->id}}" selected>{{$location->name}}, {{$country->country}}</option>
                        @else
                            <option value="{{$location->id}} {{$country->id}}" >{{$location->name}}, {{$country->country}}</option>
                        @endif
                    @endforeach
                @endforeach
            </select>
        </div>

        
        <div>
            <label for="">Email</label>
            <input type="email"  name="email" value="{{$agency->email}}" required>
        </div>

        <div>
            <label for="">Phone Number</label>
            <input type="number" min="10" name="phone_number" value="{{$agency->phone_number}}">
        </div>

        <div>
            <label for="">Tele Phone Number</label>
            <input type="number" min="9" name="tel_number" value="{{$agency->tel_number}}" required>
        </div>



        <input type="submit" value="Edit" class="btn btn-warning">
    </form>

@else

    <form action="{{route('saveAgency')}}" method="post">

    @csrf

    <div>
        <label for="">Agency Name</label>
        <input type="text" name="agency_name" required>
    </div>

    <div>

        <label for="">Location</label>
        <select name="location" id="locations">
            <option value="" selected>None</option>
            @foreach($countries as $country)
        
                @foreach($country->location as $location)
                    <option value="{{$location->id}} {{$country->id}}" >{{$location->name}}, {{$country->country}}</option>
                @endforeach
        

            @endforeach


            
        </select>
    </div>


    <div>
        <label for="">Email</label>
        <input type="email"  name="email" required>
    </div>

    <div>
        <label for="">Phone Number</label>
        <input type="number" min="10" name="phone_number">
    </div>

    <div>
        <label for="">Tele Phone Number</label>
        <input type="number" min="9" name="tel_number" required>
    </div>



    <input type="submit" value="Add" class="btn btn-primary">
    </form>


@endif

@vite('resources/js/agency.js')
@endsection