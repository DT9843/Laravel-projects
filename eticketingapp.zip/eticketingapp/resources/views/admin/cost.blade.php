@extends('base')


@if($edit)
    @section('title', 'Edit cost')
@else
    @section('title', 'Create cost')
@endif

@section('body')
@include('admin.nav')
    @if($edit)
        <form action="{{route('saveEditCost',['cId'=>$cost->id])}}" method="post">

            @csrf
            <div>
                <label for="">Cost Type</label>
                <input type="text" name="type" value="{{$cost->type}}" required>
            </div>

            <input type="submit" value="Edit" class="btn btn-warning">
        </form>
    @else
        <form action="{{route('saveCost')}}" method="post">

        @csrf
            <div>
                <label for="">Cost Type</label>
                <input type="text" name="type" required>
            </div>

            <input type="submit" value="Add" class="btn btn-primary">
        </form>

    @endif

@endsection