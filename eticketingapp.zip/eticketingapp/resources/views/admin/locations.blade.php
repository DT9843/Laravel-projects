@extends('base')


@section('title', 'Locations')


@section('body')
@include('admin.nav')
    <a href="{{route('createLocation')}}">create</a>

    <table class="table">

        <thead>

            <tr>

                <th>Location</th>
                <th>Country</th>
                <th>Action</th>

            </tr>


        </thead>

        <tbody>
            @foreach($locations as $loc)
                <tr>

                    <td><a href="{{route('editLocation',['lId'=>$loc->id])}}">{{$loc->name}}</a></td>
                    <td>{{$loc->country->country}}</td>
                    <td>
                        <a href="{{route('deleteLocation',['lId'=>$loc->id])}}" class="btn btn-danger">Delete</a>
                    </td>

                </tr>
            @endforeach
        </tbody>



    </table>


@endsection