@extends('base')


@section('title', 'Edit highlight')

@section('body')
@include('admin.nav')
    <form action="{{route('updateHighlight', ['tripId'=>$tId, 'hId'=>$hId])}}" method="post">

        @csrf

        <div>
            <label for="">Highlight</label>
            <input type="text" name="highlight" value="{{$hl->highlight}}" required>
        </div>

        <input type="submit" class="btn btn-warning" value="Edit">

    </form>


@endsection