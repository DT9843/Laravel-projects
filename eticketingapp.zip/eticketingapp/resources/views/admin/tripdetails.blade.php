@extends('base')


@section('title') {{$trip->trip_name}} trip details @endsection
@section('head') 

<meta name="csrf-token" content="{{ csrf_token() }}">

@endsection
@include('admin.nav')
@section('body')

    @php
        $tId = $trip->id;
    @endphp



<div class="container">


    <h3>Trekking Details</h3>
    <form action="{{route('updateTrip', ['tripId'=>$trip->id])}}" method="post">
        @csrf
        <div>

            <label for="">Trip Name</label>
            <input type="text" name="trip_name" value="{{$trip->trip_name}}" required>

        </div>

        <div>

            <label for="">Trip Cost</label>
            <input type="number" name="trip_cost" value="{{$trip->trip_cost}}" required>
        </div>

        <div>

            <label for="">Trip Duration</label>
            <input type="number" name="trip_duration" value="{{$trip->duration}}" required>
        </div>  

        <div>
            <label for="">Trip Description</label>
            <textarea name="description" id="" cols="30" rows="10">
                {{$trip->description}}
            </textarea>
        </div>

        <div>
            <label for="">Destination</label>
            <select name="destination" id="">
                @foreach($destinations as $d)
                    @if($d->country === $trip->destination->country)
                        <option value="{{$d->id}}" selected>{{$d->country}}</option>
                    @else
                        <option value="{{$d->id}}">{{$d->country}}</option>
                    @endif
                @endforeach
            </select>
        </div>


        <div>
            <label for="">Activities</label>
            <select name="activity" id="">
                @foreach($activities as $a)
                    @if($a->activity === $trip->activity->activity)
                        <option value="{{$a->id}}" selected>{{$a->activity}}</option>
                    @else
                        <option value="{{$a->id}}">{{$a->activity}}</option>
                    @endif
                @endforeach
            </select>
        </div>

        <div>
            <label for="">Region</label>
            <select name="region" id="">
                @foreach($regions as $r)
                    @if($r->region === $trip->region->region)
                        <option value="{{$r->id}}" selected>{{$r->region}}</option>
                    @else
                        <option value="{{$r->id}}">{{$r->region}}</option>
                    @endif
                @endforeach
            </select>
        </div>

        
        <div>
            <label for="">Agency</label>
            <select name="agency" id="">
                @foreach($agencies as $a)
                    @if($a->agency_name === $trip->agency->agency_name)
                        <option value="{{$a->id}}" selected>{{$a->agency_name}}</option>
                    @else
                        <option value="{{$a->id}}">{{$a->agency_name}}</option>
                    @endif
                @endforeach
            </select>
        </div>

        <input type="submit" value="Edit" class="btn btn-warning">
    </form>

    <fieldset class="highlights" >

        <legend>Highlights</legend>
        <table class="table table-hover table-bordered" >

            <thead>
                <tr>
                    <th>Highlights</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                @foreach($trip->highlights as $highlight)
                <tr>
                    <td>{{$highlight->highlight}}</td>
                    <td> 
                        <a href="{{route('showHighlightForm',['tripId'=>$trip->id, 'hId'=>$highlight->id])}}" class="btn btn-warning">Edit</a> 
                        <a href="{{route('deleteHighlight',['tripId'=>$trip->id, 'hId'=>$highlight->id])}}" class="btn btn-danger">Delete</a>
                    </td>
                </tr>
                @endforeach

            </tbody>

        </table>

        <button class="highlight" data-highlight="{{route('saveTripHighlight', ['tripId'=>$tId])}}">Add Highlight</button>
    </fieldset>


    <fieldset class="itinerary">
        <legend>Itinerary Details</legend>

        <table class="table table-hover table-bordered">
            <thead>
                <tr>
                    <th>Day</th>
                    <th>Day Activity</th>
                    <th>Activity description</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

                @for($i=0; $i<count($trip->itinerary); $i++)
                    <tr>
                        <td><b>Day {{$i+1}}</b></td>
                        <td><b>{{$trip->itinerary[$i]->activity}}</b></td>
                        <td>{{$trip->itinerary[$i]->activity_description}}</td>
                        <td> 
                            <a href="{{route('showItinerary', ['tripId'=>$tId, 'itnId'=>$trip->itinerary[$i]->id])}}" class="btn btn-warning">Edit</a> 
                            <a href="{{route('deleteItinerary' , ['tripId'=>$tId, 'itnId'=>$trip->itinerary[$i]->id])}}" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                @endfor
            </tbody>
        </table>
       
        <button id="add-itinerary"  data-trip-itinerary = "{{route('saveItinerary',['id'=>$trip->id])}}">Add Itinerary</button>
    </fieldset>
    
    <fieldset class="costs">

        <legend>Cost Include & Exclude</legend>
       
        @foreach($costs as $cost)
        <h3>{{$cost->type}}</h3>
        <table class="table table-hover table-bordered"> 
            <thead>
                <tr>
                    <th>{{$cost->type}}</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
            @foreach($trip->cost as $c)

                        
                @if($cost->id === $c->id)
                    <tr>
                        <td>{{$c->pivot->description}}</td>
                        <td> 
                            <a href="{{route('showCost',['tripId'=>$tId, 'cId'=>$c->id, 'cPid'=>$c->pivot->id])}}" class="btn btn-warning">Edit</a> 
                            <a href="{{route('deleteTripCost', ['tripId'=>$tId, 'cId'=>$c->id, 'cPid'=>$c->pivot->id])}}" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>

                @endif


            @endforeach
                
            </tbody>
        </table>
            
            <button class="cost" data-cost-id="{{route('saveTripCost',['tripId'=>$tId, 'costId'=>$cost->id])}}">Add {{$cost->type}}</button>
        @endforeach
    </fieldset>

    <fieldset class="gearequipment">

        <legend>Gear and Equipment</legend>
        @foreach($ge as $g)

            <h3>{{$g->list}}</h3>
            <table class="table table-hover table-bordered">

                <thead>
                    <tr>
                        <th>Equipment and Gears</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    @foreach($trip->gearEquipment as $tge)
                        @if($tge->id === $g->id)
                            <tr>
                                <td>{{$tge->pivot->list}}</td>    
                                <td> 
                                    <a href="{{route('showGearAndEquipment', ['tripId'=>$tId, 'geId'=>$g->id, 'gePid'=>$tge->pivot->id])}}" class="btn btn-warning">Edit</a> 
                                    <a href="{{route('deleteGearAndEquipment', ['tripId'=>$tId, 'geId'=>$g->id, 'gePid'=>$tge->pivot->id])}}" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                        @endif
                    @endforeach
                </tbody>


            </table>
            <button class="ge" data-ge= "{{route('saveTripGearEquipment',['tripId'=>$tId, 'gearEquipmentId'=>$g->id])}}">Add {{$g->list}}</button>
        @endforeach

    </fieldset>



    <fieldset class="faqs">

        <legend>FAQ's</legend>

        <table class="table table-hover table-bordered">

            <thead>
                <tr>
                    <th>Questions</th>
                    <th>Answers</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                @foreach($trip->faq as $faq)
                    <tr>
                    
                            <td><b>{{$faq->question}}</b></td>
                            <td>{{$faq->answer}}</td>
                            <td> 
                                <a href="{{route('showFaq',['tripId'=>$tId, 'fId'=>$faq->id])}}" class="btn btn-warning">Edit</a> 
                                <a href="{{route('deleteFaq', ['tripId'=>$tId, 'fId'=>$faq->id])}}" class="btn btn-danger">Delete</a>
                            </td>
                    
                    </tr>
                @endforeach
            </tbody>

        </table>
           
        
        <button class="faq" data-faq="{{route('saveTripFaq', ['tripId'=>$tId])}}">Add FAQ</button>
    </fieldset>

    <img src="{{url($trip->trip_photo)}}" alt="" >
    <form action="{{route('updateTripPhoto', ['tripId'=>$tId])}}" method="post" enctype= "multipart/form-data">
        @csrf
        <div>
            <label for="">Update Front Photo</label>
            <input type="file" name="front_image" id="" required>
        </div>

        <input type="submit" class="btn btn-warning" value="Edit Front Photo">

    </form>

    <img src="{{url($trip->route_photo)}}" alt="">
    <form action="{{route('updateRoutePhoto', ['tripId'=>$tId])}}" method="post" enctype= "multipart/form-data">
        @csrf
        <div>
            <label for="">Update Route Photo</label>
            <input type="file" name="route_image" id="" required>
        </div>
        <input type="submit" class="btn btn-warning" value="Edit Route Photo">
    </form>

    <fieldset>
        <legend>Publish Details</legend>

        <form action="{{route('updatePublish', ['tripId'=>$tId])}}" method="post">
            @csrf
            <div>
                @if($trip->is_published)
                    <label for="">Uncheck to unpublish</label>
                    <input type="checkbox" name="publish" checked >
                @else
                    <label for="">Check to publish</label>
                    <input type="checkbox" name="publish" >
                @endif
            </div>

            <input type="submit" value="Submit publish" class="btn btn-warning">
        </form>
    </fieldset>
</div>
@vite('resources/js/trip.js')

@endsection
