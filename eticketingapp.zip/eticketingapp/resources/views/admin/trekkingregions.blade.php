@extends('base')


@section('title', 'Trekking region')


@section('body')
@include('admin.nav')
    <a href="{{route('createTrekkingRegion')}}">create</a>

    <table class="table">

        <thead>

            <tr>

                <th>Trekking Region</th>
                <th>Action</th>

            </tr>


        </thead>

        <tbody>
            @foreach($regions as $tr)
                <tr>

                    <td><a href="{{route('editTrekkingRegion',['rId'=>$tr->id])}}">{{$tr->region}}</a></td>
                    <td>
                        <a href="{{route('deleteTrekkingRegion',['rId'=>$tr->id])}}" class="btn btn-danger">Delete</a>
                    </td>

                </tr>
            @endforeach
        </tbody>



    </table>


@endsection