@extends('base')


@section('title', 'Costs')


@section('body')
@include('admin.nav')
    <a href="{{route('createCost')}}">create</a>

    <table class="table">

        <thead>

            <tr>

                <th>Cost</th>
                <th>Action</th>

            </tr>


        </thead>

        <tbody>
            @foreach($costs as $cost)
                <tr>

                    <td><a href="{{route('editCost',['cId'=>$cost->id])}}">{{$cost->type}}</a></td>
                    <td>
                        <a href="{{route('deleteCost',['cId'=>$cost->id])}}" class="btn btn-danger">Delete</a>
                    </td>

                </tr>
            @endforeach
        </tbody>



    </table>


@endsection