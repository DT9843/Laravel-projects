@extends('base')

@if($edit)
    @section('title', 'Location Edit Form')
@else
    @section('title', 'Location Create Form')
@endif

@section('body')
@include('admin.nav')
    @if($edit)

    <form action="{{route('saveEditLocation', ['lId'=>$location->id])}}" method="post">

        @csrf

        <div>
            <label for="">Location</label>
            <input type="text" name="location" value="{{$location->name}}"  required>
        </div>


        <div>

            <label for="">Country</label>
            <select name="country" id="" required>
                @foreach($countries as $country)
                    @if($location->country_id == $country->id)
                    <option value="{{$country->id}}" selected>{{$country->country}} </option>
                    @else
                    <option value="{{$country->id}}">{{$country->country}} </option>
                    @endif
                @endforeach
            </select>
        </div>


        <input type="submit" value="Edit" class="btn btn-warning">
    </form>
    @else
        <form action="{{route('saveLocation')}}" method="post">

            @csrf

            <div>
                <label for="">Location</label>
                <input type="text" name="location" required>
            </div>


            <div>

                <label for="">Country</label>
                <select name="country" id="" required>
                    <option value="">None</option>
                    @foreach($countries as $country)
                        <option value="{{$country->id}}">{{$country->country}} </option>
                    @endforeach
                </select>
            </div>
        

            <input type="submit" value="Add" class="btn btn-primary">
        </form>
    @endif
@endsection