@extends('base')


@section('title', 'roles')


@section('body')
@include('admin.nav')
<div class="container">
    <a href="{{route('createRole')}}">Create role</a>
    <table class="table">

      <thead>
        <tr>
          <th>Roles</th>
        </tr>
      </thead>

      <tbody>

        
        @forelse($roles as $role)
          <tr>
          <td> <a href="{{route('assignPermissionToRoleForm', ['roleId'=>$role->id])}}">{{$role->name}}</a></td>
          </tr>
        @empty
            <p>There are no roles</p>
        @endforelse
        


      </tbody>


    </table>


</div>


@endsection