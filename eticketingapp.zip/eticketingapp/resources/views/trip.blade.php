@extends('base')


@section('title')
    {{$trip->trip_name}} details
@endsection

@section('head')
    @vite('resources/css/style.css')
@endsection

@section('body')

@include('nav')

<div class="container">
   <h1>{{$trip->trip_name}}</h1> 
   <div class="d-flex justify-content-between">
    <img src="{{url($trip->trip_photo)}}" height="490px" width="850px" alt="">

    <div>
        @if($trip->discount_price === 0)
            <p><b>From: {{$trip->trip_cost}}</b></p>
        @else
           <p>From <del>{{$trip->trip_cost}}</del></p> 
           <b>{{$trip->discount_price}}</b>
        @endif
    </div>

   </div>
    <p>{{$trip->description}}</p>

    <div>
        <h1>Trip Details</h1>
        <ul class="trip-details">
            <li class="btn btn-secondary  td-btn">HIGHLIGHTS</li>
            <li class="btn btn-secondary  td-btn">ITINERARY</li>
            <li class="btn btn-secondary  td-btn">COST</li>
            <li class="btn btn-secondary  td-btn">EQUIPMENTS</li>
            <li class="btn btn-secondary  td-btn">MAP</li>
            <li class="btn btn-secondary  td-btn">FAQs</li>
        </ul>

        <div class="highlights td">
            <ul>
                @foreach($trip->highlights as $highlight)

                    <li>{{$highlight->highlight}}</li>

                @endforeach
            </ul>
        </div>

        <div class="itinerary td dp-none">
            @for($i=0; $i<count($trip->itinerary); $i++)

                <b>Day {{$i+1}}: {{$trip->itinerary[$i]->activity}}</b>
                <p>{{$trip->itinerary[$i]->activity_description}}</p>
            @endfor
        </div>

        <div class="cost td dp-none">
            <h3>Includes</h3>
            <ul>
                @foreach($trip->cost as $cost)

                
                    @if($cost->type === "Cost Include")
                        <li>{{$cost->pivot->description}}</li>
                    @endif


                @endforeach
            </ul>

            <h3>Excludes</h3>
            <ul>
                @foreach($trip->cost as $cost)
                
                    @if($cost->type === "Cost Exclude")
                        <li>{{$cost->pivot->description}}</li>
                    @endif

                @endforeach
            </ul>
        </div>

        <div class="equipments td dp-none">
            @foreach($ge as $e)
                <h3>{{$e->list}}</h3>
                <ul>
                    @foreach($trip->gearEquipment as $equipment)
                            
                        @if($e->list === $equipment->list)
                            <li>{{$equipment->pivot->list}}</li>
                        @endif

                    @endforeach
                </ul>
            @endforeach
        </div>


        <div class="map td dp-none">

            <img src="{{url($trip->route_photo)}}" height="400px" width="700px" alt="">


        </div>


        <div class="faqs td dp-none">
            @foreach($trip->faq as $faq)

                <h3>{{$faq->question}}</h3>
                <p><b>Answer:</b> {{$faq->answer}}</p>

            @endforeach
        </div>


    </div>

</div>

@vite('resources/js/tripdetails.js')
@endsection