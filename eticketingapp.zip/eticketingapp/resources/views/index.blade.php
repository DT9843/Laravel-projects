@extends('base')



@section('title', 'Welcome to home page')


@section('body')

    @include('nav')
<div class="container">
    <fieldset>


        <legend>Search Trips</legend>

        <form action="{{route('searchTrips')}}" class="d-flex" method="post">
            @csrf

            <div>

                <label for=""><b>Destination</b> </label>
                <select name="destination" id="">
                    <option value="" selected>None</option>
                    @foreach($destinations as $destination)
                        <option value="{{$destination->country}}">{{$destination->country}}</option>
                    @endforeach
                </select>

            </div>

            <div class="mx-2">

                <label for=""><b>Activities</b></label>
                <select name="activity" id="">
                    <option value="">None</option>
                    @foreach($activities as $activity)
                        <option value="{{$activity->activity}}">{{$activity->activity}}</option>
                    @endforeach
                </select>

            </div>



            <input type="submit" value="Search" class="btn btn-success">
        </form>

    </fieldset>
</div>

@endsection