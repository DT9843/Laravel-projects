<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{AdminController, 
    TrekkingRegion, 
    ActivityController, 
    AgencyController, 
    LocationController,
    TripController,
    ItineraryController,
    CostController,
    GearEquipmentController,
    HomeController,
    RolesController,
    PermissionController,
    DestinationController,
    UserController};

use App\Http\Controllers\Auth\AuthenticatedSessionController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [HomeController::Class, 'home'])->name('root');
Route::get('/home', [HomeController::class, 'index'])->name('home');
Route::post('/search/trips',[HomeController::class, 'searchResult'])->name('searchTrips');
Route::get('/search/trips/{destination}/{activity}',[HomeController::class, 'trips'])->name('searchResults');
Route::get('/search/trips/{destination}/{activity}/{region}', [HomeController::class, 'trips'])->name('searchByRegion');
Route::get('/trip/{activity}/{tripName}',[HomeController::class, 'showTripDetails'])->name('tripDetails');


Route::get('/admin/dashboard', [AdminController::class, 'showPage'])->name('adminDashboard');

// Displays database table data 
Route::get('/trips', [TripController::class, 'showTrips'])->name('trips')->middleware(['permission:view trips|view all']);
Route::get('/trekking/regions', [TrekkingRegion::class, 'showRegions'])->name('trekkingRegions')->middleware(['permission:view regions|view all']);
Route::get('/locations', [LocationController::class, 'showLocations'])->name('locations')->middleware(['permission:view locations|view all']);
Route::get('/agencies', [AgencyController::class, 'showAgencies'])->name('agencies')->middleware(['permission:view agencies|view all']);
Route::get('/roles', [RolesController::class, 'showRoles'])->name('roles')->middleware(['permission:view roles|view all']);
Route::get('/activities', [ActivityController::class, 'showActivities'])->name('activities')->middleware(['permission:view activities|view all']);
Route::get('/destinations', [DestinationController::class, 'showDestinations'])->name('destinations')->middleware(['permission:view destinations|view all']);
Route::get('/users', [UserController::class, 'showUsers'])->name('users')->middleware(['permission:view users|view all']);
Route::get('/permissions', [PermissionController::class, 'showPermissions'])->name('permissions')->middleware(['permission:view permissions|view all']);



// Insert data into table
Route::get('/create/trip', [TripController::class, 'showCreatePage'])->name('createTrip')->middleware(['permission:create trip|create all']);
Route::post('/save/trip', [TripController::class, 'create'])->name('saveTrip')->middleware(['permission:create trip|create all']);
Route::get('/create/trekking/region', [TrekkingRegion::class, 'createEdit'])->name('createTrekkingRegion')->middleware(['permission:create region|create all']);
Route::post('/save/trekking/region', [TrekkingRegion::class, 'createEdit'])->name('saveTrekkingRegion')->middleware(['permission:create region|create all']);
Route::get('/create/location', [LocationController::class, 'createEdit'])->name('createLocation')->middleware(['permission:create location|create all']);
Route::post('/save/location', [LocationController::class, 'createEdit'])->name('saveLocation')->middleware(['permission:create location|create all']);
Route::get('/create/activity', [ActivityController::class, 'createEdit'])->name('createActivity')->middleware(['permission:create activity|create all']);
Route::post('/save/activity', [ActivityController::class, 'createEdit'])->name('saveActivity')->middleware(['permission:create activity|create all']);
Route::get('/create/agency', [AgencyController::class, 'createEdit'])->name('createAgency')->middleware(['permission:create agency|create all']);
Route::post('/save/agency', [AgencyController::class, 'createEdit'])->name('saveAgency')->middleware(['permission:create agency|create all']);
Route::get('/create/role', [RolesController::Class, 'create'])->name('createRole')->middleware(['permission:create role|create all']);
Route::post('/save/role', [RolesController::Class, 'saveRole'])->name('saveRole')->middleware(['permission:create role|create all']);
Route::get('/create/permission', [PermissionController::Class, 'create'])->name('createPermission')->middleware(['permission:create permission|create all']);
Route::post('/save/permission', [PermissionController::Class, 'savePermission'])->name('savePermission')->middleware(['permission:create permission|create all']);
Route::get('/create/destination', [DestinationController::class, 'createEdit'])->name('createDestination')->middleware(['permission:create destination|create all']);
Route::post('/save/destination',  [DestinationController::class, 'createEdit'])->name('saveDestination')->middleware(['permission:create destination|create all']);
Route::get('/create/user', [UserController::class, 'createEdit'])->name('createUser')->middleware(['permission:create user|create all']);
Route::post('/save/user',  [UserController::class, 'createEdit'])->name('saveUser')->middleware(['permission:create user|create all']);


// Edit data of table
Route::get('/trip/{id}', [TripController::class, 'showTripDetails'])->name('trip')->middleware(['permission:edit trip|edit all']);
Route::post('/trip/edit/{tripId}', [TripController::class, 'updateTrip'])->name('updateTrip')->middleware(['permission:edit trip|edit all']);
Route::get('/edit/trekking/region/{rId}', [TrekkingRegion::class, 'createEdit'])->name('editTrekkingRegion')->middleware(['permission:edit region|edit all']);
Route::post('/save/edit/trekking/region/{rId}', [TrekkingRegion::class, 'createEdit'])->name('saveEditTrekkingRegion')->middleware(['permission:edit region|edit all']);
Route::get('/edit/location/{lId}', [LocationController::class, 'createEdit'])->name('editLocation')->middleware(['permission:edit location|edit all']);
Route::post('/save/edit/location/{lId}', [LocationController::class, 'createEdit'])->name('saveEditLocation')->middleware(['permission:edit location|edit all']);
Route::get('/edit/agency/{aId}', [AgencyController::class, 'createEdit'])->name('editAgency')->middleware(['permission:edit agency|edit all']);
Route::post('/save/edit/agency/{aId}', [AgencyController::class, 'createEdit'])->name('saveEditAgency')->middleware(['permission:edit agency|edit all']);
Route::post('/edit/role/{roleId}', [RolesController::class, 'edit'])->name('editRole')->middleware(['permission:edit role|edit all']);
Route::get('/assign/permission/to/role/{roleId}', [RolesController::class, 'assignPermissionToRoleForm'])->name('assignPermissionToRoleForm')->middleware(['permission:edit role|edit all']);
Route::get('/edit/permission/{pId}', [PermissionController::class, 'create'])->name('editPermission')->middleware(['permission:edit permission|edit all']);
Route::post('/edit/save/permission/{pId}', [PermissionController::class, 'edit'])->name('editSavePermission')->middleware(['permission:edit permission|edit all']);
Route::get('/edit/activity/{aId}',[ActivityController::class,'createEdit'])->name('editActivity')->middleware(['permission:edit activity|edit all']);
Route::post('/save/edit/activity/{aId}',[ActivityController::class,'createEdit'])->name('saveEditActivity')->middleware(['permission:edit activity|edit all']);
Route::get('/edit/destination/{dId}',  [DestinationController::class, 'createEdit'])->name('editDestination')->middleware(['permission:edit destination|edit all']);
Route::post('/save/edit/destination/{dId}',  [DestinationController::class, 'createEdit'])->name('saveEditDestination')->middleware(['permission:edit destination|edit all']);
Route::get('/edit/user/{uId}',  [UserController::class, 'createEdit'])->name('editUser')->middleware(['permission:edit user|edit all']);
Route::post('/save/edit/user/{uId}',  [UserController::class, 'createEdit'])->name('saveEditUser')->middleware(['permission:edit user|edit all']);


//Delete data from table
Route::get('/delete/trip/{tripId}',[TripController::class, 'delete'])->name('deleteTrip')->middleware(['permission:delete trip|delete all']);
Route::get('/delete/trekking/region/{rId}', [TrekkingRegion::class, 'delete'])->name('deleteTrekkingRegion')->middleware(['permission:delete region|delete all']);
Route::get('/delete/location/{lId}', [LocationController::class, 'delete'])->name('deleteLocation')->middleware(['permission:delete location|delete all']);
Route::get('/delete/agency/{aId}', [AgencyController::class, 'delete'])->name('deleteAgency')->middleware(['permission:delete agency|delete all']);
Route::get('/delete/role/{roleId}',[RolesController::class, 'delete'])->name('deleteRole')->middleware(['permission:delete role|delete all']);
Route::get('/delete/permission/{pId}', [PermissionController::class, 'delete'])->name('deletePermission')->middleware(['permission:delete permission|delete all']);
Route::get('/delete/activity/{aId}',[ActivityController::class, 'delete'])->name('deleteActivity')->middleware(['permission:delete activity|delete all']);
Route::get('/delete/destination/{dId}',  [DestinationController::class, 'delete'])->name('deleteDestination')->middleware(['permission:delete destination|delete all']);
Route::get('/delete/user/{uId}',  [UserController::class, 'delete'])->name('deleteUser')->middleware(['permission:delete user|delete all']);



//pending
Route::get('/costs', [CostController::class, 'showCosts'])->name('costs')->middleware(['permission:view costs|view all']);
Route::get('/create/cost', [CostController::class, 'createEdit'])->name('createCost')->middleware(['permission:create cost|create all']);
Route::post('/save/cost', [CostController::class, 'createEdit'])->name('saveCost')->middleware(['permission:create cost|create all']);
Route::get('/edit/cost{cId}', [CostController::class, 'createEdit'])->name('editCost')->middleware(['permission:edit cost|edit all']);
Route::post('/save/edit/cost/{cId}', [CostController::class, 'createEdit'])->name('saveEditCost')->middleware(['permission:edit cost|edit all']);
Route::get('/delete/cost/{cId}', [CostController::class, 'delete'])->name('deleteCost')->middleware(['permission:delete cost|delete all']);

Route::get('/gears/equipments', [GearEquipmentController::class, 'showGearEquipments'])->name('gearequipments')->middleware(['permission:view gearandequipments|view all']);
Route::get('/create/gear/equipment', [GearEquipmentController::class, 'createEdit'])->name('createGearEquipment')->middleware(['permission:create gearandequipment|create all']);
Route::post('/save/gear/equipment', [GearEquipmentController::class, 'createEdit'])->name('saveGearEquipment')->middleware(['permission:create gearandequipment|create all']);
Route::get('/edit/gear/equipment/{geId}', [GearEquipmentController::class, 'createEdit'])->name('editGearEquipment')->middleware(['permission:edit gearandequipment|edit all']);
Route::post('/save/edit/gear/equipment/{geId}', [GearEquipmentController::class, 'createEdit'])->name('saveEditGearEquipment')->middleware(['permission:edit gearandequipment|edit all']);
Route::get('/delete/gear/equipment/{geId}', [GearEquipmentController::class, 'delete'])->name('deleteGearEquipment')->middleware(['permission:delete gearandequipment|delete all']);


//Others
Route::post('/save/trip/cost/{tripId}/{costId}', [TripController::class, 'saveTripCost'])->name('saveTripCost')->middleware(['permission:edit trip|edit all']);
Route::post('/trip/edit/cost/{tripId}/{cId}/{cPid}', [TripController::class, 'updateCost'])->name('updateCost')->middleware(['permission:edit trip|edit all']);
Route::get('/trip/edit/cost/form/{tripId}/{cId}/{cPid}', [TripController::Class, 'showCostForm'])->name('showCost')->middleware(['permission:edit trip|edit all']);
Route::get('/trip/delete/cost/{tripId}/{cId}/{cPid}', [TripController::class, 'deleteCost'])->name('deleteTripCost')->middleware(['permission:edit trip|edit all']);

Route::post('/save/itinerary/{id}', [TripController::class, 'saveTripItinerary'])->name('saveItinerary')->middleware(['permission:edit trip|edit all']);
Route::post('/trip/edit/itinerary/{tripId}/{itnId}', [TripController::class, 'updateItinerary'])->name('updateItinerary')->middleware(['permission:edit trip|edit all']);
Route::get('/trip/edit/itinerary/form/{tripId}/{itnId}', [TripController::Class, 'showItineraryForm'])->name('showItinerary')->middleware(['permission:edit trip|edit all']);
Route::get('/trip/delete/itinerary/{tripId}/{itnId}', [TripController::class, 'deleteItinerary'])->name('deleteItinerary')->middleware(['permission:edit trip|edit all']);


Route::post('/save/trip/gear/equipment/{tripId}/{gearEquipmentId}', [TripController::class, 'saveTripGearEquipment'])->name('saveTripGearEquipment')->middleware(['permission:edit trip|edit all']);
Route::post('/save/trip/highlight/{tripId}', [TripController::class, 'saveTripHighlight'])->name('saveTripHighlight')->middleware(['permission:edit trip|edit all']);
Route::post('/save/trip/faq/{tripId}', [TripController::class, 'saveTripFaq'])->name('saveTripFaq')->middleware(['permission:edit trip|edit all']);


Route::post('/trip/edit/highlight/{tripId}/{hId}', [TripController::class, 'updateHighlight'])->name('updateHighlight')->middleware(['permission:edit trip|edit all']);
Route::get('/trip/edit/highlight/form/{tripId}/{hId}', [TripController::Class, 'showHighlightForm'])->name('showHighlightForm')->middleware(['permission:edit trip|edit all']);
Route::get('/trip/delete/highlight/{tripId}/{hId}', [TripController::class, 'deleteHighlight'])->name('deleteHighlight')->middleware(['permission:edit trip|edit all']);

Route::post('/trip/edit/faq/{tripId}/{fId}', [TripController::class, 'updateFaq'])->name('updateFaq')->middleware(['permission:edit trip|edit all']);
Route::get('/trip/edit/faq/form/{tripId}/{fId}', [TripController::Class, 'showFaqForm'])->name('showFaq')->middleware(['permission:edit trip|edit all']);
Route::get('/trip/delete/faq/{tripId}/{fId}', [TripController::class, 'deleteFaq'])->name('deleteFaq')->middleware(['permission:edit trip|edit all']);


Route::post('/trip/edit/gearequipment/{tripId}/{geId}/{gePid}', [TripController::class, 'updateGearAndEquipment'])->name('updateGearAndEquipment')->middleware(['permission:edit trip|edit all']);
Route::get('/trip/edit/gearequipment/form/{tripId}/{geId}/{gePid}', [TripController::Class, 'showGearAndEquipmentForm'])->name('showGearAndEquipment')->middleware(['permission:edit trip|edit all']);
Route::get('/trip/delete/gearequipment/{tripId}/{geId}/{gePid}', [TripController::class, 'deleteGearAndEquipment'])->name('deleteGearAndEquipment')->middleware(['permission:edit trip|edit all']);

Route::post('/trip/update/trip/photo/{tripId}', [TripController::class, 'updateTripPhoto'])->name('updateTripPhoto')->middleware(['permission:edit trip|edit all']);
Route::post('/trip/update/route/photo/{tripId}', [TripController::class, 'updateRoutePhoto'])->name('updateRoutePhoto')->middleware(['permission:edit trip|edit all']);

Route::post('/trip/update/publish/{tripId}', [TripController::class, 'updatePublish'])->name('updatePublish')->middleware(['permission:edit trip|edit all']);







Route::post('/save/assign/permission/to/role/{roleId}', [RolesController::class, 'assignPermissionToRole'])->name('assignPermissionToRole');
Route::get('/delete/role/permission/{roleId},{pId}',[RolesController::class,'deleteRolePermission'])->name('deleteRolePermission');



Route::post('/assign/role/to/user/{uId}',  [UserController::class, 'assignRoleToUser'])->name('assignRoleToUser');
Route::get('/delete/user/role/{uId}/{role}',  [UserController::class, 'deleteUserRole'])->name('deleteUserRole');

Route::get('/logout', [AuthenticatedSessionController::class, 'destroy'])->name('logout');

require __DIR__.'/auth.php';
