<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Location;

class Agency extends Model
{
    use HasFactory;

    protected $fillable=['country_id', 
    'location_id', 
    'agency_name', 
    'phone_number', 
    'tel_number', 
    'email'];


    public function location(){

        return $this->belongsTo(Location::class, 'location_id', 'id');
    }
}
