<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Costs;
use App\Models\GearEquipment;
use App\Modles\Hightlight;
use App\Models\Faq;
use App\Models\Country;
use App\Models\ItineraryDetails;
use App\Models\Activity;
use App\Models\TrekkingRegion;
use App\Models\Agency;


class Trip extends Model
{
    use HasFactory;

    protected $fillable = [
        'destination_id',
        "activity_id",
        "agency_id",
        "trekking_region_id",
        "trip_name",
        "trip_cost",
        "duration",
        "description",
        "trip_photo",
        "route_photo"
    ];

    public function cost(){

        return $this->belongsToMany(Cost::class, 'trip_cost', 'trip_id', 'cost_id')
        ->withPivot('id','description')
        ->withTimestamps();
    }


    public function gearEquipment(){
        return $this->belongsToMany(GearEquipment::class, 'trip_gear_equipment', 'trip_id', 'gear_equipment_id')
        ->withPivot('id','list')
        ->withTimestamps();
    }

    public function highlights(){
        return $this->hasMany(Highlight::class, 'trip_id', 'id');
    }

    public function faq(){
        return $this->hasMany(Faq::class, 'trip_id', 'id');
    }

    public function destination(){
        return $this->belongsTo(Country::class, 'destination_id', 'id');
    }

    public function activity(){

        return $this->belongsTo(Activity::class, 'activity_id', 'id');
    }

    public function region(){
        return $this->belongsTo(TrekkingRegion::class, 'trekking_region_id', 'id');
    }

    public function agency(){
        return $this->belongsTo(Agency::class, 'agency_id', 'id');
    }

    public function itinerary(){
        return $this->hasMany(ItineraryDetails::class, 'trip_id', 'id');
    }
    
}
