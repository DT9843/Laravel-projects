<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\{Location,
                TrekkingRegion};
class Country extends Model
{
    use HasFactory;

    protected $fillable = ['country'];

    public function location(){

        return $this->hasMany(Location::class, 'country_id', 'id'); 
    }

    public function region(){
        return $this->hasMany(TrekkingRegion::class, 'country_id', 'id');
    }
}
