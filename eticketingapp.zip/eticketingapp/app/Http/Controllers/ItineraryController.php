<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ItineraryDetails as ID;
class ItineraryController extends Controller
{
    //

    public function create(Request $request, int $id){

        ID::Create([
            "trip_id"=>$id,
            "activity"=>$request->activity,
            "activity_description"=>$request->activity_description
        ]);

        return "saved";

    }
}
