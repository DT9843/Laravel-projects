<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RolesController extends Controller
{
    
    public function __construct(){

        $this->middleware(['auth', 'afterLogin']);
    }

    public function showRoles(){

        return view('admin.roles', ["roles"=>Role::all()]);

    }


    public function create(){
        return view('admin.role');
    }

    public function saveRole(Request $request){


        Role::create(['name'=>$request->role]);
        return redirect()->route('roles');
    }

    public function edit(Request $request, int $roleId){

        $role = Role::find($roleId);
        $role -> name = $request->role;
        $role -> save();

        return redirect()->route('roles');

    }


    public function delete(int $id){

        Role::find($id)->delete();
        return redirect()->route('roles');
    }

    public function assignPermissionToRoleForm($roleId){


        return view('admin.assignpermissiontorole',['role'=>Role::find($roleId),
        "permissions"=>Permission::all()]);


    }

    public function assignPermissionToRole(Request $request, int $roleId){

        Role::find($roleId)->givePermissionTo(explode(',',$request->permissions));

        return redirect()->route('assignPermissionToRoleForm',['roleId'=>$roleId]);
    }

    public function deleteRolePermission(int $roleId, int $pId){


        Role::find($roleId)->revokePermissionTo($pId);

        return redirect()->route('assignPermissionToRoleForm', ['roleId'=>$roleId]);

    }

}
