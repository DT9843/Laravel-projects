<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\{Trip,
                Activity,
                Region,
                TrekkingRegion,
                Country,
                GearEquipment};

class HomeController extends Controller
{
    //

    public function __construct(){
        $this->middleware(['afterLogin']);
    }

    public function home(){

        return redirect()->route('home');
    }

    public function index(){


        return view('index',[
            "destinations"=>Country::all(),
            "activities"=>Activity::all()
        ]);
    }


    public function showTripDetails(string $activity, string $tripName){
        $trip = Trip::where([['trip_name', '=', $tripName], ['is_published', '=', true]])->first();
        if($trip){
            return view('trip', ['trip'=>$trip,
            "ge"=>GearEquipment::all()]);
        }
        return "Sorry trip not found";
    }       



    public function trips(string $destination, string $activity, string $region=null){

        $d = Country::where('country', '=', $destination)->first();
        $a = Activity::where('activity', '=', $activity)->first();
        $r = TrekkingRegion::where('region','=',$region)->first();

        if($region){
            $trips = Trip::where('destination_id', '=', $d->id)->
            where('activity_id', '=', $a->id)->
            where('trekking_region_id', '=', $r->id)->
            where('is_published', '=', true)->
            orderBy('created_at', 'asc')->get();
        }
        else{
            $trips = Trip::where('destination_id', '=', $d->id)->
            where('activity_id', '=', $a->id)->
            where('is_published', '=', true)->
            orderBy('created_at', 'asc')->get();
        }


        return view('trips', ["trips"=>$trips, "destination"=>$d, 
        "activity"=>$a,
        "destinations"=>Country::all(), 
        "activities"=>Activity::all(),
        "region"=>$r,
        "regions"=>TrekkingRegion::where('country_id', '=', $d->id)->get()
        ]);
    }


    public function searchResult(Request $request){
       

        return redirect()->route('searchResults', ["destination"=>$request->destination,
        "activity"=>$request->activity]);
    }

}
