<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Cost;

class CostController extends Controller
{
    //

    public function __construct(){

        $this->middleware(['auth', 'afterLogin']);
    }

    public function showCosts(){

        return view('admin.costs', ["costs"=>Cost::all()]);
    }

    public function createEdit(Request $request, int $cId = 0){

        $cost = Cost::find($cId);
        $edit = false;

        if($cost){
            $edit = true;
        }

        if($request->isMethod('get')){

            return view('admin.cost', ["edit"=>$edit, "cost"=>$cost]);
        }
        else if($request->isMethod('post')){

            if($edit){

                $cost->type = $request->type;
                $cost->save();

                return redirect()->route('editCost',["cId"=>$cId]);

            }

            else{

                Cost::create(["type"=> $request->type]);
                return redirect()->route('costs');
            }
        }

    }


    public function delete(int $cId){

        Cost::find($cId)->delete();

        return redirect()->route('costs');
    }
}
