<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\GearEquipment;

class GearEquipmentController extends Controller
{

    public function __construct(){

        $this->middleware(['auth', 'afterLogin']);
    }
    //
    public function showGearEquipments(){

        return view('admin.gearequipments', ["ges"=>GearEquipment::all()]);
    }

    public function createEdit(Request $request, int $geId = 0){

        $ge = GearEquipment::find($geId);
        $edit = false;

        if($ge){
            $edit = true;
        }

        if($request->isMethod('get')){

            return view('admin.gearequipment', ["edit"=>$edit, "ge"=>$ge]);
        }
        else if($request->isMethod('post')){

            if($edit){

                $ge->list = $request->ge;
                $ge->save();

                return redirect()->route('editGearEquipment',["geId"=>$geId]);

            }

            else{

                GearEquipment::create([
                    "list" => $request->ge
                ]);
                return redirect()->route('gearequipments');
            }
        }

    }


    public function delete(int $geId){

        GearEquipment::find($geId)->delete();

        return redirect()->route('gearequipments');
    }
    
    
}
