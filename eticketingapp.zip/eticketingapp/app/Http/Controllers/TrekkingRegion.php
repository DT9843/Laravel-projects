<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\TrekkingRegion as TR;
use App\Models\{Activity,
                Country};
class TrekkingRegion extends Controller
{
    //

    public function __construct(){

        $this->middleware(['auth', 'afterLogin']);
    }

    public function showRegions(){


        return view('admin.trekkingregions',["regions"=>TR::all()]);
    }

    public function createEdit(Request $request, int $rId=0){

        $tr = TR::find($rId);
        $edit = false;

        if($tr){
            $edit = true;
        }

        if($request->isMethod('get')){

            return view('admin.trekkingregion', ['region'=>$tr, 'edit'=>$edit, 
            "activities"=>Activity::all(), 
            "countries"=>Country::all()]);

        }
        else if($request->isMethod('post')){

            if($edit){

                $tr->region = $request -> trekkingregion;
                $tr->country_id = $request -> country;
                $tr->save();

                return redirect()->route('editTrekkingRegion', ['rId'=>$rId]);
            }
            else{
                
                TR::Create(['region'=>$request->trekkingregion, 'country_id'=>$request->country]);

                return redirect()->route('trekkingRegions');
            }

        }

    }

    public function delete(int $rId){

        TR::find($rId)->delete();

        return redirect()->route('trekkingRegions');

    }


}
