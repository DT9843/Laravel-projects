<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Country;
use App\Models\Location;
use App\Models\Agency;

class AgencyController extends Controller
{
    //
    public function __construct(){

        $this->middleware(['auth', 'afterLogin']);
    }

    public function showAgencies(){

        return view('admin.agencies', ["agencies"=>Agency::all()]);

    }

    public function createEdit(Request $request, int $aId=0){

        $ag = Agency::find($aId);
        $edit = false;

        if($ag){
            $edit = true;
        }

        if($request->isMethod('get')){

            return view('admin.agency', ['agency'=>$ag, 'edit'=>$edit,  
            "locations"=>Location::all(), "countries"=>Country::all()]);

        }

        else if($request->isMethod('post')){
            $countryLocation = explode(' ', $request->location);
            if($edit){

                $ag->agency_name = $request -> agency_name;
                $ag->country_id=(int)$countryLocation[1];
                $ag->location_id=(int)$countryLocation[0];
                $ag->phone_number=$request->phone_number;
                $ag->tel_number=$request->tel_number;
                $ag->email=$request->email;
                $ag->save();

                return redirect()->route('editAgency', ['aId'=>$aId]);
            }
            else{
                
                Agency::Create(["agency_name"=>$request->agency_name,
                "country_id"=>(int)$countryLocation[1],
                "location_id"=>(int)$countryLocation[0],
                "phone_number"=>$request->phone_number,
                "tel_number"=>$request->tel_number,
                "email"=>$request->email
                ]);

                return redirect()->route('agencies');
            }

        }


    }


    public function delete(int $aId){

        Agency::find($aId)->delete();

        return redirect()->route('agencies');
    }


}
