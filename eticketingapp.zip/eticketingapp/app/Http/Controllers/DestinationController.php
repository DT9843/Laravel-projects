<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Country;

class DestinationController extends Controller
{
    //

    public function __construct(){

        $this->middleware(['auth', 'afterLogin']);
    }


    public function showDestinations(){

        return view('admin.destinations', ['destinations'=>Country::all()]);

    }

    public function createEdit(Request $request, int $dId = 0){

        $destination = Country::find($dId);
        $edit = false;

        if($destination){

            $edit=true;        

        }

        if($request->isMethod('get')){
                
            return view('admin.destination', ["destination"=>$destination, "edit"=>$edit]);

        }
        else if($request->isMethod('post')){

            if($edit){

                $destination -> country = $request -> destination; 
                $destination -> save();

                return redirect()->route('editDestination', ["dId"=>$dId]);
            }
            else{

                Country::create(["country"=>$request->destination]);
                return redirect()->route('destinations');
            }
            
          
        }

    }


    public function delete(int $dId){


        Country::find($dId)->delete();

        return redirect()->route('destinations');
    }
}
