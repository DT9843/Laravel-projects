<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Country;
use App\Models\Agency;
use App\Models\TrekkingRegion;
use App\Models\Activity;
use App\Models\Trip;
use App\Models\Cost;
use App\Models\GearEquipment as GE;
use App\Models\Highlight;
use App\Models\Faq;
use App\Models\ItineraryDetails;
use Illuminate\Database\Eloquent\Builder;
class TripController extends Controller
{
    //

    public function __construct(){

        $this->middleware(['auth', 'afterLogin']);
    }

    public function showTrips(){


        return view('admin.trips',["trips"=>Trip::all()]);

    }


    public function showTripDetails(int $id){
        // dd(Trip::find($id)->gearEquipment);
        return view('admin.tripdetails',["trip"=>Trip::find($id),
        "activities"=>Activity::all(),
        "agencies"=>Agency::all(),
        "regions"=>TrekkingRegion::all(),
        "destinations"=>Country::all(),
        "costs" => Cost::all(),
        "ge"=>GE::all()]);

    }

    public function showCreatePage(){
        
        return view('admin.trip',[
            "destinations" => Country::all(),
            "activities" => Activity::all(),
            "agencies" => Agency::all(),
            "regions" => TrekkingRegion::all(),
            "costs" => Cost::all()
        ]);
    }

    public function create(Request $request){

        $frontImg = $request->front_image;
        $routeImg = $request->route_image;

        $destination = 'trip_photos';

        if(!$request->hasFile('front_image')){
            return "front_image required";
        }

        if(!$request->hasFile('route_image')){
            return "route_image required";
        }
        $newName1 = $frontImg->hashName();
        $newName2 = $routeImg->hashName();



        $newTrip = Trip::Create(["destination_id"=>(int)$request->destination,
        "activity_id"=>(int)$request->activity,
        "agency_id"=>(int)$request->agency,
        "trekking_region_id"=>(int)$request->region,
        "trip_name"=>$request->trip_name,
        "trip_cost"=>(int)$request->trip_cost,
        "duration"=>$request->duration,
        "description"=>$request->description,
        "trip_photo"=> $frontImg ? "$destination/$newName1" : null,
        "route_photo"=> $routeImg ? "$destination/$newName2" : null,
        ]);

        $frontImg->move(public_path($destination), $newName1);        
        $routeImg->move(public_path($destination), $newName2); 

        return redirect()->route('editTrip', ["tripId"=>$newTrip->id]);
    }


    public function saveTripCost(Request $request, int $tripId, int $costId){
        Trip::find($tripId)->cost()->attach($costId, ["description"=>$request->description]);
        return redirect()->route('editTrip', ["tripId"=>$tripId]);
    }

    public function saveTripGearEquipment(Request $request, int $tripId, int $gearEquipmentId){
        Trip::find($tripId)->gearEquipment()->attach($gearEquipmentId, ["list"=>$request->list]);

        return redirect()->route('trip', ["tripId"=>$tripId]);

    }

    public function saveTripHighlight(Request $request, int $tripId){
        Highlight::create([
            "trip_id"=>$tripId,
            "highlight"=>$request->highlight
        ]);

        return redirect()->route('trip',["id"=>$tripId]);
    }

    public function saveTripFaq(Request $request, int $tripId){
        Faq::create([
            'trip_id' => $tripId,
            'question'=>$request->question,
            'answer'=>$request->answer
        ]);

        return redirect()->route('trip',["id"=>$tripId]);
    }

    public function saveTripItinerary(Request $request, int $tripId){


        ID::Create([
            "trip_id"=>$tripId,
            "activity"=>$request->activity,
            "activity_description"=>$request->activity_description
        ]);

        return redirect()->route('trip',["id"=>$tripId]);

    }

    public function updateTrip(Request $request, int $tripId){

        $trip = Trip::find($tripId);
        $trip -> trip_name = $request -> trip_name;
        $trip -> trip_cost = $request -> trip_cost;
        $trip -> duration = $request -> trip_duration;
        $trip -> description = $request -> description;
        $trip -> destination_id = $request -> destination;
        $trip -> activity_id = $request -> activity;
        $trip -> agency_id = $request -> agency;
        $trip -> trekking_region_id = $request -> region;

        $trip->save();

        return redirect()->route('trip',["id"=>$tripId]);
    }


    public function showHighlightForm(int $tripId, int $hId){
        $hl = Highlight::where([['id', '=' ,$hId], ['trip_id', '=' ,$tripId]])->first();
        return view('admin.highlight', ['tId'=>$tripId, 'hId'=>$hId, 'hl'=>$hl]);
    }


    public function updateHighlight(Request $request, int $tripId, int $hId){

        $hl = Highlight::where([['id', '=' ,$hId], ['trip_id', '=' ,$tripId]])->first();
        $hl->highlight = $request->highlight;
        $hl->save();

        return redirect()->route('trip', ['id'=>$tripId]);
    }


    public function deleteHighlight(int $tripId, int $hId){
        Highlight::where([
            ['id', $hId],
            ['trip_id','=', $tripId]
        ])->first()->delete();

        return redirect()->route('trip', ['id'=>$tripId]);
    }

    public function showFaqForm(int $tripId, int $fId){
        $faq = Faq::where([['id', '=', $fId], ['trip_id', '=', $tripId]])->first();
        return view('admin.faq', ["tripId"=>$tripId,"fId"=>$fId, "faq"=>$faq]);
    }

    public function updateFaq(Request $request,int $tripId, int $fId){
        $faq = Faq::where([['id', '=', $fId], ['trip_id', '=', $tripId]])->first();
        $faq->question = $request -> question;
        $faq->answer = $request -> answer;
        $faq->save();

        return redirect()->route('trip',['id'=>$tripId]);
    }

    public function deleteFaq(int $tripId, int $fId){
        Faq::where([['id', '=', $fId], ['trip_id', '=', $tripId]])->first()->delete();
        return redirect()->route('trip',['id'=>$tripId]);
    }



    public function showItineraryForm(int $tripId, int $itnId){
        $itn = ItineraryDetails::where([['trip_id','=',$tripId], ['id', '=' ,$itnId]])->first();
        return view('admin.itinerary', ["tripId"=>$tripId, "itnId"=>$itnId, "itn"=>$itn]);

    }

    public function updateItinerary(Request $request,int $tripId, int $itnId){
        $itn = ItineraryDetails::where([['trip_id','=',$tripId], ['id', '=' ,$itnId]])->first();
        $itn->activity = $request -> activity;
        $itn->activity_description = $request -> description;
        $itn->save();

        return redirect()->route('trip',['id'=>$tripId]);

    }

    public function deleteItinerary(int $tripId, int $itnId){
        ItineraryDetails::where([['trip_id','=',$tripId], ['id', '=' ,$itnId]])->delete();
        return redirect()->route('trip',['id'=>$tripId]);
    }

    public function showCostForm(int $tripId, int $cId, int $cPid){

        $costs = Trip::find($tripId)->cost()->where('cost_id', '=', $cId)->get();
        foreach($costs as $c){
            if($c->pivot->id === $cPid){
                return view('admin.costedit', ['cost'=>$c, 'tripId'=>$tripId, 'cId'=>$cId]);
            }
        }


    }

    public function updateCost(Request $request, int $tripId, int $cId, int $cPid){

        $costs = Trip::find($tripId)->cost()->where('cost_id', '=', $cId)->get();
        foreach($costs as $c){
            if($c->pivot->id === $cPid){
                $cost = $c->pivot;
                $cost->description = $request->description;
                $cost->save();
           
                return redirect()->route('trip',['id'=>$tripId]);
            }
        }


    }

    public function deleteCost(Request $request, int $tripId, int $cId, int $cPid){
        $costs = Trip::find($tripId)->cost()->where('cost_id', '=', $cId)->get();
        foreach($costs as $c){
            if($c->pivot->id === $cPid){
                $c->pivot->delete();
                return redirect()->route('trip',['id'=>$tripId]);
            }
        }

       
    }


    public function showGearAndEquipmentForm(int $tripId, int $geId, int $gePid){

        $ges = Trip::find($tripId)->gearEquipment()->where('gear_equipment_id', '=', $geId)->
        get();

        foreach($ges as $ge){

            if($ge->pivot->id === $gePid){

                return view('admin.gearandquipmentedit', ["ge"=>$ge, "tripId"=>$tripId, "geId"=>$geId]);

            }

        }

    }


    public function updateGearAndEquipment(Request $request, int $tripId, int $geId, int $gePid){
        
        $ges = Trip::find($tripId)->gearEquipment()->where('gear_equipment_id', '=', $geId)->
        get();

        foreach($ges as $ge){

            if($ge->pivot->id === $gePid){
                $geObj = $ge->pivot;
                $geObj->list = $request->list;
                $geObj->save();

                return redirect()->route('trip',['id'=>$tripId]);
            }

        }
    }

    public function deleteGearAndEquipment(int $tripId, int $geId, int $gePid){
        $ges = Trip::find($tripId)->gearEquipment()->where('gear_equipment_id', '=', $geId)->
        get();

        foreach($ges as $ge){

            if($ge->pivot->id === $gePid){
                $ge->pivot->delete();
            
                return redirect()->route('trip',['id'=>$tripId]);

            }

        }

    }

    public function updateTripPhoto(Request $request, int $tripId){

        $trip = Trip::find($tripId);
        
        $frontImg = $request->front_image;
      

        $destination = 'trip_photos';

        if(!$request->hasFile('front_image')){
            return "front_image required";
        }

        $newName1 = explode('/', $trip->trip_photo)[1];
        

        $frontImg->move(public_path($destination), $newName1);        
       
        return redirect()->route('trip',['id'=>$tripId]);
    }


    public function updateRoutePhoto(Request $request, int $tripId){

        $trip = Trip::find($tripId);

        $routeImg = $request->route_image;

        $destination = 'trip_photos';

        if(!$request->hasFile('route_image')){
            return "route_image required";
        }

        $newName2 = explode('/', $trip->route_photo)[1];
        $routeImg->move(public_path($destination), $newName2); 

        return redirect()->route('trip',['id'=>$tripId]);
    }

    public function updatePublish(Request $request, int $tripId){
        $trip = Trip::find($tripId);
        if($request->publish){
            $trip->is_published = true;
            $trip->save();
        }
        else{
            $trip->is_published = false;
            $trip->save();
        }   
        
        return redirect()->route('trip',['id'=>$tripId]);
    }

    public function delete(int $tripId){


        Trip::find($tripId)->delete();

        return redirect()->route('trips');

    }

}   
