<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Activity;

class ActivityController extends Controller
{
    
    public function __construct(){

        $this->middleware(['auth', 'afterLogin']);
    }


    public function showActivities(){


        return view('admin.activities', ["activities"=>Activity::all()]);

    }

    public function createEdit(Request $request, int $aId = 0){


        $activity = Activity::find($aId);
        $edit = false;

        if($activity){
            $edit = true;
        }

        if($request->isMethod('get')){

            return view('admin.activity', ["activity"=>$activity, "edit"=>$edit]);

        }
        else if($request->isMethod('post')){

            if($edit){

                $activity->activity = $request->activity;
                $activity->save();

                return redirect()->route('editActivity',['aId'=>$aId]);
            }

            else{
                Activity::create(['activity'=>$request->activity]);

                return redirect()->route('activities');
            }

        }

    }


    public function delete(int $aId){

        Activity::find($aId)->delete();

        return redirect()->route('activities');

    }
}
