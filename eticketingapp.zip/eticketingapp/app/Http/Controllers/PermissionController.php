<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Spatie\Permission\Models\Permission;

class PermissionController extends Controller
{
    

    public function __construct(){

        $this->middleware(['auth', 'afterLogin']);
    }

    public function showPermissions(){

        return view('admin.permissions', ["permissions"=>Permission::all()]);

    }


    public function create(int $pId = 0){

        $edit = false;
        $permission = null;

        if($pId !== 0){
            $permission = Permission::find($pId);
            $edit = true;
        }

        return view('admin.permission', ["edit"=>$edit, "permission"=>$permission]);
    }

    public function savePermission(Request $request){

        Permission::create(['name'=>$request->permission]);
        return redirect()->route('permissions');
    }
    
    public function edit(Request $request, int $pId){

        $permission = Permission::find($pId);
        $permission->name = $request -> permission;
        $permission->save();

        return redirect()->route('editPermission', ['pId'=>$pId]);

    }
    


    public function delete(int $pId){
        
        Permission::find($pId)->delete();
        return redirect()->route('permissions');
    }

    

    
}
