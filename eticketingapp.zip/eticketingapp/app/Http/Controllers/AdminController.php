<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


class AdminController extends Controller
{
    //
    public function __construct(){

        $this->middleware(['auth', 'afterLogin']);
    }
    
    public function showPage(){

        return view('admin.dashboard');

    }


}
