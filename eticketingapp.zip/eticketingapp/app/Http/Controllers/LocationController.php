<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Location;
use App\Models\Country;
class LocationController extends Controller
{
    //

    public function __construct(){

        $this->middleware(['auth', 'afterLogin']);
    }

    public function showLocations(){

        return view('admin.locations', ['locations'=>Location::all()]);
    }


    public function createEdit(Request $request, int $lId = 0){


        $loc = Location::find($lId);
        $edit = false;

        if($loc){
            $edit = true;
        }

        if($request->isMethod('get')){

            return view('admin.location', ['location'=>$loc, 'edit'=>$edit,  
            "countries"=>Country::all()]);

        }

        else if($request->isMethod('post')){

            if($edit){

                $loc->name = $request -> location;
                $loc->country_id = $request -> country;
                $loc->save();

                return redirect()->route('editLocation', ['lId'=>$lId]);
            }
            else{
                
                Location::Create(['name'=>$request->location, 'country_id'=>$request->country]);

                return redirect()->route('locations');
            }

        }


    }

    public function delete(int $lId){

        Location::find($lId)->delete();

        return redirect()->route('locations');
    }



}
