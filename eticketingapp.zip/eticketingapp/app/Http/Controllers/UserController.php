<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Gender;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class UserController extends Controller
{
    public function __construct(){

        $this->middleware(['auth', 'afterLogin']);
    }

    public function showUsers(){


        return view('admin.users', ['users'=>User::all()]);

    }

    public function createEdit(Request $request, int $uId = 0){

        $user = User::find($uId);
        $edit = false;
        $roles = null;

        if($user){
            $edit = true;
            $roles = Role::all();
        }

        if($request->isMethod('get')){

            return view('admin.user', ["user"=>$user, "edit"=>$edit, 
            "genders"=>Gender::all(), "roles"=>$roles]);
        }
        else if($request->isMethod('post')){

            if($edit){
                
                $user->full_name = $request->full_name;
                $user->phone_number = $request->phone_number;
                $user->gender_id = $request->gender;
                $user->save();

                return redirect()->route('editUser', ['uId'=>$uId]);
            }
            else{
                $user = User::create([
                    'full_name' => $request->full_name,
                    'email' => $request->email,
                    'password' => Hash::make($request->password),
                    'phone_number' => $request->phone_number,
                    'gender_id'=>(int)$request->gender,
                ]);

                return redirect()->route('users');
            }

        }
    }

    public function delete(int $uId){


        User::find($uId)->delete();

        return redirect()->route('users');

    }

    public function assignRoleToUser(Request $request,int $uId){

        $user = User::find($uId);
        $user->assignRole(explode(',',$request->roles));

        return redirect()->route('editUser',['uId'=>$uId]);

    }

    public function deleteUserRole(int $uId, string $role){
        $user = User::find($uId);
        $user->removeRole($role);

        return redirect()->route('editUser',['uId'=>$uId]);
    }

}
