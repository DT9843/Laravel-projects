-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: eticketingapp
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `trip_cost`
--

DROP TABLE IF EXISTS `trip_cost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trip_cost` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `trip_id` bigint NOT NULL,
  `cost_id` bigint NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trip_cost`
--

LOCK TABLES `trip_cost` WRITE;
/*!40000 ALTER TABLE `trip_cost` DISABLE KEYS */;
INSERT INTO `trip_cost` VALUES (1,1,4,'Airport transfers','2022-08-11 04:34:02','2022-08-11 04:34:02'),(2,1,4,'Accommodation on the trek and in Pokhara in lodges/tea houses (twin rooms with beds and mattresses)','2022-08-11 04:34:17','2022-08-11 04:34:17'),(3,1,4,'Three meals per day during the trek section, with a hot drinks (e.g tea, coffee, juices)','2022-08-11 04:34:26','2022-09-11 09:18:22'),(4,1,4,'Annapurna Area Permit Fee','2022-08-11 04:34:34','2022-08-11 04:34:34'),(5,1,4,'Sherpa guides (English speaking, trained in first aid)','2022-08-11 04:34:42','2022-08-11 04:34:42'),(6,1,4,'Porters (carries about 15kgs)','2022-08-11 04:34:52','2022-08-11 04:34:52'),(8,1,5,'International flight to Kathmandu (~£600.00)','2022-08-11 04:35:13','2022-09-11 09:19:01'),(9,1,5,'Accommodation in Kathmandu (~ £15 - £25pp/n) - we can book this for you.','2022-08-11 04:35:24','2022-08-11 04:35:24'),(10,1,5,'Meals and drinks in Kathmandu (~£40)','2022-08-11 04:35:34','2022-08-11 04:35:34'),(11,1,5,'Personal costs like drinks, laundry, hot showers, bottled water (~£50)','2022-08-11 04:35:44','2022-08-11 04:35:44'),(12,1,5,'Lunch or dinner in Pokhara','2022-08-11 04:35:53','2022-08-11 04:35:53'),(13,1,5,'Trip Insurance (~£50-75)','2022-08-11 04:36:02','2022-08-11 04:36:02'),(14,1,5,'Visa (~£35 paid on arrival)','2022-08-11 04:36:16','2022-08-11 04:36:16'),(15,1,5,'Tips (~£30-50)','2022-08-11 04:36:25','2022-08-11 04:36:25'),(16,1,5,'Flight Departure Tax, Payable on some airfares(~1000-1500 Rupees ~£10)','2022-08-11 04:36:35','2022-08-11 04:36:35'),(18,1,4,'Staff food, insurance and equipment','2022-09-11 09:24:18','2022-09-11 09:24:18'),(20,1,5,'Sightseeing Tours or Guides','2022-09-11 09:25:17','2022-09-11 09:25:17');
/*!40000 ALTER TABLE `trip_cost` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-19 15:32:16
