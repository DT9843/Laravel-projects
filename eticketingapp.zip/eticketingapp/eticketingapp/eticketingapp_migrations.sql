-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: eticketingapp
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2022_07_14_151845_create_genders_table',1),(6,'2022_07_16_140556_add_country_to_users_table',2),(7,'2022_07_16_142101_create_countries_table',3),(8,'2022_07_16_143128_create_locations_table',4),(9,'2022_07_16_145653_create_agencies_table',4),(10,'2022_07_16_150434_add_email_to_agencies_table',5),(11,'2022_07_16_150740_create_activities_table',6),(12,'2022_07_16_150912_create_trekking_regions_table',7),(13,'2022_07_16_151044_create_trips_table',8),(14,'2022_07_16_151922_create_itinerary_details_table',9),(15,'2022_07_16_152050_create_day_activities_table',10),(16,'2022_07_18_155025_add_activity_id_to_trekking_regions',11),(17,'2022_07_19_095549_remove_activity_id_from_trekking_regions',12),(18,'2022_07_19_103626_add_country_id_to_locations_table',13),(19,'2022_07_23_081326_remove_logo_from_agencies_table',14),(20,'2022_07_24_151649_add_activity_description_to_itinerary_details',15),(21,'2022_08_03_154211_create_costs_table',16),(22,'2022_08_11_075658_create_trip_cost_table',17),(23,'2022_08_11_115312_create_gear_equipment_table',18),(24,'2022_08_12_072150_create_trip_gear_equipment_table',19),(25,'2022_08_12_111218_add_is_published_to_trips_table',20),(26,'2022_08_12_113254_add_discount_price_to_trips_table',21),(27,'2022_08_12_120933_create_highlights_table',22),(28,'2022_08_12_131645_create_faqs_table',23),(29,'2022_08_15_094523_add_country_id_to_trekking_regions_table',24),(30,'2022_09_15_125002_create_permission_tables',25),(31,'2022_10_12_132613_remove_country_id_from_users_table',26);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-19 15:32:18
