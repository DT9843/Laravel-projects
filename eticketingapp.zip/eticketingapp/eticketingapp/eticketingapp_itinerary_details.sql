-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: eticketingapp
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `itinerary_details`
--

DROP TABLE IF EXISTS `itinerary_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `itinerary_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `trip_id` bigint NOT NULL,
  `activity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `activity_description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itinerary_details`
--

LOCK TABLES `itinerary_details` WRITE;
/*!40000 ALTER TABLE `itinerary_details` DISABLE KEYS */;
INSERT INTO `itinerary_details` VALUES (1,1,'Drive to Pokhara (800m / 2,690ft) (200 km / 124 miles ) west of the Kathmandu Valley, then drive to Dhampus (1650m / 5,413ft ) (25 km /15.5miles)','2022-07-31 03:29:03','2022-09-09 00:00:07','You will start with a scenic drive after early morning breakfast, traveling by tourist bus out of the Kathmandu Valley and along the picturesque Trishuli and Marsyangdi rivers. Along the way, you get to enjoy majestically flowing rivers, terraced fields, villages, and sights of the snowy mountains, including Ganesh and Manaslu peaks. \r\n\r\nWe will stop at Pokhara - the tourist capital of Nepal- and head to Dhampus, which is 2 hours away from Pokhara. Dhampus is a picturesque Gurung village that offers fabulous views of mountains such as Annapurna South Peaks, the Fishtail, Dhaulagiri, Hiunchuli, and other peaks. We will stay in Dhampus this day, enjoying the sunset views of the Himalayas.'),(2,1,'Trek from Dhampus (1650m / 5,413ft ) to Landruk (1565m / 5,134ft )','2022-07-31 03:31:21','2022-07-31 03:31:21','After breakfast, we set off our day\'s hike, and the trail will first take us to Pothana through rhododendron (the national flower of Nepal) and orchid-hung forests. The route is stone-paved on the steeper sections. You can catch the best views of Machhapuchhare from Pothana.\r\n\r\nAs we continue forward, we reach a clearing on a pass- called Deurali, from where you can get fantastic views of Annapurna South and Hiunchuli. At this point, we are high up on the east side of the Modi Khola, and a descent follows through the forest alive with birds, ferns, and orchids taking us to a grand Modi Khola canyon. Little ahead lies Landruk - our destination for this day. Landruk offers outstanding views of Machhapuchhare (6920m), Annapurna South (7219m), and Hiunchuli (6441m).'),(3,1,'Trek from Landruk (1565m / 5,134ft) to Chhomrong (2165m / 7,103ft)','2022-07-31 03:31:54','2022-07-31 03:31:54','From Landruk, we descend to the river and cross it. Then our route climbs quite steeply, high above the river, through bamboo forest and isolated farmsteads. We will be stopping at Jhinu Danda for lunch. If you are enthusiastic, you can walk for 20 minutes to reach the hot springs at Jhinu Danda and take a bath. \r\n\r\nAfter Jhino Danda, the trail ascends to Chomrong Village. Chomrong is built on the steep hillside and has a few shops and several tea-houses, wooden lodges, and the whole village faces Macchappuchare (Fish-Tail Peak). The lodge windows offer spectacular closer views of several mountains.'),(4,1,'Trek from Chomrong (2,165m / 7,103ft) to Himalaya (2,890m / 9,425ft)','2022-07-31 03:32:21','2022-07-31 03:32:21','We make our way down through the spread-out picturesque Chomrong Village to a river crossing before climbing again and heading north of the Modi River Valley. We cross a suspension bridge and then trek to Sinuwa Danda. The trail from Sinuwa Danda becomes somewhat wider as it passes through thick and dark rhododendron forests until we reach Khuldighar. From Khuldighar, we descend long and steep stone steps into deep bamboo and rhododendron forests to reach Bamboo. After a gentle ascent from Bamboo, we finally reach Himalaya.'),(5,1,'Trek from Himalaya (2,890m / 9,425ft) to Annapurna Base Camp (4,130m / 13,550ft)','2022-07-31 03:32:39','2022-07-31 03:32:39','After breakfast at Himalaya, we climb upstream gently along the banks of the Modi Khola and then through the rugged path over to the mountainside. The walk until Machhapuchhre Base Camp is somewhat strenuous. From Machhapuchhre Base Camp, we get excellent views of the majestic Machhapuchhre, Mt. Hiunchuli, Annapurna South, Annapurna I, Annapurna III, Gandharvachuli, and Gangapurna, which is certainly a rewarding experience. \r\n\r\nWe continue our trek leaving Macchapuchhare Base Camp until we reach Annapurna Base Camp. From the Annapurna Base Camp, we will savor the mesmerizing views of Machhapuchhre, Annapurna South, Annapurna I, Hiunchuli, and other peaks.'),(6,1,'Trek from Annapurna Base Camp (4,130m / 13,550ft) to Bamboo (2,350m / 7,700ft)','2022-07-31 03:33:06','2022-07-31 03:33:06','After savoring another sunrise on the Himalayas from our otherworldly Annapurna Base Camp, we will have our breakfast. Then it is time to retrace our path out of Annapurna Sanctuary and Modi River valley. Since we will be descending, the trek is quite easy, and on the way, you can enjoy the views of several waterfalls. We will eventually make it to Bamboo, our destination for the day.'),(7,1,'Trek from Bamboo (2,350m / 7,700ft) to Jhinu Danda (1,780m / 6,393ft) and nearby natural hot springs','2022-07-31 03:33:35','2022-07-31 03:33:35','We continue our descent, passing through the same serene rhododendron, bamboo, and oak forests, that we pursued during our ascent. Then we ascend slightly to Chomrong village before dropping down to the small, peaceful settlement of Jhinu Danda. This village has nearby riverside hot springs where you can soak your tired muscles.'),(8,1,'Trek from Jhinu Danda (1,780m / 6,393ft) to Siwa/Ghandruk Phedi (1,150m / 3,770ft) , drive to Pokhara (820m) via Nayapul (1,050m)','2022-07-31 03:33:52','2022-07-31 03:33:52','We have reached our final day on the trekking trails. Today, you will make a pleasant hike along the Modi River as we head down the beautiful Modi River Valley. The descent takes us through the fertile landscape until we reach Siwa/Ghandruk Phedi. We then say goodbye to the trails and make a return drive through picturesque countryside to Pokhara.'),(10,1,'Drive from Pokhara (820m / 2,690ft) to Kathmandu (1,350m / 4,450ft)','2022-09-09 01:23:17','2022-09-09 22:42:12','Today is an early start as we depart on a tourist bus and return to Kathmandu. The 200 km route first follows the banks of Marsyangdi River and then the Trishuli River offering fabulous natural scenery and farmlands. The bus makes a final climb, and we reach Kathmandu. We hope that your Annapurna Sanctuary trek was extremely enjoyable.');
/*!40000 ALTER TABLE `itinerary_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-19 15:32:17
