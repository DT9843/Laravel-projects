-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: eticketingapp
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `trip_gear_equipment`
--

DROP TABLE IF EXISTS `trip_gear_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trip_gear_equipment` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `trip_id` bigint NOT NULL,
  `gear_equipment_id` bigint NOT NULL,
  `list` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trip_gear_equipment`
--

LOCK TABLES `trip_gear_equipment` WRITE;
/*!40000 ALTER TABLE `trip_gear_equipment` DISABLE KEYS */;
INSERT INTO `trip_gear_equipment` VALUES (1,1,1,'Thermal Base Layers – Tops and Bottoms','2022-08-12 03:31:34','2022-09-11 22:03:56'),(2,1,1,'Heavy Base Layers','2022-08-12 03:31:46','2022-08-12 03:31:46'),(3,1,1,'Trekking Pants','2022-08-12 03:31:53','2022-08-12 03:31:53'),(4,1,1,'Hard-shell Goretex pant for summit day','2022-08-12 03:32:02','2022-08-12 03:32:02'),(5,1,1,'Down Pant evening at tea house and camp','2022-08-12 03:32:11','2022-08-12 03:32:11'),(6,1,1,'T-shirts – Short and long sleeve','2022-08-12 03:32:20','2022-08-12 03:32:20'),(7,1,1,'Mid Layer Top','2022-08-12 03:32:27','2022-08-12 03:32:27'),(8,1,1,'Insulated Jacket','2022-08-12 03:32:34','2022-08-12 03:32:34'),(9,1,1,'Hard-shell Goretex jacket for summit day','2022-08-12 03:32:43','2022-08-12 03:32:43'),(11,1,2,'Double insulated mountaineering boots for climbing (Any alpine shoes will be accepted but I recommend the g2sm model from La Sportiva)','2022-08-12 03:33:10','2022-08-12 03:33:10'),(12,1,2,'Hiking/Trekking shoes (Full and waterproof)','2022-08-12 03:33:18','2022-08-12 03:33:18'),(13,1,2,'Lightweight shoes for camp and around town','2022-08-12 03:33:26','2022-08-12 03:33:26'),(14,1,2,'Gaiters to save your shoes from Snow','2022-08-12 03:33:33','2022-08-12 03:33:33'),(15,1,2,'Flip-flops','2022-08-12 03:33:40','2022-08-12 03:33:40'),(16,1,2,'Wool/Synthetic socks','2022-08-12 03:33:55','2022-08-12 03:33:55'),(18,1,3,'Liner gloves','2022-08-12 03:34:16','2022-08-12 03:34:16'),(19,1,3,'Mid-weight gloves','2022-08-12 03:34:23','2022-08-12 03:34:23'),(20,1,3,'Down mittens','2022-08-12 03:34:31','2022-08-12 03:34:31'),(21,1,4,'Cap/Sun Hat','2022-08-12 03:34:47','2022-08-12 03:34:47'),(22,1,4,'Pullover hat','2022-08-12 03:34:55','2022-08-12 03:34:55'),(23,1,4,'Balaclava to keep your neck warm','2022-08-12 03:35:03','2022-08-12 03:35:03'),(24,1,4,'Warm wool/Synthetic Hat','2022-08-12 03:35:12','2022-08-12 03:35:12'),(25,1,4,'Eye Wear (Full coverage around eyes and nose)','2022-08-12 03:35:23','2022-08-12 03:35:23'),(26,1,4,'Ski Goggles','2022-08-12 03:35:32','2022-08-12 03:35:32'),(27,1,5,'Helmet','2022-08-12 03:35:47','2022-08-12 03:35:47'),(28,1,5,'Waist leash','2022-08-12 03:35:55','2022-08-12 03:35:55'),(29,1,5,'Mountaineering Crampons','2022-08-12 03:36:04','2022-08-12 03:36:04'),(30,1,5,'Lightweight Mountaineering Harness','2022-08-12 03:36:13','2022-08-12 03:36:13'),(31,1,5,'Carabineers','2022-08-12 03:36:21','2022-08-12 03:36:21'),(32,1,5,'Belay Device(ATC Guide or Figure 8','2022-08-12 03:36:29','2022-08-12 03:36:29'),(33,1,5,'Ascender/Jumar','2022-08-12 03:36:37','2022-08-12 03:36:37'),(34,1,5,'Prussik /Accessory Cord','2022-08-12 03:36:45','2022-08-12 03:36:45'),(35,1,6,'Water Bottles: 2 bottles of 1 liter each with insulation cover or portable Thermos','2022-08-12 03:37:01','2022-08-12 03:37:01'),(36,1,6,'Trekking poles','2022-08-12 03:37:08','2022-08-12 03:37:08'),(38,1,6,'Headlamp: 200-300 lumens with spare batteries','2022-08-12 03:37:26','2022-08-12 03:37:26'),(39,1,6,'Camera','2022-08-12 03:37:37','2022-08-12 03:37:37'),(40,1,6,'Power bank/Solar Charger','2022-08-12 03:37:46','2022-08-12 03:37:46'),(41,1,6,'Universal adapter','2022-08-12 03:37:55','2022-08-12 03:37:55'),(42,1,6,'Notebooks/Diary','2022-08-12 03:38:02','2022-08-12 03:38:02'),(43,1,6,'Pocket knife','2022-08-12 03:38:12','2022-08-12 03:38:12'),(44,1,7,'Skincare (Maximum SPF sunscreen and lip balm)','2022-08-12 03:38:28','2022-08-12 03:38:28'),(45,1,7,'Toothbrush, Toothpaste, Soap, Moisturizer','2022-08-12 03:38:39','2022-08-12 03:38:39'),(46,1,7,'Hand Sanitizer','2022-08-12 03:38:45','2022-08-12 03:38:45'),(47,1,7,'Toilet paper and wet wipes','2022-08-12 03:38:54','2022-08-12 03:38:54'),(48,1,7,'Personal first aid kit (Include personal prescriptions, high altitude medications, painkillers, first-aid tape, band-aids, etc.)','2022-08-12 03:39:03','2022-08-12 03:39:03'),(49,1,7,'Water treatment','2022-08-12 03:39:11','2022-08-12 03:39:11'),(50,1,8,'Comfort Foods (Bring snacks and foods you like to munch)','2022-08-12 03:39:20','2022-08-12 03:39:20'),(51,1,8,'Travel clothes to wear in Kathmandu','2022-08-12 03:39:27','2022-08-12 03:39:27'),(52,1,8,'Sleeping bag (-20 degrees sleeping bag)','2022-08-12 03:39:34','2022-08-12 03:39:34'),(53,1,8,'Inflatable mattress - lightweight (Option)','2022-08-12 03:39:42','2022-08-12 03:39:42'),(54,1,1,'10. Down Jacket/Parka for Evening and Morning','2022-09-11 22:07:18','2022-09-11 22:07:18'),(55,1,2,'Liner socks','2022-09-11 22:07:45','2022-09-11 22:07:45');
/*!40000 ALTER TABLE `trip_gear_equipment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-19 15:32:16
