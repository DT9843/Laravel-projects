-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: eticketingapp
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'create trip','web','2022-09-16 03:24:22','2022-10-04 01:53:29'),(2,'edit trip','web','2022-09-16 03:24:30','2022-09-16 03:24:30'),(3,'delete trip','web','2022-09-16 03:24:39','2022-09-16 03:24:39'),(4,'view trips','web','2022-09-16 03:24:58','2022-10-04 02:00:45'),(5,'create all','web','2022-10-02 04:24:26','2022-10-02 04:24:26'),(6,'edit all','web','2022-10-02 04:24:37','2022-10-02 04:24:37'),(7,'delete all','web','2022-10-02 04:24:51','2022-10-02 04:24:51'),(8,'view all','web','2022-10-02 04:25:00','2022-10-04 02:00:58'),(10,'create role','web','2022-10-04 01:59:19','2022-10-04 01:59:19'),(11,'edit role','web','2022-10-04 01:59:27','2022-10-04 01:59:27'),(12,'delete role','web','2022-10-04 01:59:35','2022-10-04 01:59:35'),(13,'view roles','web','2022-10-04 02:00:27','2022-10-04 02:00:27'),(14,'create permission','web','2022-10-04 02:20:57','2022-10-04 02:20:57'),(15,'edit permission','web','2022-10-04 02:21:06','2022-10-04 02:21:06'),(16,'delete permission','web','2022-10-04 02:21:15','2022-10-04 02:21:15'),(17,'view permissions','web','2022-10-04 02:21:22','2022-10-04 02:21:22'),(18,'create activity','web','2022-10-08 22:49:51','2022-10-08 22:49:51'),(19,'edit activity','web','2022-10-08 22:50:11','2022-10-08 22:50:11'),(20,'delete activity','web','2022-10-08 22:50:21','2022-10-08 22:50:21'),(21,'view activities','web','2022-10-08 22:51:52','2022-10-08 22:51:52'),(22,'create destination','web','2022-10-08 22:52:07','2022-10-08 22:52:07'),(23,'edit destination','web','2022-10-08 22:52:15','2022-10-08 22:52:15'),(24,'delete destination','web','2022-10-08 22:52:22','2022-10-08 22:52:22'),(25,'view destinations','web','2022-10-08 22:52:32','2022-10-08 22:52:32'),(26,'create region','web','2022-10-08 22:52:43','2022-10-08 22:52:49'),(27,'edit region','web','2022-10-08 22:53:03','2022-10-08 22:53:03'),(28,'delete region','web','2022-10-08 22:53:13','2022-10-08 22:53:13'),(29,'view regions','web','2022-10-08 22:53:20','2022-10-08 22:53:20'),(30,'create agency','web','2022-10-08 22:53:43','2022-10-08 22:53:43'),(31,'edit agency','web','2022-10-08 22:53:58','2022-10-08 22:53:58'),(32,'delete agency','web','2022-10-08 22:54:07','2022-10-08 22:54:07'),(33,'view agencies','web','2022-10-08 22:54:16','2022-10-08 22:54:16'),(34,'create location','web','2022-10-08 22:54:27','2022-10-08 22:54:27'),(35,'edit location','web','2022-10-08 22:54:40','2022-10-08 22:54:40'),(36,'delete location','web','2022-10-08 22:54:54','2022-10-08 22:54:54'),(37,'view locations','web','2022-10-08 22:55:23','2022-10-08 22:55:23'),(38,'create user','web','2022-10-12 23:52:43','2022-10-12 23:52:43'),(39,'edit user','web','2022-10-12 23:53:00','2022-10-12 23:53:00'),(40,'delete user','web','2022-10-12 23:53:19','2022-10-12 23:53:19'),(41,'view users','web','2022-10-12 23:53:51','2022-10-12 23:53:51'),(42,'assign roles to user','web','2022-10-12 23:54:06','2022-10-12 23:54:06'),(43,'create cost','web','2022-10-16 22:21:39','2022-10-16 22:21:39'),(44,'edit cost','web','2022-10-16 22:22:34','2022-10-16 22:22:34'),(45,'delete cost','web','2022-10-16 22:22:54','2022-10-16 22:22:54'),(46,'view costs','web','2022-10-16 22:23:15','2022-10-16 22:23:15'),(47,'create gearandequipment','web','2022-10-16 22:23:46','2022-10-16 22:23:46'),(48,'edit gearandequipment','web','2022-10-16 22:23:54','2022-10-16 22:23:54'),(49,'delete gearandequipment','web','2022-10-16 22:24:01','2022-10-16 22:24:01'),(50,'view gearandequipments','web','2022-10-16 22:24:10','2022-10-16 22:24:10');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-19 15:32:19
