-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: eticketingapp
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `highlights`
--

DROP TABLE IF EXISTS `highlights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `highlights` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `trip_id` bigint NOT NULL,
  `highlight` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `highlights`
--

LOCK TABLES `highlights` WRITE;
/*!40000 ALTER TABLE `highlights` DISABLE KEYS */;
INSERT INTO `highlights` VALUES (1,1,'EBC Trek takes you to the highest peak of the world Mt. Everest(8,848)m.','2022-08-12 07:25:08','2022-09-08 01:28:28'),(2,1,'Rewarding breathtaking view of the Mt. Everest(8,848m), Lhotse (8516m), Nuptse(7,861m)& Pumori(7,161m).','2022-08-12 07:26:07','2022-08-12 07:26:07'),(3,1,'Admire the beauty of Kalapatthar along with the 360° view of the highest peak & many more.','2022-08-12 07:26:20','2022-08-12 07:26:20'),(4,1,'View amazing landscape, suspension bridges, Kala Patthar and base camp of Mount Everest.','2022-08-12 07:26:43','2022-08-12 07:26:43'),(5,1,'Adorable beauty of Khumjung village & Sherpa culture.','2022-08-12 07:26:55','2022-08-12 07:26:55'),(6,1,'Dramatic view of the Khumbu region with breathtaking Khumbu glaciers & icefalls.','2022-08-12 07:27:04','2022-08-12 07:27:04'),(7,1,'Explore the Hillary museum, different high passes trek and majestic views of Mount Everest.','2022-08-12 07:27:13','2022-08-12 07:27:13'),(8,1,'Visit amazing Sagarmatha National Park exploring the wilderness vast range of flora & fauna.','2022-08-12 07:27:25','2022-08-12 07:27:25'),(10,1,'Primitive Highlights of Hillary Museum & Sherpa Capital Namche Bazaar.','2022-09-08 01:42:52','2022-09-08 01:42:52');
/*!40000 ALTER TABLE `highlights` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-19 15:32:18
