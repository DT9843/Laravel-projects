-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: eticketingapp
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faqs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `trip_id` bigint NOT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqs`
--

LOCK TABLES `faqs` WRITE;
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
INSERT INTO `faqs` VALUES (1,1,'Can I Do the Everest Base Camp Trek?','Before committing to at least eleven days hiking in (generally) basic conditions, it’s a good idea to establish that you like hiking and don’t mind basic conditions, so that you can actually enjoy the experience when you do it. Bank a two- or, optimally, three-day hike to see how you feel about walking each day and being away from home comforts before you commit.','2022-08-12 10:20:33','2022-09-08 06:24:37'),(2,1,'How Should I Prepare for the Everest Base Camp Trek?','The Everest Base Camp trek is less physically strenuous than some people make out – although not a walk in the park. The main issue is going up and down steep slopes and steps, and so the best preparation is to go up and down lots and lots of stairs with the weight that you’ll be carrying when you trek. The trek starts at Lukla, 2,860m above sealevel, and culminates at Gorak Shep, over 5,160m above sealevel, so it’s worth banking some higher altitude trekking experience before committing to it.','2022-08-12 10:21:31','2022-08-12 10:21:31'),(3,1,'Can I Drink the Water on the Everest Base Camp Trek?','Nepalese tap water is not safe to drink. Bring water purifying tablets or a water purifying stick to save money and the environment. Note that at higher elevations during the coldest times of year the water will freeze, so you’ll need to buy boiled water from teahouses. Buy a decent thermos flask or plastic water container in Kathmandu so that you can top up with hot, boiled water at the beginning of the day – starting with hot water will stop it freezing.','2022-08-12 10:22:10','2022-08-12 10:22:10'),(4,1,'Do I buy gears from my hometown or Nepal?','Yes, you can charge batteries en route. Charger should be brought. There are hot shower facilities as well. You may have to pay certain amount for both ($1-$2). Negotiate. Also, hot water facility could be free at lower elevation.','2022-08-12 10:22:51','2022-08-12 10:22:51'),(5,1,'Is There Mobile Signal on the Everest Base Camp Trek?','The main Everest Base Camp route now has decent cell coverage – although be aware that you will need to pay from 200 to 600 NPR per hour to charge your devices. You can buy a local Ncell SIM with 5gb of data for under $25: do this in Kathmandu or Pokhara, not Lukla!','2022-08-12 10:23:24','2022-08-12 10:23:24'),(6,1,'Do you need travel insurance for EBC?','Yes. Definitely purchase travel insurance and make sure it will cover you at high altitudes. If you need to be airlifted down you will want to be covered by your insurance.','2022-08-12 10:24:02','2022-08-12 10:24:02'),(7,1,'How long is the Everest Base Camp Trek?','In the mountains, people generally talk in hours rather than kilometres or miles. It can be painful to hear that you have walked for 8 hours but only covered 4 miles!\r\n\r\nBut for those who need the stats the total distance you walk from Lukla (the village where you fly to from Kathmandu) to Everest base camp is; 38.58 miles or 62 Kilometers.','2022-08-12 10:24:32','2022-08-12 10:24:32'),(8,1,'How high is the Everest Base Camp trek?','The starting point is at 2,700 meters and EBC is at 5,400 to 5,500 meters.\r\n\r\nThe highest point reached during the trek is the small (in comparison!) mountain of Kala Pattar which is around 5,550 meters from here you can see the Khumbu and the Mount Everest in all its magnificence!','2022-08-12 10:24:59','2022-08-12 10:24:59'),(10,1,'Kit needed for Everest Base Camp?','Pack for every season. Kathmandu and the first few days of the trek will feel like the UK on a very hot summers day and base camp like a very cold winter day. The most important item on your kit-list should be your boots. Because of the variety of terrain covered they will need to be strong, flexible, warm and offer good ankle support. Generally, 3 season trekking boots fit the bill well (they don’t need to be crampon compatible). If you are happy with your boots walking the Scottish Munros then take them to Nepal. (Adventure Connexion can provide you with a comprehensive kit-list which covers all the bases but still lets you travel as lightly as possible.)','2022-09-08 06:26:22','2022-09-08 06:26:22');
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-19 15:32:18
