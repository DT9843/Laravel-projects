


<?php $__env->startSection('title'); ?> <?php echo e($trip->trip_name); ?> trip details <?php $__env->stopSection(); ?>
<?php $__env->startSection('head'); ?> 

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <?php
        $tId = $trip->id;
    ?>



<div class="container">


    <h3>Trekking Details</h3>
    <form action="<?php echo e(route('updateTrip', ['tripId'=>$trip->id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div>

            <label for="">Trip Name</label>
            <input type="text" name="trip_name" value="<?php echo e($trip->trip_name); ?>" required>

        </div>

        <div>

            <label for="">Trip Cost</label>
            <input type="number" name="trip_cost" value="<?php echo e($trip->trip_cost); ?>" required>
        </div>

        <div>

            <label for="">Trip Duration</label>
            <input type="number" name="trip_duration" value="<?php echo e($trip->duration); ?>" required>
        </div>  

        <div>
            <label for="">Trip Description</label>
            <textarea name="description" id="" cols="30" rows="10">
                <?php echo e($trip->description); ?>

            </textarea>
        </div>

        <div>
            <label for="">Destination</label>
            <select name="destination" id="">
                <?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($d->country === $trip->destination->country): ?>
                        <option value="<?php echo e($d->id); ?>" selected><?php echo e($d->country); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($d->id); ?>"><?php echo e($d->country); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


        <div>
            <label for="">Activities</label>
            <select name="activity" id="">
                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($a->activity === $trip->activity->activity): ?>
                        <option value="<?php echo e($a->id); ?>" selected><?php echo e($a->activity); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($a->id); ?>"><?php echo e($a->activity); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label for="">Region</label>
            <select name="region" id="">
                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($r->region === $trip->region->region): ?>
                        <option value="<?php echo e($r->id); ?>" selected><?php echo e($r->region); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($r->id); ?>"><?php echo e($r->region); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div>
            <label for="">Agency</label>
            <select name="agency" id="">
                <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($a->agency_name === $trip->agency->agency_name): ?>
                        <option value="<?php echo e($a->id); ?>" selected><?php echo e($a->agency_name); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($a->id); ?>"><?php echo e($a->agency_name); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <input type="submit" value="Edit" class="btn btn-warning">
    </form>

    <fieldset class="highlights" >

        <legend>Highlights</legend>
        <table class="table table-hover table-bordered" >

            <thead>
                <tr>
                    <th>Highlights</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $trip->highlights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($highlight->highlight); ?></td>
                    <td> 
                        <a href="<?php echo e(route('showHighlightForm',['tripId'=>$trip->id, 'hId'=>$highlight->id])); ?>" class="btn btn-warning">Edit</a> 
                        <a href="<?php echo e(route('deleteHighlight',['tripId'=>$trip->id, 'hId'=>$highlight->id])); ?>" class="btn btn-danger">Delete</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>

        <button class="highlight" data-highlight="<?php echo e(route('saveTripHighlight', ['tripId'=>$tId])); ?>">Add Highlight</button>
    </fieldset>


    <fieldset class="itinerary">
        <legend>Itinerary Details</legend>

        <table class="table table-hover table-bordered">
            <thead>
                <tr>
                    <th>Day</th>
                    <th>Day Activity</th>
                    <th>Activity description</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

                <?php for($i=0; $i<count($trip->itinerary); $i++): ?>
                    <tr>
                        <td><b>Day <?php echo e($i+1); ?></b></td>
                        <td><b><?php echo e($trip->itinerary[$i]->activity); ?></b></td>
                        <td><?php echo e($trip->itinerary[$i]->activity_description); ?></td>
                        <td> 
                            <a href="<?php echo e(route('showItinerary', ['tripId'=>$tId, 'itnId'=>$trip->itinerary[$i]->id])); ?>" class="btn btn-warning">Edit</a> 
                            <a href="<?php echo e(route('deleteItinerary' , ['tripId'=>$tId, 'itnId'=>$trip->itinerary[$i]->id])); ?>" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php endfor; ?>
            </tbody>
        </table>
       
        <button id="add-itinerary"  data-trip-itinerary = "<?php echo e(route('saveItinerary',['id'=>$trip->id])); ?>">Add Itinerary</button>
    </fieldset>
    
    <fieldset class="costs">

        <legend>Cost Include & Exclude</legend>
       
        <?php $__currentLoopData = $costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3><?php echo e($cost->type); ?></h3>
        <table class="table table-hover table-bordered"> 
            <thead>
                <tr>
                    <th><?php echo e($cost->type); ?></th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
            <?php $__currentLoopData = $trip->cost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        
                <?php if($cost->id === $c->id): ?>
                    <tr>
                        <td><?php echo e($c->pivot->description); ?></td>
                        <td> 
                            <a href="<?php echo e(route('showCost',['tripId'=>$tId, 'cId'=>$c->id, 'cPid'=>$c->pivot->id])); ?>" class="btn btn-warning">Edit</a> 
                            <a href="<?php echo e(route('deleteCost', ['tripId'=>$tId, 'cId'=>$c->id, 'cPid'=>$c->pivot->id])); ?>" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>

                <?php endif; ?>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
        </table>
            
            <button class="cost" data-cost-id="<?php echo e(route('saveTripCost',['tripId'=>$tId, 'costId'=>$cost->id])); ?>">Add <?php echo e($cost->type); ?></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </fieldset>

    <fieldset class="gearequipment">

        <legend>Gear and Equipment</legend>
        <?php $__currentLoopData = $ge; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <h3><?php echo e($g->list); ?></h3>
            <table class="table table-hover table-bordered">

                <thead>
                    <tr>
                        <th>Equipment and Gears</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $trip->gearEquipment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($tge->id === $g->id): ?>
                            <tr>
                                <td><?php echo e($tge->pivot->list); ?></td>    
                                <td> 
                                    <a href="<?php echo e(route('showGearAndEquipment', ['tripId'=>$tId, 'geId'=>$g->id, 'gePid'=>$tge->pivot->id])); ?>" class="btn btn-warning">Edit</a> 
                                    <a href="<?php echo e(route('deleteGearAndEquipment', ['tripId'=>$tId, 'geId'=>$g->id, 'gePid'=>$tge->pivot->id])); ?>" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>


            </table>
            <button class="ge" data-ge= "<?php echo e(route('saveTripGearEquipment',['tripId'=>$tId, 'gearEquipmentId'=>$g->id])); ?>">Add <?php echo e($g->list); ?></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </fieldset>



    <fieldset class="faqs">

        <legend>FAQ's</legend>

        <table class="table table-hover table-bordered">

            <thead>
                <tr>
                    <th>Questions</th>
                    <th>Answers</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $trip->faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    
                            <td><b><?php echo e($faq->question); ?></b></td>
                            <td><?php echo e($faq->answer); ?></td>
                            <td> 
                                <a href="<?php echo e(route('showFaq',['tripId'=>$tId, 'fId'=>$faq->id])); ?>" class="btn btn-warning">Edit</a> 
                                <a href="<?php echo e(route('deleteFaq', ['tripId'=>$tId, 'fId'=>$faq->id])); ?>" class="btn btn-danger">Delete</a>
                            </td>
                    
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
           
        
        <button class="faq" data-faq="<?php echo e(route('saveTripFaq', ['tripId'=>$tId])); ?>">Add FAQ</button>
    </fieldset>

    <img src="<?php echo e(url($trip->trip_photo)); ?>" alt="" >
    <form action="<?php echo e(route('updateTripPhoto', ['tripId'=>$tId])); ?>" method="post" enctype= "multipart/form-data">
        <?php echo csrf_field(); ?>
        <div>
            <label for="">Update Front Photo</label>
            <input type="file" name="front_image" id="" required>
        </div>

        <input type="submit" class="btn btn-warning" value="Edit Front Photo">

    </form>

    <img src="<?php echo e(url($trip->route_photo)); ?>" alt="">
    <form action="<?php echo e(route('updateRoutePhoto', ['tripId'=>$tId])); ?>" method="post" enctype= "multipart/form-data">
        <?php echo csrf_field(); ?>
        <div>
            <label for="">Update Route Photo</label>
            <input type="file" name="route_image" id="" required>
        </div>
        <input type="submit" class="btn btn-warning" value="Edit Route Photo">
    </form>

    <fieldset>
        <legend>Publish Details</legend>

        <form action="<?php echo e(route('updatePublish', ['tripId'=>$tId])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div>
                <?php if($trip->is_published): ?>
                    <label for="">Uncheck to unpublish</label>
                    <input type="checkbox" name="publish" checked >
                <?php else: ?>
                    <label for="">Check to publish</label>
                    <input type="checkbox" name="publish" >
                <?php endif; ?>
            </div>

            <input type="submit" value="Submit publish" class="btn btn-warning">
        </form>
    </fieldset>
</div>
<?php echo app('Illuminate\Foundation\Vite')('resources/js/trip.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/tripdetails.blade.php ENDPATH**/ ?>