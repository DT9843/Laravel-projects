

<?php $__env->startSection('title' , 'Display trips'); ?>


<?php $__env->startSection('body'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create trip', 'create all'])): ?>
        <a href="<?php echo e(route('createTrip')); ?>" class="btn btn-primary">Create trip</a>
    <?php endif; ?>

    <table class="table">

        <thead>


            <tr>
                <th>Trips</th>
            </tr>


        </thead>

        <tbody>


            <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <a href="<?php echo e(route('trip',['id'=>$trip->id])); ?>"><?php echo e($trip->trip_name); ?></a></td>
                </tr>
               
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </tbody>

    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/trips.blade.php ENDPATH**/ ?>