


<?php $__env->startSection('title', 'Create permission'); ?>


<?php $__env->startSection('body'); ?>

    <?php if($edit): ?>
    <form action="<?php echo e(route('editSavePermission',['pId'=>$permission->id])); ?>" method="post">
    <?php else: ?>
    <form action="<?php echo e(route('savePermission')); ?>" method="post">
    <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div>
            <label for="">Permission</label>
            <?php if($edit): ?>
            <input type="text" name="permission" value="<?php echo e($permission->name); ?>" required>
            
            <?php else: ?>
            <input type="text" name="permission" required>
            
            <?php endif; ?>
        </div>

        <?php if($edit): ?>
        <input type="submit" value="Edit Permission" class="btn btn-warning">
        <?php else: ?>
        <input type="submit" value="Add Permission" class="btn btn-primary">
        <?php endif; ?>
    </form>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/permission.blade.php ENDPATH**/ ?>