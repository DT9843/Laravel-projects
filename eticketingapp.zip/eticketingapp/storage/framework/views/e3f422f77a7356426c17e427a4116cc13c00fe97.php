


<?php $__env->startSection('title', 'Activities'); ?>


<?php $__env->startSection('body'); ?>

    <?php echo $__env->make('admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <a href="<?php echo e(route('createActivity')); ?>">create</a>

    <table class="table">

        <thead>

            <tr>

                <th>Activity</th>
                <th>Action</th>

            </tr>


        </thead>

        <tbody>
            <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><a href="<?php echo e(route('editActivity',['aId'=>$activity->id])); ?>"><?php echo e($activity->activity); ?></a></td>
                    <td>
                        <a href="<?php echo e(route('deleteActivity',['aId'=>$activity->id])); ?>" class="btn btn-danger">Delete</a>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>



    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/activities.blade.php ENDPATH**/ ?>