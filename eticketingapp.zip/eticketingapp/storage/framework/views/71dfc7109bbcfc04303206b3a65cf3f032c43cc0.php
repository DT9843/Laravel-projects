


<?php $__env->startSection('title', 'Assign permission to role'); ?>

<?php $__env->startSection('body'); ?>

    <h2>Role details</h2>

    <form action="<?php echo e(route('editRole', ['roleId'=>$role->id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div>

            <label for="">Role</label>
            <input type="text" name="role" value="<?php echo e($role->name); ?>">

        </div>


        <input type="submit" value="Edit role" class="btn btn-warning">
    </form>



    <h2>Role permissions</h2>
    <table class="table">
        <thead>

            <tr>
                <th>Permission</th>
                <th>Action</th>
            </tr>

        </thead>

        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($rp->name); ?></td>
                <td><a href="<?php echo e(route('deleteRolePermission',['roleId'=>$role->id, 'pId'=>$rp->id])); ?>" class="btn btn-danger">Delete</a></td>
            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td>No permission is given to the role.</td>
                <td>No action</td>
            </tr>
            <?php endif; ?>


        </tbody>
     
    </table>
    <form action="<?php echo e(route('assignPermissionToRole', ['roleId'=>$role->id])); ?>" method="post">
        <?php echo csrf_field(); ?>

        <div>
            <input type="text" id="rolePermissions" name="permissions" placeholder="please select permission" required>
            <select id="permissions">
                <option value="" selected>None</option>
                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if(!$role -> hasPermissionTo($p)): ?>
                        <option value="<?php echo e($p->name); ?>"><?php echo e($p->name); ?></option>    
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>

        </div>

        <input type="submit" value="Add permission to role" class="btn btn-primary">

    </form>

<a href="<?php echo e(route('deleteRole',['roleId'=>$role->id])); ?>" class="btn btn-danger">Delete</a>

<?php echo app('Illuminate\Foundation\Vite')('resources/js/role.js'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/assignpermissiontorole.blade.php ENDPATH**/ ?>