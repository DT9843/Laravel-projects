


<?php $__env->startSection('title', 'Trip Create Form'); ?>


<?php $__env->startSection('body'); ?>


    <form action="<?php echo e(route('saveTrip')); ?>" enctype="multipart/form-data"  method="post">

        <?php echo csrf_field(); ?>

        <div>
            <label for="">Trip Name</label>
            <input type="text" name="trip_name" required>
        </div>

        
        <div>
            <label for="">Trip Cost</label>
            <input type="number" name="trip_cost" required>
        </div>

        <div>
            <label for="">Trip Duration</label>
            <input type="number" name="duration" required>
        </div>

        <div>
            <label for="">Trip Destination</label>
            <select name="destination" id="">
                <option value="" selected>None</option>
                <?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($destination->id); ?>"><?php echo e($destination->country); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label for="">Region</label>
            <select name="region" id="">
                <option value="" selected>None</option>
                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($region->id); ?>"><?php echo e($region->region); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label for="">Activity</label>
            <select name="activity" id="">
                <option value="" selected>None</option>
                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($activity->id); ?>"><?php echo e($activity->activity); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label for="">Agency</label>
            <select name="agency" id="">
                <option value="" selected>None</option>
                <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($agency->id); ?>"><?php echo e($agency->agency_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label for="">Description</label>
            <textarea name="description" id="" cols="80" rows="20">
                
            </textarea>
        </div>

        <div>
            <label for="">Front Image</label>
            <input type="file" name="front_image" id="" required>
        </div>

        <div>
            <label for="">Route Image</label>
            <input type="file" name="route_image" required>
        </div>

        <input type="submit" value="Add">
    </form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/trip.blade.php ENDPATH**/ ?>