


<?php $__env->startSection('title', 'Destinations'); ?>


<?php $__env->startSection('body'); ?>
<?php echo $__env->make('admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <a href="<?php echo e(route('createDestination')); ?>">create</a>

    <table class="table">

        <thead>

            <tr>

                <th>Activity</th>
                <th>Action</th>

            </tr>


        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>

                    <td><a href="<?php echo e(route('editDestination',['dId'=>$destination->id])); ?>"><?php echo e($destination->country); ?></a></td>
                    <td>
                        <a href="<?php echo e(route('deleteDestination',['dId'=>$destination->id])); ?>" class="btn btn-danger">Delete</a>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td>There are no destinations.</td>
                    <td>Action not available</td>
                </tr>
            <?php endif; ?>
        </tbody>



    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/destinations.blade.php ENDPATH**/ ?>