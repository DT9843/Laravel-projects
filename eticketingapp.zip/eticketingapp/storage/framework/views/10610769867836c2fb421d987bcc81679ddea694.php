


<?php $__env->startSection('title', 'Users'); ?>


<?php $__env->startSection('body'); ?>

    <a href="<?php echo e(route('createUser')); ?>">create</a>

    <table class="table">

        <thead>

            <tr>
                <th>Full Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Gender</th>

            </tr>


        </thead>

        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><a href="<?php echo e(route('editUser',['uId'=>$user->id])); ?>"><?php echo e($user->full_name); ?></a></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone_number); ?></td>
                    <td><?php echo e($user->gender->sex); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>



    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/users.blade.php ENDPATH**/ ?>