


<?php $__env->startSection('title', 'permissions'); ?>


<?php $__env->startSection('body'); ?>


    <a href="<?php echo e(route('createPermission')); ?>">Create permission</a>
    <table class="table">

      <thead>

        <tr>
          <th>Permission</th>
          <th>Action</th>
        </tr>

      </thead >

      <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <tr>
          <td><a href="<?php echo e(route('editPermission', ['pId'=>$permission->id])); ?>"><?php echo e($permission->name); ?></a></td>
          <td><a href="<?php echo e(route('deletePermission', ['pId'=>$permission->id])); ?>" class="btn btn-danger">Delete</a> </td>
        </tr>
      
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td>There are no permissions</td>
            <td>No action</td>
          </tr>
        <?php endif; ?>

      </tbody>

    </table>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/permissions.blade.php ENDPATH**/ ?>