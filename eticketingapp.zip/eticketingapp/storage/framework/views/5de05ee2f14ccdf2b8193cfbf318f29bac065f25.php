

<?php $__env->startSection('title', 'Admin dashboard'); ?>

<?php $__env->startSection('body'); ?>
<?php echo $__env->make('admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view activities','view destinations','view regions','view trips','view all'])): ?>


        <table class="table">

            <thead>
                <tr>
                    <th>Trip models</th>
                </tr>
            </thead>

            <tbody>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view activities','view all'])): ?>
                    <tr>
                    <td> <a href="<?php echo e(route('activities')); ?>">Activities</a></td>
                    </tr>
                <?php endif; ?>


                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view destinations','view all'])): ?>
                    <tr>
                    <td><a href="<?php echo e(route('destinations')); ?>">Destinations</a></td>
                    </tr>
                <?php endif; ?>


                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view regions','view all'])): ?>
                    <tr>
                    <td><a href="<?php echo e(route('trekkingRegions')); ?>">Trekking Regions</a></td>
                    </tr>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view costs','view all'])): ?>
                    <tr>
                    <td><a href="<?php echo e(route('costs')); ?>">Costs</a></td>
                    </tr>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view gearandequipments','view all'])): ?>
                    <tr>
                    <td><a href="<?php echo e(route('gearequipments')); ?>">Gear And Equipments</a></td>
                    </tr>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view trips','view all'])): ?>
                    <tr>
                    <td><a href="<?php echo e(route('trips')); ?>">Trips</a></td>
                    </tr>
                <?php endif; ?>



            </tbody>

        </table>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view agencies','view locations','view all'])): ?>    
        <table class="table">

            <thead>
                <tr>
                    <th>Agnecy models</th>
                </tr>
            </thead>

            <tbody>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view agencies','view all'])): ?>
                    <tr>
                    <td>  <a href="<?php echo e(route('agencies')); ?>">Agencies</a></td>
                    </tr>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view locations','view all'])): ?>
                    <tr>
                    <td><a href="<?php echo e(route('locations')); ?>">Locations</a></td>
                    </tr>
                <?php endif; ?>
            </tbody>

        </table>

    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view users','view roles','view permissions','view all'])): ?>    
        
        <table class="table">

            <thead>
                <tr>
                    <th>User Authorization</th>
                </tr>
            </thead>

            <tbody>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view users','view all'])): ?>
                    <tr>
                        <td><a href="<?php echo e(route('users')); ?>">Users</a></td>
                    </tr>
                <?php endif; ?>


                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view roles','view all'])): ?>
                    <tr>
                        <td><a href="<?php echo e(route('roles')); ?>">Roles</a></td>
                    </tr>
                <?php endif; ?>


                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view permissions','view all'])): ?>
                    <tr>
                        <td><a href="<?php echo e(route('permissions')); ?>">Permissions</a></td>
                    </tr>
                <?php endif; ?>

            </tbody>

        </table>

    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>