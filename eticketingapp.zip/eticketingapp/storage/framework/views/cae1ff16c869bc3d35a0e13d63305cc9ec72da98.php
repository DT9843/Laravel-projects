

<?php if($edit): ?>
<?php $__env->startSection('title', 'Trekking Region Edit Form'); ?>
<?php else: ?>
<?php $__env->startSection('title', 'Trekking Region Create Form'); ?>
<?php endif; ?>

<?php $__env->startSection('body'); ?>

    <?php if($edit): ?>
    <form action="<?php echo e(route('saveEditTrekkingRegion',['rId'=>$region->id])); ?>" method="post">

            <?php echo csrf_field(); ?>

        <div>

            <label for="">Country</label>
            <select name="country" id="region" required>
                <option value="">None</option>
                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($country->id == $region->country_id): ?>

                        <option value="<?php echo e($country->id); ?>" selected><?php echo e($country->country); ?></option>

                    <?php else: ?>

                        <option value="<?php echo e($country->id); ?>"><?php echo e($country->country); ?></option>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


        <div>
            <label for="">Region</label>
            <input type="text" name="trekkingregion" value="<?php echo e($region->region); ?>" required>
        </div>


        <input type="submit" value="Edit" class="btn btn-warning">
        </form>
    <?php else: ?>
        <form action="<?php echo e(route('saveTrekkingRegion')); ?>" method="post">
    
            <?php echo csrf_field(); ?>

            <div>

                <label for="">Country</label>
                <select name="country" id="region" required>
                    <option value="">None</option>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->country); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


            <div>
                <label for="">Region</label>
                <input type="text" name="trekkingregion" required>
            </div>


            <input type="submit" value="Add" class="btn btn-primary">
        </form>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/trekkingregion.blade.php ENDPATH**/ ?>