

<?php if($edit): ?>
    <?php $__env->startSection('title', 'Agency Edit Form'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Agency Create Form'); ?>
<?php endif; ?>

<?php $__env->startSection('head'); ?>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/style.css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<?php if($edit): ?>

    <form action="<?php echo e(route('saveEditAgency', ['aId'=>$agency->id])); ?>" method="post">

        <?php echo csrf_field(); ?>

        <div>
            <label for="">Agency Name</label>
            <input type="text" name="agency_name" value="<?php echo e($agency->agency_name); ?>" required>
        </div>

        <div>

            <label for="">Location</label>
            <select name="location" id="locations" required>
                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $country->location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($country->id == $agency->country_id && $location->id == $agency->location_id): ?>
                            <option value="<?php echo e($location->id); ?> <?php echo e($country->id); ?>" selected><?php echo e($location->name); ?>, <?php echo e($country->country); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($location->id); ?> <?php echo e($country->id); ?>" ><?php echo e($location->name); ?>, <?php echo e($country->country); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div>
            <label for="">Email</label>
            <input type="email"  name="email" value="<?php echo e($agency->email); ?>" required>
        </div>

        <div>
            <label for="">Phone Number</label>
            <input type="number" min="10" name="phone_number" value="<?php echo e($agency->phone_number); ?>">
        </div>

        <div>
            <label for="">Tele Phone Number</label>
            <input type="number" min="9" name="tel_number" value="<?php echo e($agency->tel_number); ?>" required>
        </div>



        <input type="submit" value="Edit" class="btn btn-warning">
    </form>

<?php else: ?>

    <form action="<?php echo e(route('saveAgency')); ?>" method="post">

    <?php echo csrf_field(); ?>

    <div>
        <label for="">Agency Name</label>
        <input type="text" name="agency_name" required>
    </div>

    <div>

        <label for="">Location</label>
        <select name="location" id="locations">
            <option value="" selected>None</option>
            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                <?php $__currentLoopData = $country->location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($location->id); ?> <?php echo e($country->id); ?>" ><?php echo e($location->name); ?>, <?php echo e($country->country); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            
        </select>
    </div>


    <div>
        <label for="">Email</label>
        <input type="email"  name="email" required>
    </div>

    <div>
        <label for="">Phone Number</label>
        <input type="number" min="10" name="phone_number">
    </div>

    <div>
        <label for="">Tele Phone Number</label>
        <input type="number" min="9" name="tel_number" required>
    </div>



    <input type="submit" value="Add" class="btn btn-primary">
    </form>


<?php endif; ?>

<?php echo app('Illuminate\Foundation\Vite')('resources/js/agency.js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/agency.blade.php ENDPATH**/ ?>