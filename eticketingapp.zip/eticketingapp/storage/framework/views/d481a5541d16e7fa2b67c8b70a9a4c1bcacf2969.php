


<?php $__env->startSection('title', 'Agencies'); ?>


<?php $__env->startSection('body'); ?>

    <a href="<?php echo e(route('createAgency')); ?>">create</a>

    <table class="table">

        <thead>

            <tr>

                <th>Agency Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Tel Number</th>
                <th>Location</th>
                <th>Action</th>

            </tr>


        </thead>

        <tbody>
            <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><a href="<?php echo e(route('editAgency',['aId'=>$ag->id])); ?>"><?php echo e($ag->agency_name); ?></a></td>
                    <td><?php echo e($ag->email); ?></td>
                    <td><?php echo e($ag->phone_number); ?></td>
                    <td><?php echo e($ag->tel_number); ?></td>
                    <td><?php echo e($ag->location->name); ?></td>
                    <td>
                        <a href="<?php echo e(route('deleteAgency',['aId'=>$ag->id])); ?>" class="btn btn-danger">Delete</a>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>



    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/agencies.blade.php ENDPATH**/ ?>