

<?php if($edit): ?>
    <?php $__env->startSection('title', 'Edit gear and equipment'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Create gear and equipment'); ?>
<?php endif; ?>


<?php $__env->startSection('body'); ?>

    <?php if($edit): ?>

        <form action="<?php echo e(route('saveEditGearEquipment',['geId'=>$ge->id])); ?>" method="post">

            <?php echo csrf_field(); ?>
            <div>
                <label for="">Gear Or Equipment</label>
                <input type="text" name="ge" value="<?php echo e($ge->list); ?>" required>
            </div>

            <input type="submit" value="Edit" class="btn btn-warning">
        </form>

    <?php else: ?>
        <form action="<?php echo e(route('saveGearEquipment')); ?>" method="post">

        <?php echo csrf_field(); ?>
            <div>
                <label for="">Gear Or Equipment</label>
                <input type="text" name="ge" required>
            </div>

            <input type="submit" value="Add" class="btn btn-primary">
        </form>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/gearequipment.blade.php ENDPATH**/ ?>