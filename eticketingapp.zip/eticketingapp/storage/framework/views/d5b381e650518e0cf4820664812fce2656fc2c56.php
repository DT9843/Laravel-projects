
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid ">
		<a class="navbar-brand " href="#">Admin Panel</a>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		  <span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
		  <ul class="navbar-nav ">
			<li class="nav-item">
			  <a class="nav-link active" href="<?php echo e(route('adminDashboard')); ?>">Home</a>
			</li>
			<?php if(auth()->guard()->check()): ?>
				<!-- <li class="nav-item">
				<a class="nav-link active" href="">Profile</a>
				</li>		 -->
				<li class="nav-item">
				<a class="nav-link active" href="<?php echo e(route('logout')); ?>">Logout</a>
				</li>			
			<?php endif; ?>


		  </ul>		  
		</div>
	</div>
</nav><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/nav.blade.php ENDPATH**/ ?>