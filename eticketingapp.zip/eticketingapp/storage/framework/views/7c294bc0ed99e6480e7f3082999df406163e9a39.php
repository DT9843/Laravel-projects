


<?php $__env->startSection('title', 'Gear And Equipments'); ?>


<?php $__env->startSection('body'); ?>

    <a href="<?php echo e(route('createGearEquipment')); ?>">create</a>

    <table class="table">

        <thead>

            <tr>

                <th>Gear And Equipment</th>
                <th>Action</th>

            </tr>


        </thead>

        <tbody>
            <?php $__currentLoopData = $ges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><a href="<?php echo e(route('editGearEquipment',['geId'=>$ge->id])); ?>"><?php echo e($ge->list); ?></a></td>
                    <td>
                        <a href="<?php echo e(route('deleteGearEquipment',['geId'=>$ge->id])); ?>" class="btn btn-danger">Delete</a>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>



    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/gearequipments.blade.php ENDPATH**/ ?>