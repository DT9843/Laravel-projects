


<?php if($edit): ?>
    <?php $__env->startSection('title', 'Edit cost'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Create cost'); ?>
<?php endif; ?>

<?php $__env->startSection('body'); ?>

    <?php if($edit): ?>
        <form action="<?php echo e(route('saveEditCost',['cId'=>$cost->id])); ?>" method="post">

            <?php echo csrf_field(); ?>
            <div>
                <label for="">Cost Type</label>
                <input type="text" name="type" value="<?php echo e($cost->type); ?>" required>
            </div>

            <input type="submit" value="Edit" class="btn btn-warning">
        </form>
    <?php else: ?>
        <form action="<?php echo e(route('saveCost')); ?>" method="post">

        <?php echo csrf_field(); ?>
            <div>
                <label for="">Cost Type</label>
                <input type="text" name="type" required>
            </div>

            <input type="submit" value="Add" class="btn btn-primary">
        </form>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/cost.blade.php ENDPATH**/ ?>