


<?php $__env->startSection('title', 'Locations'); ?>


<?php $__env->startSection('body'); ?>

    <a href="<?php echo e(route('createLocation')); ?>">create</a>

    <table class="table">

        <thead>

            <tr>

                <th>Location</th>
                <th>Country</th>
                <th>Action</th>

            </tr>


        </thead>

        <tbody>
            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><a href="<?php echo e(route('editLocation',['lId'=>$loc->id])); ?>"><?php echo e($loc->name); ?></a></td>
                    <td><?php echo e($loc->country->country); ?></td>
                    <td>
                        <a href="<?php echo e(route('deleteLocation',['lId'=>$loc->id])); ?>" class="btn btn-danger">Delete</a>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>



    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/locations.blade.php ENDPATH**/ ?>