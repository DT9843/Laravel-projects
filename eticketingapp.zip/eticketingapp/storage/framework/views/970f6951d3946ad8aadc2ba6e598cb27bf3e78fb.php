



<?php $__env->startSection('title', 'Welcome to home page'); ?>


<?php $__env->startSection('body'); ?>

    <?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <fieldset>


        <legend>Search Trips</legend>

        <form action="<?php echo e(route('searchTrips')); ?>" class="d-flex" method="post">
            <?php echo csrf_field(); ?>

            <div>

                <label for=""><b>Destination</b> </label>
                <select name="destination" id="">
                    <option value="" selected>None</option>
                    <?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($destination->country); ?>"><?php echo e($destination->country); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>

            <div class="mx-2">

                <label for=""><b>Activities</b></label>
                <select name="activity" id="">
                    <option value="">None</option>
                    <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($activity->activity); ?>"><?php echo e($activity->activity); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>



            <input type="submit" value="Search" class="btn btn-success">
        </form>

    </fieldset>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/index.blade.php ENDPATH**/ ?>