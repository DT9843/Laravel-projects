


<?php $__env->startSection('title', 'Trekking region'); ?>


<?php $__env->startSection('body'); ?>

    <a href="<?php echo e(route('createTrekkingRegion')); ?>">create</a>

    <table class="table">

        <thead>

            <tr>

                <th>Trekking Region</th>
                <th>Action</th>

            </tr>


        </thead>

        <tbody>
            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><a href="<?php echo e(route('editTrekkingRegion',['rId'=>$tr->id])); ?>"><?php echo e($tr->region); ?></a></td>
                    <td>
                        <a href="<?php echo e(route('deleteTrekkingRegion',['rId'=>$tr->id])); ?>" class="btn btn-danger">Delete</a>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>



    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/trekkingregions.blade.php ENDPATH**/ ?>