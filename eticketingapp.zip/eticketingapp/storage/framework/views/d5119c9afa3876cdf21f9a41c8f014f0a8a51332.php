

<?php if($edit): ?>
    <?php $__env->startSection('title', 'Trekking Region Edit Form'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Trekking Region Create Form'); ?>
<?php endif; ?>

<?php $__env->startSection('body'); ?>

    <?php if($edit): ?>
    <form action="<?php echo e(route('saveEditDestination',['dId'=>$destination->id])); ?>" method="post">
    <?php else: ?>
    <form action="<?php echo e(route('saveDestination')); ?>" method="post">
    <?php endif; ?>
    
        <?php echo csrf_field(); ?>

        <div>
            <label for="">Destination</label>
            <?php if($edit): ?>
            <input type="text" name="destination" value="<?php echo e($destination->country); ?>" required>
            <?php else: ?>
            <input type="text" name="destination" required>
            <?php endif; ?>
        </div>
        <?php if($edit): ?>
        <input type="submit" value="Edit" class="btn btn-warning">
        <?php else: ?>
        <input type="submit" value="Add" class="btn btn-primary">
        <?php endif; ?>
    </form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/destination.blade.php ENDPATH**/ ?>