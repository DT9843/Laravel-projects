


<?php $__env->startSection('title'); ?>
    <?php echo e($trip->trip_name); ?> details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/style.css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
   <h1><?php echo e($trip->trip_name); ?></h1> 
   <div class="d-flex justify-content-between">
    <img src="<?php echo e(url($trip->trip_photo)); ?>" height="490px" width="850px" alt="">

    <div>
        <?php if($trip->discount_price === 0): ?>
            <p><b>From: <?php echo e($trip->trip_cost); ?></b></p>
        <?php else: ?>
           <p>From <del><?php echo e($trip->trip_cost); ?></del></p> 
           <b><?php echo e($trip->discount_price); ?></b>
        <?php endif; ?>
    </div>

   </div>
    <p><?php echo e($trip->description); ?></p>

    <div>
        <h1>Trip Details</h1>
        <ul class="trip-details">
            <li class="btn btn-secondary  td-btn">HIGHLIGHTS</li>
            <li class="btn btn-secondary  td-btn">ITINERARY</li>
            <li class="btn btn-secondary  td-btn">COST</li>
            <li class="btn btn-secondary  td-btn">EQUIPMENTS</li>
            <li class="btn btn-secondary  td-btn">MAP</li>
            <li class="btn btn-secondary  td-btn">FAQs</li>
        </ul>

        <div class="highlights td">
            <ul>
                <?php $__currentLoopData = $trip->highlights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><?php echo e($highlight->highlight); ?></li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div class="itinerary td dp-none">
            <?php for($i=0; $i<count($trip->itinerary); $i++): ?>

                <b>Day <?php echo e($i+1); ?>: <?php echo e($trip->itinerary[$i]->activity); ?></b>
                <p><?php echo e($trip->itinerary[$i]->activity_description); ?></p>
            <?php endfor; ?>
        </div>

        <div class="cost td dp-none">
            <h3>Includes</h3>
            <ul>
                <?php $__currentLoopData = $trip->cost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                
                    <?php if($cost->type === "Cost Include"): ?>
                        <li><?php echo e($cost->pivot->description); ?></li>
                    <?php endif; ?>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <h3>Excludes</h3>
            <ul>
                <?php $__currentLoopData = $trip->cost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <?php if($cost->type === "Cost Exclude"): ?>
                        <li><?php echo e($cost->pivot->description); ?></li>
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div class="equipments td dp-none">
            <?php $__currentLoopData = $ge; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h3><?php echo e($e->list); ?></h3>
                <ul>
                    <?php $__currentLoopData = $trip->gearEquipment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <?php if($e->list === $equipment->list): ?>
                            <li><?php echo e($equipment->pivot->list); ?></li>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


        <div class="map td dp-none">

            <img src="<?php echo e(url($trip->route_photo)); ?>" height="400px" width="700px" alt="">


        </div>


        <div class="faqs td dp-none">
            <?php $__currentLoopData = $trip->faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <h3><?php echo e($faq->question); ?></h3>
                <p><b>Answer:</b> <?php echo e($faq->answer); ?></p>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


    </div>

</div>

<?php echo app('Illuminate\Foundation\Vite')('resources/js/tripdetails.js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/trip.blade.php ENDPATH**/ ?>