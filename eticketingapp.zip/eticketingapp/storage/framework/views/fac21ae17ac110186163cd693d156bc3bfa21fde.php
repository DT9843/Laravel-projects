

<?php if($edit): ?>
    <?php $__env->startSection('title', 'Edit user'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Create new user'); ?>
<?php endif; ?>

<?php $__env->startSection('body'); ?>

    <?php if($edit): ?>

        <form action="<?php echo e(route('saveEditUser',['uId'=>$user->id])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div>

                <label for="">Full Name</label>
                <input type="text" name="full_name" value="<?php echo e($user->full_name); ?>" required>

            </div>

            <div>

                <label for="">Email</label>
                <input type="email" name="email" value="<?php echo e($user->email); ?>" required>

            </div>

            <div>

                <label for=""></label>
                <input type="number" name="phone_number" value="<?php echo e($user->phone_number); ?>" min="10" required>

            </div>

            <div>

                <label for="">Gender</label>
                <br/>
                <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($gender->id === $user->gender_id): ?>
                        <label for=""><?php echo e($gender->sex); ?></label>
                        <input type="radio" name="gender" value="<?php echo e($gender->id); ?>" checked>
                    <?php else: ?>
                        <label for=""><?php echo e($gender->sex); ?></label>
                        <input type="radio" name="gender" value="<?php echo e($gender->id); ?>">
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <input type="submit" value="Edit" class="btn btn-warning">
        </form>

        <h2>User Roles</h2>

        <table class="table">

            <thead>

                <tr>
                    <th>Role</th>
                    <th>Action</th>
                </tr>

            </thead>


            <tbody>

                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  

                    <tr>
                        <td><?php echo e($ur->name); ?></td>
                        <td> <a href="<?php echo e(route('deleteUserRole', ['uId'=>$user->id, 'role'=>$ur->name])); ?>">Delete</a> </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>


        </table>

        <form action="<?php echo e(route('assignRoleToUser', ['uId'=>$user->id])); ?>" method = "post">
            <?php echo csrf_field(); ?>
            <input type="text" name="roles" id="userRoles" placeholder="Donot type select only" required>
            <select id="roles">

                <option value="">None</option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($r->name); ?>"><?php echo e($r->name); ?></option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>

            <input type="submit" value="Assign role to user" class="btn btn-primary">
        </form>



        <a href="<?php echo e(route('deleteUser',['uId'=>$user->id])); ?>" class="btn btn-danger">Delete</a>

        <?php echo app('Illuminate\Foundation\Vite')('resources/js/user.js'); ?>
    <?php else: ?>

        <form action="<?php echo e(route('saveUser')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div>

                <label for="">Full Name</label>
                <input type="text" name="full_name" required>

            </div>

            <div>

                <label for="">Email</label>
                <input type="email" name="email" required>

            </div>

            <div>

                <label for="">Phone Number</label>
                <input type="number" name="phone_number" min="10" required>

            </div>

            <div>

                <label for="">Password</label>
                <input type="password" name="password" min="10" required>

            </div>

            <div>

                <label for="">Confirm Password</label>
                <input type="password" name="password_confirmation" min="10" required>

            </div>

            <div>
                <label for="">Gender</label>
         
                <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label for=""><?php echo e($gender->sex); ?></label>
                        <input type="radio" name="gender" value="<?php echo e($gender->id); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <input type="submit" value="Create" class="btn btn-primary">

        </form>


    <?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/user.blade.php ENDPATH**/ ?>