


<?php $__env->startSection('title', 'Create role'); ?>


<?php $__env->startSection('body'); ?>

    <form action="<?php echo e(route('saveRole')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div>
            <label for="">Role</label>
            <input type="text" name="role" required>
        </div>

        <input type="submit" value="Add Role" class="btn btn-primary">
    </form>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/role.blade.php ENDPATH**/ ?>