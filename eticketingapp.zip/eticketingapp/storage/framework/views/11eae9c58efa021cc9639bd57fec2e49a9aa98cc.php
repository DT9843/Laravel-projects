


<?php $__env->startSection('title', 'roles'); ?>


<?php $__env->startSection('body'); ?>

<div class="container">
    <a href="<?php echo e(route('createRole')); ?>">Create role</a>
    <table class="table">

      <thead>
        <tr>
          <th>Roles</th>
        </tr>
      </thead>

      <tbody>

        
        <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
          <td> <a href="<?php echo e(route('assignPermissionToRoleForm', ['roleId'=>$role->id])); ?>"><?php echo e($role->name); ?></a></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>There are no roles</p>
        <?php endif; ?>
        


      </tbody>


    </table>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/roles.blade.php ENDPATH**/ ?>