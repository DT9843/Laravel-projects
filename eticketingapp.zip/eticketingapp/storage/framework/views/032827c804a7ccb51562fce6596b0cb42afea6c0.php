


<?php $__env->startSection('title', 'Costs'); ?>


<?php $__env->startSection('body'); ?>

    <a href="<?php echo e(route('createCost')); ?>">create</a>

    <table class="table">

        <thead>

            <tr>

                <th>Cost</th>
                <th>Action</th>

            </tr>


        </thead>

        <tbody>
            <?php $__currentLoopData = $costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><a href="<?php echo e(route('editCost',['cId'=>$cost->id])); ?>"><?php echo e($cost->type); ?></a></td>
                    <td>
                        <a href="<?php echo e(route('deleteCost',['cId'=>$cost->id])); ?>" class="btn btn-danger">Delete</a>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>



    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/admin/costs.blade.php ENDPATH**/ ?>