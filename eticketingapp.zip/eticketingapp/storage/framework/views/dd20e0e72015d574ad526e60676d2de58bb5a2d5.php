


<?php $__env->startSection('title', 'Search result'); ?>


<?php $__env->startSection('body'); ?>

<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
<div class="d-flex justify-content-between">
<fieldset>


<legend>Search Trips</legend>

<form action="<?php echo e(route('searchTrips')); ?>" class="d-flex"  method="post">
    <?php echo csrf_field(); ?>

    <div>

        <label for=""> <b>Destination</b> </label>
        <select name="destination" id="">
    
            <?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($destination->country === $d->country): ?>
                    <option value="<?php echo e($d->country); ?>" selected><?php echo e($d->country); ?></option>
            
                <?php else: ?>
                    <option value="<?php echo e($d->country); ?>"><?php echo e($d->country); ?></option>
            
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

    </div>

    <div class="mx-2">

        <label for=""><b>Activities</b></label>
        <select name="activity" id="">

            <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($activity->activity === $a->activity): ?>
                    <option value="<?php echo e($a->activity); ?>" selected><?php echo e($a->activity); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($a->activity); ?>"><?php echo e($a->activity); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

    </div>



    <input type="submit" value="Search" class="btn btn-success">
</form>

</fieldset>


<fieldset>
    <legend>Select Region</legend>
    <select name="" id="region"
    data-all="<?php echo e(route('searchResults', ['destination'=>$destination->country, 'activity'=>$activity->activity])); ?>"
    data-link="/search/trips/<?php echo e($destination->country); ?>/<?php echo e($activity->activity); ?>">

        <option value="All" >All</option>
        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($region): ?>
                <?php if($region->region === $r->region): ?>
                    <option value="<?php echo e($r->region); ?>" selected><?php echo e($r->region); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($r->region); ?>"><?php echo e($r->region); ?></option>
                <?php endif; ?>
            <?php else: ?>
                <option value="<?php echo e($r->region); ?>"><?php echo e($r->region); ?></option>
            <?php endif; ?>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</fieldset>
</div>
    <div class="my-3">
        <?php $__empty_1 = true; $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <!-- <p><?php echo e($trip->trip_name); ?></p> -->

            <div class="card" style="width:410px;">

                <img class="card-img-top" width='410' height="250" src="<?php echo e(url($trip->trip_photo)); ?>" alt="">

                <div class="card-body">
                    <h4 class="card-title"> <a href="" class="card-link"><?php echo e($trip->trip_name); ?></a></h4>

                    <h5>Starting From: <?php echo e($trip->trip_cost); ?></h5>
                    <h5>Destination: <?php echo e($trip->destination->country); ?></h5>
                    <h5>Duration: <?php echo e($trip->duration); ?> days</h5>

                    <a href="<?php echo e(route('tripDetails',['activity'=>$activity->activity,'tripName'=>$trip->trip_name])); ?>" class="btn btn-primary d-grid">View Details</a>
                </div>


            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <p>Search Not Found</p>
        <?php endif; ?>
    </div>
</div>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/home.js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Documents\laravel\eticketingapp\resources\views/trips.blade.php ENDPATH**/ ?>